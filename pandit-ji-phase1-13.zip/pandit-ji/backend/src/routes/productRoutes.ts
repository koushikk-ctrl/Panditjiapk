import { Router } from "express";
import { listProducts, getProductById } from "../controllers/productController";
import { asyncHandler } from "../utils/asyncHandler";

const router = Router();
router.get("/", asyncHandler(listProducts));
router.get("/:id", asyncHandler(getProductById));

export default router;
