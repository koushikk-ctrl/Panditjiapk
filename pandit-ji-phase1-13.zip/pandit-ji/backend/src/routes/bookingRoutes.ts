import { Router } from "express";
import { listBookings, createBooking } from "../controllers/bookingController";
import { asyncHandler } from "../utils/asyncHandler";
import { protect } from "../middleware/auth";

const router = Router();
router.get("/", protect, asyncHandler(listBookings));
router.post("/", protect, asyncHandler(createBooking));

export default router;
