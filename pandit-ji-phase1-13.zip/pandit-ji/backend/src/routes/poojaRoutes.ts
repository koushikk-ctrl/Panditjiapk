import { Router } from "express";
import { listPoojas, getPoojaById } from "../controllers/poojaController";
import { asyncHandler } from "../utils/asyncHandler";

const router = Router();
router.get("/", asyncHandler(listPoojas));
router.get("/:id", asyncHandler(getPoojaById));

export default router;
