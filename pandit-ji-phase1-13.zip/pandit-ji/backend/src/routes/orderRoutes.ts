import { Router } from "express";
import { createOrder, listOrders } from "../controllers/orderController";
import { asyncHandler } from "../utils/asyncHandler";
import { protect } from "../middleware/auth";

const router = Router();
router.get("/", protect, asyncHandler(listOrders));
router.post("/", protect, asyncHandler(createOrder));

export default router;
