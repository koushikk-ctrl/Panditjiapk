import { Router } from "express";
import { listPandits, getPanditById } from "../controllers/panditController";
import { asyncHandler } from "../utils/asyncHandler";

const router = Router();
router.get("/", asyncHandler(listPandits));
router.get("/:id", asyncHandler(getPanditById));

export default router;
