import { Router } from "express";
import { listFestivals, getFestivalById } from "../controllers/festivalController";
import { asyncHandler } from "../utils/asyncHandler";

const router = Router();
router.get("/", asyncHandler(listFestivals));
router.get("/:id", asyncHandler(getFestivalById));

export default router;
