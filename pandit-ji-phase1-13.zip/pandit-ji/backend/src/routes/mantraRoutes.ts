import { Router } from "express";
import { listMantras, getMantraById } from "../controllers/mantraController";
import { asyncHandler } from "../utils/asyncHandler";

const router = Router();
router.get("/", asyncHandler(listMantras));
router.get("/:id", asyncHandler(getMantraById));

export default router;
