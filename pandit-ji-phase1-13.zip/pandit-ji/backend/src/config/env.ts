import dotenv from "dotenv";

dotenv.config();

export const env = {
  port: parseInt(process.env.PORT || "5000", 10),
  nodeEnv: process.env.NODE_ENV || "development",
  corsOrigin: process.env.CORS_ORIGIN || "*",

  // Added in Phase 12
  mongodbUri: process.env.MONGODB_URI || "",

  // Added in Phase 13
  jwtSecret: process.env.JWT_SECRET || "",
  jwtExpiresIn: process.env.JWT_EXPIRES_IN || "7d",

  // Added in Phase 15
  anthropicApiKey: process.env.ANTHROPIC_API_KEY || "",

  isProduction: process.env.NODE_ENV === "production",
};
