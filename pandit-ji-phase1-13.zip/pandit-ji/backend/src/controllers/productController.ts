import { Request, Response } from "express";
import { Product } from "../models/Product";
import { ApiError } from "../utils/ApiError";

export async function listProducts(req: Request, res: Response) {
  const products = await Product.find().sort({ createdAt: -1 });
  res.json({ success: true, data: products });
}

export async function getProductById(req: Request, res: Response) {
  const product = await Product.findOne({ slug: req.params.id });
  if (!product) throw ApiError.notFound("Product not found");
  res.json({ success: true, data: product });
}
