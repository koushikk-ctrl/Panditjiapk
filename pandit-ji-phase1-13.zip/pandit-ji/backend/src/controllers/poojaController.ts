import { Request, Response } from "express";
import { Pooja } from "../models/Pooja";
import { ApiError } from "../utils/ApiError";

export async function listPoojas(req: Request, res: Response) {
  const poojas = await Pooja.find().sort({ createdAt: -1 });
  res.json({ success: true, data: poojas });
}

export async function getPoojaById(req: Request, res: Response) {
  const pooja = await Pooja.findOne({ slug: req.params.id });
  if (!pooja) throw ApiError.notFound("Pooja not found");
  res.json({ success: true, data: pooja });
}
