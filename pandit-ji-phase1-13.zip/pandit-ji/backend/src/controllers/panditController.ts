import { Request, Response } from "express";
import { Pandit } from "../models/Pandit";
import { ApiError } from "../utils/ApiError";

export async function listPandits(req: Request, res: Response) {
  const pandits = await Pandit.find({ isApproved: true }).sort({ rating: -1 });
  res.json({ success: true, data: pandits });
}

export async function getPanditById(req: Request, res: Response) {
  const pandit = await Pandit.findOne({ slug: req.params.id });
  if (!pandit) throw ApiError.notFound("Pandit not found");
  res.json({ success: true, data: pandit });
}
