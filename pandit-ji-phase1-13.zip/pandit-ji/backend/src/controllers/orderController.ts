import { Request, Response } from "express";
import { Order } from "../models/Order";
import { Product } from "../models/Product";
import { ApiError } from "../utils/ApiError";

export async function createOrder(req: Request, res: Response) {
  const { items, address, paymentMethod, subtotal, deliveryCharge, total } = req.body;

  if (!items || !Array.isArray(items) || items.length === 0) {
    throw ApiError.badRequest("items are required");
  }
  if (!address || !address.name || !address.phone || !address.addressLine || !address.city || !address.pincode) {
    throw ApiError.badRequest("A complete address is required");
  }

  const resolvedItems = [];
  for (const item of items) {
    const product = await Product.findOne({ slug: item.productId });
    if (!product) throw ApiError.notFound(`Product not found: ${item.productId}`);
    resolvedItems.push({
      product: product._id,
      quantity: item.quantity,
      priceAtPurchase: item.priceAtPurchase,
    });
  }

  // PRODUCTION TODO: if paymentMethod === "mock_online", this is where a
  // real Razorpay order would be created server-side (razorpay.orders.create),
  // and the client would open Razorpay checkout with the returned order id.
  // The payment signature must then be verified here before confirming the
  // order. "cod" orders skip payment entirely and ship as-is.

  const order = await Order.create({
    items: resolvedItems,
    address,
    paymentMethod: paymentMethod === "mock_online" ? "mock_online" : "cod",
    subtotal: subtotal ?? 0,
    deliveryCharge: deliveryCharge ?? 0,
    total: total ?? 0,
    user: req.user!.id,
  });

  const populated = await order.populate("items.product");
  res.status(201).json({ success: true, data: populated });
}

export async function listOrders(req: Request, res: Response) {
  const { id: userId, role } = req.user!;
  const filter = role === "admin" ? {} : { user: userId };
  const orders = await Order.find(filter).populate("items.product").sort({ createdAt: -1 });
  res.json({ success: true, data: orders });
}
