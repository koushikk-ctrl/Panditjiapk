import { Request, Response } from "express";
import { Booking } from "../models/Booking";
import { Pandit } from "../models/Pandit";
import { ApiError } from "../utils/ApiError";

export async function listBookings(req: Request, res: Response) {
  const { id: userId, role } = req.user!;

  let bookings;
  if (role === "admin") {
    // Admins see everything (full admin dashboard arrives in Phase 14).
    bookings = await Booking.find().populate("pandit").sort({ createdAt: -1 });
  } else if (role === "pandit") {
    // A pandit sees bookings made WITH them, not bookings they made as a
    // customer — resolve their own Pandit profile first.
    const panditProfile = await Pandit.findOne({ user: userId });
    if (!panditProfile) {
      return res.json({ success: true, data: [] }); // no linked pandit profile yet
    }
    bookings = await Booking.find({ pandit: panditProfile._id }).populate("pandit").sort({ createdAt: -1 });
  } else {
    bookings = await Booking.find({ user: userId }).populate("pandit").sort({ createdAt: -1 });
  }

  res.json({ success: true, data: bookings });
}

export async function createBooking(req: Request, res: Response) {
  const { panditId, poojaType, date, time, location, specialInstructions } = req.body;

  if (!panditId || !poojaType || !date || !time || !location) {
    throw ApiError.badRequest("panditId, poojaType, date, time, and location are required");
  }

  const pandit = await Pandit.findOne({ slug: panditId });
  if (!pandit) throw ApiError.notFound("Pandit not found");

  const booking = await Booking.create({
    pandit: pandit._id,
    poojaType,
    date,
    time,
    location,
    specialInstructions,
    user: req.user!.id,
  });

  const populated = await booking.populate("pandit");
  res.status(201).json({ success: true, data: populated });
}
