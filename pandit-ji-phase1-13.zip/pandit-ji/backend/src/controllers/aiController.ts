import { Request, Response } from "express";
import { ApiError } from "../utils/ApiError";

// PHASE 15 will connect this to a real LLM API (called server-side only —
// the API key must never be shipped to the mobile app). The response will
// always carry a disclaimer that this is an AI assistant for informational/
// devotional guidance, not a substitute for a qualified Pandit, matching the
// notice shown in the mobile app's AI assistant UI.

export function chat(req: Request, res: Response) {
  throw ApiError.notImplemented("Pandit Ji AI chat will be implemented in Phase 15 (AI Assistant).");
}
