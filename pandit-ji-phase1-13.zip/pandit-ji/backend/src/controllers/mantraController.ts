import { Request, Response } from "express";
import { Mantra } from "../models/Mantra";
import { ApiError } from "../utils/ApiError";

export async function listMantras(req: Request, res: Response) {
  const mantras = await Mantra.find().sort({ createdAt: -1 });
  res.json({ success: true, data: mantras });
}

export async function getMantraById(req: Request, res: Response) {
  const mantra = await Mantra.findOne({ slug: req.params.id });
  if (!mantra) throw ApiError.notFound("Mantra not found");
  res.json({ success: true, data: mantra });
}
