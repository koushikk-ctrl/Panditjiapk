import { Request, Response } from "express";
import { Festival } from "../models/Festival";
import { ApiError } from "../utils/ApiError";

export async function listFestivals(req: Request, res: Response) {
  const festivals = await Festival.find().sort({ date: 1 });
  res.json({ success: true, data: festivals });
}

export async function getFestivalById(req: Request, res: Response) {
  const festival = await Festival.findOne({ slug: req.params.id });
  if (!festival) throw ApiError.notFound("Festival not found");
  res.json({ success: true, data: festival });
}
