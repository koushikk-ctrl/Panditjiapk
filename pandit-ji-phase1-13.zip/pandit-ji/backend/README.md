# Pandit Ji — Backend (Phase 13: Authentication)

A working Express + TypeScript API server backed by MongoDB, with real
authentication now in place: password hashing (bcrypt), JWT tokens, and
three roles (user / pandit / admin). Bookings, Cart, and Orders now require
login and are scoped to the logged-in person — a regular user only sees
their own bookings, while a pandit account sees bookings made *with* them.
AI chat remains intentionally stubbed (501) until Phase 15.

## Prerequisites

- Node.js 18+ (check: `node -v`)
- MongoDB running locally — see setup below if you don't have it yet

## Step 1: Get MongoDB running locally

**Option A — Docker (recommended, cleanest):**

```bash
docker run -d --name pandit-ji-mongo -p 27017:27017 mongo:7
```

That's it. Check it's running with `docker ps` — you should see `pandit-ji-mongo`
in the list. To stop it later: `docker stop pandit-ji-mongo`. To start it
again after a reboot: `docker start pandit-ji-mongo`.

**Option B — Native install (no Docker):**

- macOS: `brew tap mongodb/brew && brew install mongodb-community && brew services start mongodb-community`
- Windows/Linux: follow MongoDB's official "Install MongoDB Community Edition" guide for your OS, then make sure the `mongod` service is running.

Either way, MongoDB will be reachable at `mongodb://localhost:27017` — that's
already the default in `.env.example`, so no changes needed there if you're
using the default port.

## Step 2: Install, configure, seed, and run

```bash
cd pandit-ji/backend
npm install
cp .env.example .env
npm run seed     # populates MongoDB with starter data (poojas, mantras, festivals, pandits, products)
npm run dev
```

You should see, in order:
```
✅ Connected to MongoDB (pandit-ji)
🧹 Cleared existing Pooja/Mantra/Festival/Pandit/Product/User collections
🕉️  Seeded 3 poojas
📿 Seeded 4 mantras
🪔 Seeded 7 festivals
🙏 Seeded 3 pandits
🛍️  Seeded 5 products
👤 Seeded 3 demo accounts (user/pandit/admin), all with password "password123"
🔗 Linked demo pandit account to Pandit profile "pandit-ramesh-sharma"
✅ Done! Database is ready.
```

The seed script also creates one login-ready account per role, so you can
test auth immediately without registering manually first:

| Role | Email | Password |
|---|---|---|
| user | `user@test.com` | `password123` |
| pandit | `pandit@test.com` | `password123` |
| admin | `admin@test.com` | `password123` |

The `pandit@test.com` account is linked to the "पं. रमेश शर्मा" Pandit
profile, so bookings made *with* that pandit will show up when you log in
as `pandit@test.com` and call `GET /api/bookings`.

**Before you go further**: make sure `JWT_SECRET` in your `.env` is set to
something other than the placeholder (generate one with
`node -e "console.log(require('crypto').randomBytes(48).toString('hex'))"`
and paste it in) — login/register will fail with a clear error otherwise.
then, after `npm run dev`:
```
✅ MongoDB connected (pandit-ji)
🪔 Pandit Ji API running on http://localhost:5000/api (development)
   Health check: http://localhost:5000/api/health
```

Leave `npm run dev` running in its own terminal tab while you test it or
point the mobile app at it. **If MongoDB isn't running**, `npm run dev` will
print a clear error ("MongoDB connection failed. Is MongoDB actually
running?") and exit — start MongoDB (Step 1) and try again.

You only need to run `npm run seed` once (or any time you want to reset the
data back to the starter set — it's safe to re-run).

## How to test it

Use `curl`, a browser (for GET requests), or an app like Postman/Insomnia.
Make sure you've run `npm run seed` at least once (Step 2 above).

### Public endpoints (no login needed)

```bash
curl http://localhost:5000/api/health
curl http://localhost:5000/api/poojas
curl http://localhost:5000/api/poojas/ganesh-pooja
curl http://localhost:5000/api/mantras
curl http://localhost:5000/api/festivals
curl http://localhost:5000/api/festivals/diwali
curl http://localhost:5000/api/pandits
curl http://localhost:5000/api/products
curl http://localhost:5000/api/panchang/today
curl http://localhost:5000/api/astrology/muhurat
curl -X POST http://localhost:5000/api/astrology/kundli \
  -H "Content-Type: application/json" \
  -d '{"name":"Test","dob":"15/08/1995","tob":"06:30","place":"Indore"}'

# A route that doesn't exist should return a clean 404 JSON response, not a crash:
curl http://localhost:5000/api/does-not-exist
```

### Auth flow — register, login, get a token

```bash
# Register a brand new account (or skip this and use a seeded account below)
curl -X POST http://localhost:5000/api/auth/register \
  -H "Content-Type: application/json" \
  -d '{"name":"Your Name","email":"you@example.com","password":"password123"}'

# Log in with a seeded demo account instead
curl -X POST http://localhost:5000/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"email":"user@test.com","password":"password123"}'
```

Both return `{ "data": { "user": {...}, "token": "..." } }`. Copy the
`token` value — you'll need it for everything below. In the examples that
follow, replace `YOUR_TOKEN` with it.

```bash
# Confirm the token works
curl http://localhost:5000/api/auth/me -H "Authorization: Bearer YOUR_TOKEN"

# Without a token, this should fail with 401 Unauthorized:
curl http://localhost:5000/api/auth/me
```

### Protected endpoints (require a token)

```bash
# Create a booking (log in as user@test.com first)
curl -X POST http://localhost:5000/api/bookings \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer YOUR_TOKEN" \
  -d '{"panditId":"pandit-ramesh-sharma","poojaType":"griha-pravesh","date":"12/10/2026","time":"09:00","location":"Indore"}'

# List bookings — as user@test.com, shows only bookings YOU made
curl http://localhost:5000/api/bookings -H "Authorization: Bearer YOUR_TOKEN"

# Now log in as pandit@test.com instead, and call the same endpoint —
# it should show the booking you just created, because that account is
# linked to the "pandit-ramesh-sharma" profile it was booked with.
curl -X POST http://localhost:5000/api/auth/login -H "Content-Type: application/json" \
  -d '{"email":"pandit@test.com","password":"password123"}'
curl http://localhost:5000/api/bookings -H "Authorization: Bearer PANDIT_TOKEN"

# Add to cart (as any logged-in user)
curl -X POST http://localhost:5000/api/cart \
  -H "Content-Type: application/json" -H "Authorization: Bearer YOUR_TOKEN" \
  -d '{"productId":"incense-sticks","quantity":2}'
curl http://localhost:5000/api/cart -H "Authorization: Bearer YOUR_TOKEN"

# Place an order
curl -X POST http://localhost:5000/api/orders \
  -H "Content-Type: application/json" -H "Authorization: Bearer YOUR_TOKEN" \
  -d '{"items":[{"productId":"incense-sticks","quantity":2,"priceAtPurchase":54}],"address":{"name":"Test User","phone":"9999999999","addressLine":"123 MG Road","city":"Indore","pincode":"452001"},"paymentMethod":"cod","subtotal":108,"deliveryCharge":49,"total":157}'

# Without a token, bookings/cart/orders should all fail with 401:
curl http://localhost:5000/api/bookings
curl http://localhost:5000/api/cart
curl http://localhost:5000/api/orders
```

### Still stubbed

```bash
# AI chat is intentionally stubbed — should return 501 with a clear
# "coming in Phase 15" message, not a crash:
curl -X POST http://localhost:5000/api/ai/chat -H "Content-Type: application/json" -d '{}'
```

Every response follows the same shape: `{ "success": true, "data": ... }` on
success, or `{ "success": false, "message": "..." }` on error.

## What's implemented vs. stubbed

| Area | Status |
|---|---|
| Health | ✅ working, public |
| Poojas, Mantras, Festivals, Pandits, Products | ✅ working, public — real MongoDB collections |
| Auth (register/login/me) | ✅ working — bcrypt password hashing, JWT tokens, 3 roles |
| Bookings, Cart, Orders | ✅ working, **requires login** — scoped to the logged-in user (or to a pandit's own bookings, or to everything for admins) |
| Panchang, Astrology (Kundli/Muhurat) | ✅ working, public (clearly-labelled demo data — these are read-only reference lookups, not something a user owns, so there's nothing to scope to a user) |
| AI chat | 🚧 stubbed — returns 501, real impl in Phase 15 |

**Note on response shape**: records now come from MongoDB, so every response
includes Mongo's `_id`, `createdAt`, and `updatedAt` fields in addition to the
fields you'd expect. The human-readable identifier the mobile app uses (e.g.
`"ganesh-pooja"`) is now in a field called `slug` instead of `id` — GET
`/api/poojas/ganesh-pooja` still works exactly the same (it looks up by
`slug` under the hood), nothing about the URLs changed.

## How auth works

- Passwords are hashed with bcrypt before being saved (see the `pre("save")`
  hook in `src/models/User.ts`) — plain-text passwords are never stored.
- `POST /api/auth/register` and `POST /api/auth/login` both return a JWT
  `token`. Send it on every protected request as
  `Authorization: Bearer <token>`.
- `src/middleware/auth.ts` exports two pieces: `protect` (requires a valid
  token, attaches `req.user = { id, role }`) and `authorize(...roles)` (an
  additional role gate for routes that need it — not used anywhere yet since
  there's no admin-only route until Phase 14, but ready to use).
- Only `user` and `pandit` roles can self-register. `admin` accounts aren't
  created through the public API — only via direct database access or (once
  it exists) promotion by an existing admin in Phase 14.

## Project structure

```
backend/
├── src/
│   ├── controllers/   # request handlers (one file per feature)
│   ├── models/        # Mongoose schemas: User, Pooja, Mantra, Festival, Pandit, Product, Booking, Order, CartItem
│   ├── data/          # seed-only demo data, used by utils/seed.ts (not read by controllers anymore)
│   ├── middleware/     # error handling, 404, rate limiting
│   ├── routes/        # Express routers, one per feature, mounted in routes/index.ts
│   ├── services/      # empty for now — Razorpay/panchang/LLM clients land here later
│   ├── utils/          # ApiError, asyncHandler, seed.ts
│   ├── config/        # env.ts (reads .env), db.ts (MongoDB connection)
│   ├── app.ts          # Express app + middleware wiring
│   └── server.ts      # connects to MongoDB, then starts the HTTP server
├── .env.example
├── package.json
└── tsconfig.json
```

## Security measures already in place

- `helmet` for safe default HTTP headers
- `cors` configured via `CORS_ORIGIN` in `.env`
- `express-rate-limit` on all `/api` routes (100 req/15min), with a stricter
  limiter ready for auth endpoints (10 req/15min)
- A centralized error handler that never leaks stack traces in production
  (`NODE_ENV=production`)
- `.env` is gitignored — never commit real secrets

## Connecting the mobile app to this backend

The mobile app's `services/apiClient.ts` already points to
`http://localhost:5000/api` by default (set in `mobile/app.json` →
`extra.apiUrl`), and it already attaches a stored JWT token to every request
automatically if one exists (see the request interceptor in that file) — so
the pieces are in place on both sides. The mobile app still uses its own
local demo data for every screen, though; actually swapping each screen over
to call this API (and building real login/signup screens in the app) is
bigger than one phase and isn't scheduled until the broader plan calls for
it. If you run the backend and the mobile app on the same computer using the
Expo Go app on your **phone**, remember `localhost` won't resolve to your
computer from the phone — you'll need your computer's local network IP
instead (e.g. `http://192.168.1.5:5000/api`) when that wiring happens.

## What's next

Phase 14 will add the Admin dashboard (a small separate web app in `admin/`)
for managing poojas, articles, festivals, mantras, products, pandit
approvals, bookings, orders, and users — using the `authorize("admin")`
middleware that's already wired up and waiting.
