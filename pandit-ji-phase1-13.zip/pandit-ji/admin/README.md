# Admin Dashboard — coming in Phase 14

This folder is reserved for the admin dashboard (web app) described in the
project plan: managing poojas, articles, festivals, mantras, products,
pandit approvals, bookings, orders, users, and notifications.

It isn't built yet because it depends on:
- The backend API (Phase 11 — done)
- MongoDB (Phase 12)
- Role-based authentication, specifically the Admin role (Phase 13)

Once those are in place, Phase 14 will scaffold a small React (Vite) admin
app here that talks to the same backend API.
