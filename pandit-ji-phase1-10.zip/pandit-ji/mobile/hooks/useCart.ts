import { useCallback, useEffect, useMemo, useState } from "react";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { getProductById, getDiscountedPrice } from "@/constants/productData";

const STORAGE_KEY = "cart:v1";
const FREE_DELIVERY_THRESHOLD = 500;
const DELIVERY_CHARGE = 49;

// Shape stored on device: { "productId": quantity, ... }
type CartMap = Record<string, number>;

export function useCart() {
  const [cart, setCart] = useState<CartMap>({});
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    (async () => {
      try {
        const raw = await AsyncStorage.getItem(STORAGE_KEY);
        if (raw) setCart(JSON.parse(raw));
      } catch (err) {
        console.error("Failed to load cart:", err);
      } finally {
        setLoading(false);
      }
    })();
  }, []);

  const persist = useCallback(async (next: CartMap) => {
    setCart(next);
    try {
      await AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(next));
    } catch (err) {
      console.error("Failed to save cart:", err);
    }
  }, []);

  const addToCart = useCallback(
    (productId: string, quantity = 1) => {
      const next = { ...cart, [productId]: (cart[productId] || 0) + quantity };
      persist(next);
    },
    [cart, persist]
  );

  const setQuantity = useCallback(
    (productId: string, quantity: number) => {
      if (quantity <= 0) {
        const { [productId]: _removed, ...rest } = cart;
        persist(rest);
        return;
      }
      persist({ ...cart, [productId]: quantity });
    },
    [cart, persist]
  );

  const removeFromCart = useCallback(
    (productId: string) => {
      const { [productId]: _removed, ...rest } = cart;
      persist(rest);
    },
    [cart, persist]
  );

  const clearCart = useCallback(() => persist({}), [persist]);

  const cartItems = useMemo(() => {
    return Object.entries(cart)
      .map(([productId, quantity]) => {
        const product = getProductById(productId);
        if (!product) return null;
        return { product, quantity, lineTotal: getDiscountedPrice(product) * quantity };
      })
      .filter((item): item is NonNullable<typeof item> => item !== null);
  }, [cart]);

  const itemCount = useMemo(() => Object.values(cart).reduce((sum, q) => sum + q, 0), [cart]);
  const subtotal = useMemo(() => cartItems.reduce((sum, item) => sum + item.lineTotal, 0), [cartItems]);
  const deliveryCharge = subtotal === 0 || subtotal >= FREE_DELIVERY_THRESHOLD ? 0 : DELIVERY_CHARGE;
  const total = subtotal + deliveryCharge;

  return {
    loading,
    cartItems,
    itemCount,
    subtotal,
    deliveryCharge,
    total,
    freeDeliveryThreshold: FREE_DELIVERY_THRESHOLD,
    addToCart,
    setQuantity,
    removeFromCart,
    clearCart,
  };
}
