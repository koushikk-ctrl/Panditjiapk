import { useCallback, useEffect, useState } from "react";
import AsyncStorage from "@react-native-async-storage/async-storage";

const STORAGE_KEY = "bookings:v1";

export type BookingStatus = "pending" | "confirmed" | "completed" | "cancelled";

export type Booking = {
  id: string;
  panditId: string;
  panditName: string;
  poojaTypeId: string;
  poojaTypeLabel: string;
  date: string; // as entered, e.g. DD/MM/YYYY
  time: string;
  location: string;
  instructions: string;
  status: BookingStatus;
  price: number;
  createdAt: string; // ISO timestamp
};

export function useBookings() {
  const [bookings, setBookings] = useState<Booking[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    (async () => {
      try {
        const raw = await AsyncStorage.getItem(STORAGE_KEY);
        if (raw) setBookings(JSON.parse(raw));
      } catch (err) {
        console.error("Failed to load bookings:", err);
      } finally {
        setLoading(false);
      }
    })();
  }, []);

  const persist = useCallback(async (next: Booking[]) => {
    setBookings(next);
    try {
      await AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(next));
    } catch (err) {
      console.error("Failed to save bookings:", err);
    }
  }, []);

  const addBooking = useCallback(
    (input: Omit<Booking, "id" | "status" | "createdAt">) => {
      const newBooking: Booking = {
        ...input,
        id: `booking-${Date.now()}`,
        status: "pending",
        createdAt: new Date().toISOString(),
      };
      persist([newBooking, ...bookings]);
      return newBooking;
    },
    [bookings, persist]
  );

  const updateStatus = useCallback(
    (id: string, status: BookingStatus) => {
      persist(bookings.map((b) => (b.id === id ? { ...b, status } : b)));
    },
    [bookings, persist]
  );

  return { bookings, loading, addBooking, updateStatus };
}
