import { apiClient } from "@/services/apiClient";
import {
  demoPanchangDetail,
  demoMuhurats,
  demoKundliResult,
  PanchangDetail,
  Muhurat,
  KundliInput,
  KundliResult,
} from "@/constants/astrologyData";

// ============================================================================
// PRODUCTION TODO:
// Every function below currently returns static demo data. To go live,
// replace each function body with a real API call (examples shown commented
// out) to a licensed Vedic astrology/panchang provider. Screens only import
// from this file, so no screen code needs to change when you do this.
// ============================================================================

export async function fetchTodayPanchang(): Promise<PanchangDetail> {
  await new Promise((resolve) => setTimeout(resolve, 150));
  return demoPanchangDetail;
  // return (await apiClient.get<PanchangDetail>("/panchang/today")).data;
}

export async function fetchUpcomingMuhurats(): Promise<Muhurat[]> {
  await new Promise((resolve) => setTimeout(resolve, 150));
  return demoMuhurats;
  // return (await apiClient.get<Muhurat[]>("/astrology/muhurat")).data;
}

export async function generateKundli(input: KundliInput): Promise<KundliResult> {
  await new Promise((resolve) => setTimeout(resolve, 400)); // simulate calculation time
  // A real implementation would send `input` to a provider that calculates
  // the actual chart from birth date/time/place:
  // return (await apiClient.post<KundliResult>("/astrology/kundli", input)).data;
  return demoKundliResult;
}
