import { apiClient } from "@/services/apiClient";
import { products, Product } from "@/constants/productData";

// PRODUCTION TODO: replace bodies with real calls, e.g.
//   const { data } = await apiClient.get<Product[]>("/products");
// Screens only depend on this file, so the swap needs no screen changes.

export async function fetchProducts(): Promise<Product[]> {
  await new Promise((resolve) => setTimeout(resolve, 150));
  return products;
}

export async function fetchProductById(id: string): Promise<Product | undefined> {
  await new Promise((resolve) => setTimeout(resolve, 100));
  return products.find((p) => p.id === id);
}

export type OrderPayload = {
  items: { productId: string; quantity: number; priceAtPurchase: number }[];
  address: { name: string; phone: string; addressLine: string; city: string; pincode: string };
  paymentMethod: "cod" | "mock_online";
  subtotal: number;
  deliveryCharge: number;
  total: number;
};

export type OrderResult = {
  orderId: string;
  status: "placed";
  estimatedDelivery: string;
};

/**
 * Places an order. Currently simulated locally — no real payment is taken.
 * PRODUCTION TODO: integrate Razorpay here for "mock_online" (create an
 * order via POST /api/orders, open Razorpay checkout, verify payment
 * signature server-side, then confirm the order) and send `payload` to
 * POST /api/orders for "cod" as well.
 */
export async function createOrder(payload: OrderPayload): Promise<OrderResult> {
  await new Promise((resolve) => setTimeout(resolve, 600)); // simulate network + payment processing
  return {
    orderId: `PJ${Date.now().toString().slice(-8)}`,
    status: "placed",
    estimatedDelivery: "3-5 कार्यदिवस",
  };
  // return (await apiClient.post<OrderResult>("/orders", payload)).data;
}
