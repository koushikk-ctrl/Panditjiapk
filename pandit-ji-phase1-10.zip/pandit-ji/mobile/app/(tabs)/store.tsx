import React, { useMemo, useState } from "react";
import { View, Text, TextInput, ScrollView, StyleSheet, TouchableOpacity } from "react-native";
import { router } from "expo-router";
import { useQuery } from "@tanstack/react-query";
import { Ionicons } from "@expo/vector-icons";
import { Colors, Radius, Spacing, Typography } from "@/constants/theme";
import CategoryChip from "@/components/CategoryChip";
import ProductCard from "@/components/ProductCard";
import EmptyState from "@/components/EmptyState";
import { fetchProducts } from "@/services/storeService";
import { productCategories, getDiscountedPrice } from "@/constants/productData";
import { useCart } from "@/hooks/useCart";

const ALL = "सभी";

export default function StoreScreen() {
  const [query, setQuery] = useState("");
  const [activeCategory, setActiveCategory] = useState(ALL);
  const { itemCount } = useCart();

  const { data: allProducts, isLoading } = useQuery({
    queryKey: ["products"],
    queryFn: fetchProducts,
  });

  const filtered = useMemo(() => {
    if (!allProducts) return [];
    return allProducts.filter((p) => {
      const categoryLabel = productCategories.find((c) => c.id === p.category)?.label;
      const matchesCategory = activeCategory === ALL || categoryLabel === activeCategory;
      const matchesQuery = p.name.toLowerCase().includes(query.trim().toLowerCase());
      return matchesCategory && matchesQuery;
    });
  }, [allProducts, query, activeCategory]);

  return (
    <View style={styles.screen}>
      <View style={styles.header}>
        <View style={{ flex: 1 }}>
          <Text style={Typography.h1}>पूजा सामग्री स्टोर</Text>
          <Text style={[Typography.bodySmall, { marginTop: 2 }]}>पूजा के लिए सब कुछ, एक ही जगह</Text>
        </View>
        <TouchableOpacity style={styles.cartButton} onPress={() => router.push("/cart")}>
          <Ionicons name="cart" size={20} color={Colors.textOnPrimary} />
          {itemCount > 0 ? (
            <View style={styles.cartBadge}>
              <Text style={styles.cartBadgeText}>{itemCount}</Text>
            </View>
          ) : null}
        </TouchableOpacity>
      </View>

      <View style={styles.searchBar}>
        <Ionicons name="search" size={18} color={Colors.textSecondary} />
        <TextInput
          value={query}
          onChangeText={setQuery}
          placeholder="उत्पाद खोजें..."
          placeholderTextColor={Colors.textSecondary}
          style={styles.searchInput}
        />
      </View>

      <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.chipsRow}>
        <CategoryChip label={ALL} active={activeCategory === ALL} onPress={() => setActiveCategory(ALL)} />
        {productCategories.map((c) => (
          <CategoryChip
            key={c.id}
            label={c.label}
            active={activeCategory === c.label}
            onPress={() => setActiveCategory(c.label)}
          />
        ))}
      </ScrollView>

      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={styles.grid}>
        {isLoading ? null : filtered.length === 0 ? (
          <EmptyState icon="search" title="कोई उत्पाद नहीं मिला" subtitle="कृपया अलग खोज या श्रेणी आज़माएं।" />
        ) : (
          filtered.map((p) => (
            <ProductCard
              key={p.id}
              name={p.name}
              emoji={p.emoji}
              price={p.price}
              discountPercent={p.discountPercent}
              discountedPrice={getDiscountedPrice(p)}
              rating={p.rating}
              unit={p.unit}
              onPress={() => router.push(`/product/${p.id}`)}
            />
          ))
        )}
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  screen: {
    flex: 1,
    backgroundColor: Colors.background,
    paddingTop: 56,
  },
  header: {
    flexDirection: "row",
    alignItems: "flex-start",
    paddingHorizontal: Spacing.lg,
    marginBottom: Spacing.md,
  },
  cartButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: Colors.primary,
    alignItems: "center",
    justifyContent: "center",
  },
  cartBadge: {
    position: "absolute",
    top: -4,
    right: -4,
    backgroundColor: Colors.error,
    borderRadius: 10,
    minWidth: 18,
    height: 18,
    alignItems: "center",
    justifyContent: "center",
    paddingHorizontal: 3,
  },
  cartBadgeText: {
    color: "#FFFFFF",
    fontSize: 10,
    fontWeight: "700",
  },
  searchBar: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: Colors.surface,
    borderRadius: Radius.pill,
    borderWidth: 1,
    borderColor: Colors.border,
    marginHorizontal: Spacing.lg,
    paddingHorizontal: Spacing.md,
    paddingVertical: 10,
    marginBottom: Spacing.md,
  },
  searchInput: {
    flex: 1,
    marginLeft: Spacing.sm,
    fontSize: 14,
    color: Colors.textPrimary,
  },
  chipsRow: {
    paddingHorizontal: Spacing.lg,
    paddingBottom: Spacing.md,
  },
  grid: {
    flexDirection: "row",
    flexWrap: "wrap",
    justifyContent: "space-between",
    paddingHorizontal: Spacing.lg,
    paddingBottom: Spacing.xxxl,
  },
});
