import React from "react";
import { View, Text, ScrollView, StyleSheet, TouchableOpacity } from "react-native";
import { router } from "expo-router";
import { Colors, Radius, Spacing, Typography } from "@/constants/theme";
import AppHeader from "@/components/AppHeader";
import PanchangCard from "@/components/PanchangCard";
import QuickAccessButton from "@/components/QuickAccessButton";
import DeityChip from "@/components/DeityChip";
import FeatureCard from "@/components/FeatureCard";
import SectionHeader from "@/components/SectionHeader";
import Card from "@/components/Card";
import { useSadhana } from "@/hooks/useSadhana";
import { festivalLibrary } from "@/constants/festivalData";
import { daysUntil, formatDisplayDate } from "@/utils/dateHelpers";
import {
  demoPanchang,
  quickPoojaDeities,
  demoDailyMantra,
} from "@/constants/mockData";

function getGreeting() {
  const hour = new Date().getHours();
  if (hour < 12) return "सुप्रभात";
  if (hour < 17) return "नमस्ते";
  return "शुभ संध्या";
}

export default function HomeScreen() {
  const { todayCompletedCount, totalItems, todayPercent, streak } = useSadhana();

  // Soonest upcoming festival (falls back to the first one if all have passed
  // this year, since a real panchang API would give next year's date here).
  const featuredFestival =
    [...festivalLibrary].sort((a, b) => {
      const da = daysUntil(a.date);
      const db = daysUntil(b.date);
      const rankA = da >= 0 ? da : 10000 - da;
      const rankB = db >= 0 ? db : 10000 - db;
      return rankA - rankB;
    })[0] || festivalLibrary[0];
  const featuredFestivalDaysLeft = daysUntil(featuredFestival.date);

  return (
    <View style={styles.screen}>
      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={styles.scrollContent}>
        <AppHeader greeting={getGreeting()} onNotificationPress={() => {}} />

        {/* Hero banner - echoes poster's central message, not its layout */}
        <View style={styles.hero}>
          <Text style={styles.heroText}>सनातन ज्ञान सदैव आपके साथ</Text>
        </View>

        {/* Quick Access row */}
        <View style={styles.quickAccessRow}>
          <QuickAccessButton
            icon="flame"
            label="दैनिक साधना"
            backgroundColor={Colors.primaryLight}
            iconColor={Colors.primary}
            onPress={() => router.push("/sadhana")}
          />
          <QuickAccessButton
            icon="flower"
            label="पूजा विधि"
            backgroundColor={Colors.accentPinkBg}
            iconColor={Colors.accentPink}
            onPress={() => router.push("/(tabs)/library")}
          />
          <QuickAccessButton
            icon="calendar"
            label="पंचांग"
            backgroundColor={Colors.accentBlueBg}
            iconColor={Colors.accentBlue}
            onPress={() => router.push("/jyotish/panchang")}
          />
          <QuickAccessButton
            icon="musical-notes"
            label="मंत्र व ऑडियो"
            backgroundColor={Colors.accentPurpleBg}
            iconColor={Colors.accentPurple}
            onPress={() => router.push("/audio")}
          />
        </View>

        {/* Today's Panchang */}
        <View style={{ marginTop: Spacing.lg }}>
          <PanchangCard data={demoPanchang} onPress={() => router.push("/jyotish/panchang")} />
        </View>

        {/* Quick Pooja deity scroller */}
        <View style={{ marginTop: Spacing.xl }}>
          <SectionHeader title="Quick Pooja" subtitle="तुरंत पूजा विधि देखें" />
          <ScrollView
            horizontal
            showsHorizontalScrollIndicator={false}
            contentContainerStyle={{ paddingHorizontal: Spacing.lg }}
          >
            {quickPoojaDeities.map((d) => (
              <DeityChip key={d.id} name={d.name} emoji={d.emoji} onPress={() => {}} />
            ))}
          </ScrollView>
        </View>

        {/* Daily Sadhana progress teaser - live data from useSadhana */}
        <View style={{ marginTop: Spacing.xl, paddingHorizontal: Spacing.lg }}>
          <TouchableOpacity activeOpacity={0.85} onPress={() => router.push("/sadhana")}>
            <Card backgroundColor={Colors.secondary} style={styles.sadhanaCard}>
              <View style={{ flex: 1 }}>
                <Text style={styles.sadhanaTitle}>आज की साधना</Text>
                <Text style={styles.sadhanaSubtitle}>
                  {todayCompletedCount} / {totalItems} पूर्ण • 🔥 {streak} दिन की लय
                </Text>
              </View>
              <View style={styles.sadhanaBadge}>
                <Text style={styles.sadhanaBadgeText}>{todayPercent}%</Text>
              </View>
            </Card>
          </TouchableOpacity>
        </View>

        {/* Core modules grid */}
        <View style={{ marginTop: Spacing.xl }}>
          <SectionHeader title="Explore" subtitle="हर सेवा, एक ही जगह" />
          <View style={styles.grid}>
            <FeatureCard
              title="दैनिक साधना"
              subtitle="मंत्र, आरती, ट्रैकर"
              icon="flame"
              backgroundColor={Colors.primaryLight}
              accentColor={Colors.primary}
              onPress={() => router.push("/sadhana")}
            />
            <FeatureCard
              title="पूजा पुस्तकालय"
              subtitle="विधि + मंत्र + सामग्री"
              icon="flower"
              backgroundColor={Colors.accentPinkBg}
              accentColor={Colors.accentPink}
              onPress={() => router.push("/(tabs)/library")}
            />
            <FeatureCard
              title="सनातन ज्ञान"
              subtitle="वेद, पुराण, कथाएं"
              icon="book"
              backgroundColor={Colors.accentBlueBg}
              accentColor={Colors.accentBlue}
              onPress={() => {}}
            />
            <FeatureCard
              title="ज्योतिष"
              subtitle="कुंडली, पंचांग, मुहूर्त"
              icon="planet"
              backgroundColor={Colors.accentPurpleBg}
              accentColor={Colors.accentPurple}
              onPress={() => router.push("/jyotish")}
            />
            <FeatureCard
              title="पूजा सामग्री"
              subtitle="सब कुछ एक ही जगह"
              icon="basket"
              backgroundColor={Colors.accentGreenBg}
              accentColor={Colors.accentGreen}
              onPress={() => router.push("/(tabs)/store")}
            />
            <FeatureCard
              title="पंडित बुकिंग"
              subtitle="अनुभवी पंडित से जुड़ें"
              icon="person-circle"
              backgroundColor={Colors.primaryLight}
              accentColor={Colors.primaryDark}
              onPress={() => router.push("/(tabs)/pandit")}
            />
          </View>
        </View>

        {/* Featured Festival - soonest upcoming, from real festival data */}
        <View style={{ marginTop: Spacing.md, paddingHorizontal: Spacing.lg }}>
          <SectionHeader title="Featured Festival" actionLabel="सभी देखें" onActionPress={() => router.push("/festivals")} />
          <TouchableOpacity activeOpacity={0.85} onPress={() => router.push(`/festivals/${featuredFestival.id}`)}>
            <Card backgroundColor={featuredFestival.color}>
              <Text style={styles.festivalName}>{featuredFestival.name}</Text>
              <Text style={[styles.festivalDays, { color: featuredFestival.accent }]}>
                {featuredFestivalDaysLeft >= 0 ? `${featuredFestivalDaysLeft} दिन शेष` : "बीत चुका"} •{" "}
                {formatDisplayDate(featuredFestival.date)}
              </Text>
              <Text style={[Typography.bodySmall, { marginTop: Spacing.xs }]}>
                {featuredFestival.shortDescription}
              </Text>
            </Card>
          </TouchableOpacity>
        </View>

        {/* Daily Mantra */}
        <View style={{ marginTop: Spacing.xl, paddingHorizontal: Spacing.lg, marginBottom: Spacing.xxxl }}>
          <SectionHeader title="Daily Mantra" />
          <Card backgroundColor={Colors.primaryLight}>
            <Text style={styles.mantraSanskrit}>{demoDailyMantra.sanskrit}</Text>
            <Text style={[Typography.bodySmall, { marginTop: Spacing.xs }]}>
              {demoDailyMantra.meaning}
            </Text>
          </Card>
        </View>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  screen: {
    flex: 1,
    backgroundColor: Colors.background,
  },
  scrollContent: {
    paddingBottom: Spacing.xxxl,
  },
  hero: {
    marginHorizontal: Spacing.lg,
    backgroundColor: Colors.secondary,
    borderRadius: Radius.lg,
    paddingVertical: Spacing.lg,
    paddingHorizontal: Spacing.lg,
    marginBottom: Spacing.lg,
  },
  heroText: {
    color: "#FDE9D2",
    fontSize: 16,
    fontWeight: "700",
    textAlign: "center",
  },
  quickAccessRow: {
    flexDirection: "row",
    justifyContent: "space-around",
    paddingHorizontal: Spacing.lg,
  },
  sadhanaCard: {
    flexDirection: "row",
    alignItems: "center",
  },
  sadhanaTitle: {
    color: "#FFFFFF",
    fontSize: 15,
    fontWeight: "700",
    marginBottom: 4,
  },
  sadhanaSubtitle: {
    color: "#F0D9CF",
    fontSize: 12,
  },
  sadhanaBadge: {
    width: 48,
    height: 48,
    borderRadius: 24,
    backgroundColor: Colors.primary,
    alignItems: "center",
    justifyContent: "center",
  },
  sadhanaBadgeText: {
    color: "#FFFFFF",
    fontSize: 12,
    fontWeight: "700",
  },
  grid: {
    flexDirection: "row",
    flexWrap: "wrap",
    justifyContent: "space-between",
    paddingHorizontal: Spacing.lg,
  },
  festivalName: { fontSize: 18, fontWeight: "700", color: Colors.textPrimary },
  festivalDays: { fontSize: 12, fontWeight: "600", color: Colors.accentPink, marginTop: 2 },
  mantraSanskrit: { fontSize: 18, fontWeight: "700", color: Colors.secondary },
});
