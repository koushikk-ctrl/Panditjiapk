import React, { useMemo, useState } from "react";
import { View, Text, TextInput, ScrollView, StyleSheet, TouchableOpacity } from "react-native";
import { router } from "expo-router";
import { Ionicons } from "@expo/vector-icons";
import { Colors, Radius, Spacing, Typography } from "@/constants/theme";
import CategoryChip from "@/components/CategoryChip";
import PanditCard from "@/components/PanditCard";
import EmptyState from "@/components/EmptyState";
import { pandits } from "@/constants/panditData";
import { poojaTypes, getPoojaTypeLabel } from "@/constants/poojaTypesData";

const ALL = "सभी";

export default function PanditTabScreen() {
  const [query, setQuery] = useState("");
  const [activeSpecialty, setActiveSpecialty] = useState(ALL);

  const filtered = useMemo(() => {
    return pandits.filter((p) => {
      const matchesQuery =
        p.name.toLowerCase().includes(query.trim().toLowerCase()) ||
        p.city.toLowerCase().includes(query.trim().toLowerCase());
      const matchesSpecialty =
        activeSpecialty === ALL ||
        p.specialties.includes(poojaTypes.find((t) => t.label === activeSpecialty)?.id || "");
      return matchesQuery && matchesSpecialty;
    });
  }, [query, activeSpecialty]);

  return (
    <View style={styles.screen}>
      <View style={styles.header}>
        <View style={{ flex: 1 }}>
          <Text style={Typography.h1}>पंडित बुकिंग</Text>
          <Text style={[Typography.bodySmall, { marginTop: 2 }]}>घर बैठे, अनुभवी पंडित से जुड़ें</Text>
        </View>
        <TouchableOpacity style={styles.myBookingsButton} onPress={() => router.push("/bookings")}>
          <Ionicons name="document-text-outline" size={16} color={Colors.primaryDark} />
          <Text style={styles.myBookingsText}>मेरी बुकिंग्स</Text>
        </TouchableOpacity>
      </View>

      <View style={styles.searchBar}>
        <Ionicons name="search" size={18} color={Colors.textSecondary} />
        <TextInput
          value={query}
          onChangeText={setQuery}
          placeholder="नाम या शहर से खोजें..."
          placeholderTextColor={Colors.textSecondary}
          style={styles.searchInput}
        />
      </View>

      <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.chipsRow}>
        <CategoryChip label={ALL} active={activeSpecialty === ALL} onPress={() => setActiveSpecialty(ALL)} />
        {poojaTypes.map((t) => (
          <CategoryChip
            key={t.id}
            label={t.label}
            active={activeSpecialty === t.label}
            onPress={() => setActiveSpecialty(t.label)}
          />
        ))}
      </ScrollView>

      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={styles.list}>
        {filtered.length === 0 ? (
          <EmptyState icon="search" title="कोई पंडित नहीं मिला" subtitle="कृपया अलग खोज या श्रेणी आज़माएं।" />
        ) : (
          filtered.map((p) => (
            <PanditCard
              key={p.id}
              name={p.name}
              photoEmoji={p.photoEmoji}
              experienceYears={p.experienceYears}
              city={p.city}
              rating={p.rating}
              reviewCount={p.reviewCount}
              startingPrice={p.startingPrice}
              specialtyLabels={p.specialties.map(getPoojaTypeLabel)}
              onPress={() => router.push(`/pandit-profile/${p.id}`)}
            />
          ))
        )}

        <TouchableOpacity style={styles.dashboardLink} onPress={() => router.push("/pandit-dashboard")}>
          <Ionicons name="briefcase-outline" size={16} color={Colors.textSecondary} />
          <Text style={styles.dashboardLinkText}>क्या आप एक पंडित हैं? डैशबोर्ड देखें (डेमो)</Text>
        </TouchableOpacity>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  screen: {
    flex: 1,
    backgroundColor: Colors.background,
    paddingTop: 56,
  },
  header: {
    flexDirection: "row",
    alignItems: "flex-start",
    paddingHorizontal: Spacing.lg,
    marginBottom: Spacing.md,
  },
  myBookingsButton: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: Colors.primaryLight,
    borderRadius: Radius.pill,
    paddingHorizontal: Spacing.sm,
    paddingVertical: 6,
  },
  myBookingsText: {
    fontSize: 11,
    fontWeight: "700",
    color: Colors.primaryDark,
    marginLeft: 4,
  },
  searchBar: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: Colors.surface,
    borderRadius: Radius.pill,
    borderWidth: 1,
    borderColor: Colors.border,
    marginHorizontal: Spacing.lg,
    paddingHorizontal: Spacing.md,
    paddingVertical: 10,
    marginBottom: Spacing.md,
  },
  searchInput: {
    flex: 1,
    marginLeft: Spacing.sm,
    fontSize: 14,
    color: Colors.textPrimary,
  },
  chipsRow: {
    paddingHorizontal: Spacing.lg,
    paddingBottom: Spacing.md,
  },
  list: {
    paddingHorizontal: Spacing.lg,
    paddingBottom: Spacing.xxxl,
  },
  dashboardLink: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    paddingVertical: Spacing.lg,
  },
  dashboardLinkText: {
    fontSize: 12,
    color: Colors.textSecondary,
    marginLeft: Spacing.xs,
    textDecorationLine: "underline",
  },
});
