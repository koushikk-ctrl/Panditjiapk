import React, { useState } from "react";
import { View, Text, ScrollView, StyleSheet, TouchableOpacity } from "react-native";
import { router } from "expo-router";
import { useMutation } from "@tanstack/react-query";
import { Ionicons } from "@expo/vector-icons";
import { Colors, Radius, Shadow, Spacing, Typography } from "@/constants/theme";
import FormField from "@/components/FormField";
import Button from "@/components/Button";
import EmptyState from "@/components/EmptyState";
import { useCart } from "@/hooks/useCart";
import { createOrder, OrderPayload } from "@/services/storeService";
import { getDiscountedPrice } from "@/constants/productData";

type PaymentMethod = "cod" | "mock_online";

export default function CheckoutScreen() {
  const { cartItems, subtotal, deliveryCharge, total, clearCart } = useCart();
  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [addressLine, setAddressLine] = useState("");
  const [city, setCity] = useState("");
  const [pincode, setPincode] = useState("");
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>("cod");

  const mutation = useMutation({
    mutationFn: (payload: OrderPayload) => createOrder(payload),
    onSuccess: () => {
      clearCart();
    },
  });

  const isAddressValid = name.trim() && phone.trim() && addressLine.trim() && city.trim() && pincode.trim();

  const handlePlaceOrder = () => {
    if (!isAddressValid) return;
    const payload: OrderPayload = {
      items: cartItems.map((i) => ({
        productId: i.product.id,
        quantity: i.quantity,
        priceAtPurchase: getDiscountedPrice(i.product),
      })),
      address: { name, phone, addressLine, city, pincode },
      paymentMethod,
      subtotal,
      deliveryCharge,
      total,
    };
    mutation.mutate(payload);
  };

  if (cartItems.length === 0 && !mutation.isSuccess) {
    return (
      <View style={styles.screen}>
        <BackBar title="चेकआउट" />
        <EmptyState icon="cart-outline" title="आपका कार्ट खाली है" subtitle="पहले स्टोर से कुछ सामान जोड़ें।" />
      </View>
    );
  }

  if (mutation.isSuccess) {
    return (
      <View style={styles.screen}>
        <BackBar title="ऑर्डर की पुष्टि" />
        <View style={styles.successWrap}>
          <View style={styles.successIcon}>
            <Ionicons name="checkmark" size={40} color="#FFFFFF" />
          </View>
          <Text style={styles.successTitle}>आपका ऑर्डर सफलतापूर्वक दर्ज हो गया!</Text>
          <Text style={styles.orderIdText}>ऑर्डर ID: {mutation.data.orderId}</Text>
          <Text style={styles.successSubtitle}>अनुमानित डिलीवरी: {mutation.data.estimatedDelivery}</Text>
          <Button label="स्टोर पर वापस जाएं" onPress={() => router.replace("/(tabs)/store")} style={{ marginTop: Spacing.xl, width: "100%" }} />
        </View>
      </View>
    );
  }

  return (
    <View style={styles.screen}>
      <BackBar title="चेकआउट" />

      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={styles.scrollContent}>
        <Text style={styles.sectionTitle}>डिलीवरी पता</Text>
        <FormField label="पूरा नाम" placeholder="अपना नाम दर्ज करें" value={name} onChangeText={setName} />
        <FormField label="मोबाइल नंबर" placeholder="10 अंकों का मोबाइल नंबर" value={phone} onChangeText={setPhone} keyboardType="phone-pad" />
        <FormField label="पता" placeholder="मकान नं., गली, क्षेत्र" value={addressLine} onChangeText={setAddressLine} />
        <FormField label="शहर" placeholder="शहर का नाम" value={city} onChangeText={setCity} />
        <FormField label="पिनकोड" placeholder="6 अंकों का पिनकोड" value={pincode} onChangeText={setPincode} keyboardType="number-pad" />

        <Text style={styles.sectionTitle}>ऑर्डर सारांश</Text>
        <View style={styles.orderSummaryCard}>
          {cartItems.map(({ product, quantity, lineTotal }) => (
            <View key={product.id} style={styles.orderItemRow}>
              <Text style={styles.orderItemName} numberOfLines={1}>
                {product.emoji} {product.name} × {quantity}
              </Text>
              <Text style={styles.orderItemPrice}>₹{lineTotal}</Text>
            </View>
          ))}
          <View style={[styles.orderItemRow, styles.summaryDivider]}>
            <Text style={styles.summaryLabel}>सबटोटल</Text>
            <Text style={styles.summaryValue}>₹{subtotal}</Text>
          </View>
          <View style={styles.orderItemRow}>
            <Text style={styles.summaryLabel}>डिलीवरी शुल्क</Text>
            <Text style={styles.summaryValue}>{deliveryCharge === 0 ? "मुफ़्त" : `₹${deliveryCharge}`}</Text>
          </View>
          <View style={[styles.orderItemRow, styles.totalDivider]}>
            <Text style={styles.totalLabel}>कुल राशि</Text>
            <Text style={styles.totalValue}>₹{total}</Text>
          </View>
        </View>

        <Text style={styles.sectionTitle}>भुगतान का तरीका</Text>
        <TouchableOpacity
          style={[styles.paymentOption, paymentMethod === "cod" && styles.paymentOptionActive]}
          onPress={() => setPaymentMethod("cod")}
        >
          <Ionicons name="cash-outline" size={18} color={paymentMethod === "cod" ? Colors.primary : Colors.textSecondary} />
          <Text style={[styles.paymentLabel, paymentMethod === "cod" && { color: Colors.primary }]}>
            डिलीवरी पर भुगतान (Cash on Delivery)
          </Text>
          {paymentMethod === "cod" ? <Ionicons name="checkmark-circle" size={18} color={Colors.primary} /> : null}
        </TouchableOpacity>
        <TouchableOpacity
          style={[styles.paymentOption, paymentMethod === "mock_online" && styles.paymentOptionActive]}
          onPress={() => setPaymentMethod("mock_online")}
        >
          <Ionicons name="card-outline" size={18} color={paymentMethod === "mock_online" ? Colors.primary : Colors.textSecondary} />
          <Text style={[styles.paymentLabel, paymentMethod === "mock_online" && { color: Colors.primary }]}>
            ऑनलाइन भुगतान (कार्ड/UPI — डेमो)
          </Text>
          {paymentMethod === "mock_online" ? <Ionicons name="checkmark-circle" size={18} color={Colors.primary} /> : null}
        </TouchableOpacity>
        {paymentMethod === "mock_online" ? (
          <Text style={styles.paymentNote}>
            यह एक डेमो भुगतान है — कोई वास्तविक राशि नहीं कटेगी। प्रोडक्शन में यहां Razorpay जोड़ा जाएगा।
          </Text>
        ) : null}

        <Button
          label={mutation.isPending ? "ऑर्डर दर्ज हो रहा है..." : "ऑर्डर करें"}
          onPress={handlePlaceOrder}
          disabled={!isAddressValid || mutation.isPending}
          style={{ marginTop: Spacing.lg }}
        />

        <View style={{ height: Spacing.xxxl }} />
      </ScrollView>
    </View>
  );
}

function BackBar({ title }: { title: string }) {
  return (
    <View style={styles.backBar}>
      <TouchableOpacity onPress={() => router.back()} style={styles.backButton} hitSlop={{ top: 10, bottom: 10, left: 10, right: 10 }}>
        <Ionicons name="chevron-back" size={24} color={Colors.textPrimary} />
      </TouchableOpacity>
      <Text style={styles.backBarTitle} numberOfLines={1}>
        {title}
      </Text>
      <View style={{ width: 24 }} />
    </View>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: Colors.background, paddingTop: 56 },
  backBar: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingHorizontal: Spacing.lg,
    paddingBottom: Spacing.md,
  },
  backButton: {
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: Colors.surface,
    alignItems: "center",
    justifyContent: "center",
    ...Shadow.card,
  },
  backBarTitle: {
    flex: 1,
    textAlign: "center",
    fontSize: 15,
    fontWeight: "700",
    color: Colors.textPrimary,
  },
  scrollContent: {
    paddingHorizontal: Spacing.lg,
    paddingBottom: Spacing.xxxl,
  },
  sectionTitle: {
    fontSize: 15,
    fontWeight: "700",
    color: Colors.textPrimary,
    marginTop: Spacing.md,
    marginBottom: Spacing.md,
  },
  orderSummaryCard: {
    backgroundColor: Colors.surface,
    borderRadius: Radius.lg,
    padding: Spacing.md,
    ...Shadow.card,
  },
  orderItemRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    paddingVertical: 4,
  },
  orderItemName: { fontSize: 12.5, color: Colors.textPrimary, flex: 1, marginRight: Spacing.sm },
  orderItemPrice: { fontSize: 12.5, fontWeight: "600", color: Colors.textPrimary },
  summaryDivider: {
    borderTopWidth: 1,
    borderTopColor: Colors.border,
    marginTop: Spacing.xs,
    paddingTop: Spacing.sm,
  },
  summaryLabel: { fontSize: 12.5, color: Colors.textSecondary },
  summaryValue: { fontSize: 12.5, fontWeight: "600", color: Colors.textPrimary },
  totalDivider: {
    borderTopWidth: 1,
    borderTopColor: Colors.border,
    marginTop: Spacing.xs,
    paddingTop: Spacing.sm,
  },
  totalLabel: { fontSize: 14, fontWeight: "700", color: Colors.textPrimary },
  totalValue: { fontSize: 15, fontWeight: "700", color: Colors.secondary },
  paymentOption: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: Colors.surface,
    borderWidth: 1.5,
    borderColor: Colors.border,
    borderRadius: Radius.md,
    padding: Spacing.md,
    marginBottom: Spacing.sm,
  },
  paymentOptionActive: {
    borderColor: Colors.primary,
  },
  paymentLabel: {
    flex: 1,
    fontSize: 13,
    fontWeight: "600",
    color: Colors.textPrimary,
    marginLeft: Spacing.sm,
  },
  paymentNote: {
    fontSize: 11,
    color: Colors.textSecondary,
    marginBottom: Spacing.sm,
    fontStyle: "italic",
  },
  successWrap: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
    paddingHorizontal: Spacing.xl,
  },
  successIcon: {
    width: 72,
    height: 72,
    borderRadius: 36,
    backgroundColor: Colors.accentGreen,
    alignItems: "center",
    justifyContent: "center",
    marginBottom: Spacing.lg,
  },
  successTitle: {
    fontSize: 17,
    fontWeight: "700",
    color: Colors.textPrimary,
    textAlign: "center",
  },
  orderIdText: {
    fontSize: 14,
    fontWeight: "700",
    color: Colors.primaryDark,
    marginTop: Spacing.sm,
  },
  successSubtitle: {
    fontSize: 13,
    color: Colors.textSecondary,
    marginTop: 4,
  },
});
