import React from "react";
import { View, Text, ScrollView, StyleSheet, TouchableOpacity, ActivityIndicator } from "react-native";
import { router } from "expo-router";
import { Ionicons } from "@expo/vector-icons";
import { Colors, Radius, Shadow, Spacing } from "@/constants/theme";
import Button from "@/components/Button";
import CartItemRow from "@/components/CartItemRow";
import EmptyState from "@/components/EmptyState";
import { useCart } from "@/hooks/useCart";
import { getDiscountedPrice } from "@/constants/productData";

export default function CartScreen() {
  const { loading, cartItems, subtotal, deliveryCharge, total, freeDeliveryThreshold, setQuantity, removeFromCart } =
    useCart();

  return (
    <View style={styles.screen}>
      <View style={styles.backBar}>
        <TouchableOpacity onPress={() => router.back()} style={styles.backButton} hitSlop={{ top: 10, bottom: 10, left: 10, right: 10 }}>
          <Ionicons name="chevron-back" size={24} color={Colors.textPrimary} />
        </TouchableOpacity>
        <Text style={styles.backBarTitle}>कार्ट</Text>
        <View style={{ width: 24 }} />
      </View>

      {loading ? (
        <View style={styles.centerWrap}>
          <ActivityIndicator color={Colors.primary} size="large" />
        </View>
      ) : cartItems.length === 0 ? (
        <EmptyState icon="cart-outline" title="आपका कार्ट खाली है" subtitle="स्टोर से पूजा सामग्री जोड़ें।" />
      ) : (
        <>
          <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={styles.list}>
            {subtotal < freeDeliveryThreshold ? (
              <View style={styles.freeDeliveryBanner}>
                <Ionicons name="bicycle-outline" size={16} color={Colors.accentGreen} />
                <Text style={styles.freeDeliveryText}>
                  ₹{freeDeliveryThreshold - subtotal} और जोड़ें और मुफ़्त डिलीवरी पाएं!
                </Text>
              </View>
            ) : (
              <View style={styles.freeDeliveryBanner}>
                <Ionicons name="checkmark-circle" size={16} color={Colors.accentGreen} />
                <Text style={styles.freeDeliveryText}>आपकी डिलीवरी मुफ़्त है!</Text>
              </View>
            )}

            {cartItems.map(({ product, quantity, lineTotal }) => (
              <CartItemRow
                key={product.id}
                name={product.name}
                emoji={product.emoji}
                unit={product.unit}
                unitPrice={getDiscountedPrice(product)}
                quantity={quantity}
                lineTotal={lineTotal}
                onIncrease={() => setQuantity(product.id, quantity + 1)}
                onDecrease={() => setQuantity(product.id, quantity - 1)}
                onRemove={() => removeFromCart(product.id)}
              />
            ))}
          </ScrollView>

          <View style={styles.summaryBar}>
            <View style={styles.summaryRow}>
              <Text style={styles.summaryLabel}>सबटोटल</Text>
              <Text style={styles.summaryValue}>₹{subtotal}</Text>
            </View>
            <View style={styles.summaryRow}>
              <Text style={styles.summaryLabel}>डिलीवरी शुल्क</Text>
              <Text style={styles.summaryValue}>{deliveryCharge === 0 ? "मुफ़्त" : `₹${deliveryCharge}`}</Text>
            </View>
            <View style={[styles.summaryRow, styles.totalRow]}>
              <Text style={styles.totalLabel}>कुल राशि</Text>
              <Text style={styles.totalValue}>₹{total}</Text>
            </View>
            <Button label="चेकआउट पर जाएं" onPress={() => router.push("/checkout")} style={{ marginTop: Spacing.sm }} />
          </View>
        </>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: Colors.background, paddingTop: 56 },
  centerWrap: { flex: 1, alignItems: "center", justifyContent: "center" },
  backBar: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingHorizontal: Spacing.lg,
    paddingBottom: Spacing.md,
  },
  backButton: {
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: Colors.surface,
    alignItems: "center",
    justifyContent: "center",
    ...Shadow.card,
  },
  backBarTitle: {
    flex: 1,
    textAlign: "center",
    fontSize: 15,
    fontWeight: "700",
    color: Colors.textPrimary,
  },
  list: {
    paddingHorizontal: Spacing.lg,
    paddingBottom: Spacing.md,
  },
  freeDeliveryBanner: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: Colors.accentGreenBg,
    borderRadius: Radius.md,
    padding: Spacing.md,
    marginBottom: Spacing.md,
  },
  freeDeliveryText: {
    fontSize: 12,
    fontWeight: "600",
    color: Colors.accentGreen,
    marginLeft: Spacing.sm,
    flex: 1,
  },
  summaryBar: {
    backgroundColor: Colors.surface,
    borderTopWidth: 1,
    borderTopColor: Colors.border,
    paddingHorizontal: Spacing.lg,
    paddingTop: Spacing.md,
    paddingBottom: Spacing.xl,
  },
  summaryRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    marginBottom: Spacing.xs,
  },
  summaryLabel: { fontSize: 13, color: Colors.textSecondary },
  summaryValue: { fontSize: 13, fontWeight: "600", color: Colors.textPrimary },
  totalRow: {
    borderTopWidth: 1,
    borderTopColor: Colors.border,
    paddingTop: Spacing.sm,
    marginTop: Spacing.xs,
  },
  totalLabel: { fontSize: 15, fontWeight: "700", color: Colors.textPrimary },
  totalValue: { fontSize: 17, fontWeight: "700", color: Colors.secondary },
});
