import React from "react";
import { View, Text, ScrollView, StyleSheet, TouchableOpacity, ActivityIndicator } from "react-native";
import { router } from "expo-router";
import { Ionicons } from "@expo/vector-icons";
import { Colors, Radius, Shadow, Spacing } from "@/constants/theme";
import BookingStatusBadge from "@/components/BookingStatusBadge";
import EmptyState from "@/components/EmptyState";
import { useBookings } from "@/hooks/useBookings";

export default function MyBookingsScreen() {
  const { bookings, loading, updateStatus } = useBookings();

  return (
    <View style={styles.screen}>
      <View style={styles.backBar}>
        <TouchableOpacity onPress={() => router.back()} style={styles.backButton} hitSlop={{ top: 10, bottom: 10, left: 10, right: 10 }}>
          <Ionicons name="chevron-back" size={24} color={Colors.textPrimary} />
        </TouchableOpacity>
        <Text style={styles.backBarTitle}>मेरी बुकिंग्स</Text>
        <View style={{ width: 24 }} />
      </View>

      {loading ? (
        <View style={styles.centerWrap}>
          <ActivityIndicator color={Colors.primary} size="large" />
        </View>
      ) : bookings.length === 0 ? (
        <EmptyState icon="document-text-outline" title="अभी तक कोई बुकिंग नहीं" subtitle="किसी पंडित को बुक करने के लिए पंडित सूची पर जाएं।" />
      ) : (
        <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={styles.list}>
          {bookings.map((b) => (
            <View key={b.id} style={styles.card}>
              <View style={styles.topRow}>
                <View style={{ flex: 1 }}>
                  <Text style={styles.poojaType}>{b.poojaTypeLabel}</Text>
                  <Text style={styles.panditName}>{b.panditName}</Text>
                </View>
                <BookingStatusBadge status={b.status} />
              </View>

              <View style={styles.detailRow}>
                <Ionicons name="calendar-outline" size={14} color={Colors.textSecondary} />
                <Text style={styles.detailText}>
                  {b.date} • {b.time}
                </Text>
              </View>
              <View style={styles.detailRow}>
                <Ionicons name="location-outline" size={14} color={Colors.textSecondary} />
                <Text style={styles.detailText} numberOfLines={1}>
                  {b.location}
                </Text>
              </View>
              {b.instructions ? (
                <View style={styles.detailRow}>
                  <Ionicons name="chatbox-ellipses-outline" size={14} color={Colors.textSecondary} />
                  <Text style={styles.detailText} numberOfLines={2}>
                    {b.instructions}
                  </Text>
                </View>
              ) : null}

              {b.status === "pending" ? (
                <TouchableOpacity style={styles.cancelButton} onPress={() => updateStatus(b.id, "cancelled")}>
                  <Text style={styles.cancelButtonText}>बुकिंग रद्द करें</Text>
                </TouchableOpacity>
              ) : null}
            </View>
          ))}
        </ScrollView>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: Colors.background, paddingTop: 56 },
  centerWrap: { flex: 1, alignItems: "center", justifyContent: "center" },
  backBar: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingHorizontal: Spacing.lg,
    paddingBottom: Spacing.md,
  },
  backButton: {
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: Colors.surface,
    alignItems: "center",
    justifyContent: "center",
    ...Shadow.card,
  },
  backBarTitle: {
    flex: 1,
    textAlign: "center",
    fontSize: 15,
    fontWeight: "700",
    color: Colors.textPrimary,
  },
  list: {
    paddingHorizontal: Spacing.lg,
    paddingBottom: Spacing.xxxl,
  },
  card: {
    backgroundColor: Colors.surface,
    borderRadius: Radius.lg,
    padding: Spacing.md,
    marginBottom: Spacing.md,
    ...Shadow.card,
  },
  topRow: {
    flexDirection: "row",
    alignItems: "flex-start",
    marginBottom: Spacing.sm,
  },
  poojaType: {
    fontSize: 15,
    fontWeight: "700",
    color: Colors.textPrimary,
  },
  panditName: {
    fontSize: 12,
    color: Colors.textSecondary,
    marginTop: 2,
  },
  detailRow: {
    flexDirection: "row",
    alignItems: "center",
    marginTop: 4,
  },
  detailText: {
    fontSize: 12,
    color: Colors.textSecondary,
    marginLeft: 6,
    flex: 1,
  },
  cancelButton: {
    marginTop: Spacing.sm,
    alignSelf: "flex-start",
  },
  cancelButtonText: {
    fontSize: 12,
    fontWeight: "700",
    color: Colors.error,
    textDecorationLine: "underline",
  },
});
