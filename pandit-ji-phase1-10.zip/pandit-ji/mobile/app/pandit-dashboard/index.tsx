import React, { useState } from "react";
import { View, Text, ScrollView, StyleSheet, TouchableOpacity, Switch } from "react-native";
import { router } from "expo-router";
import { Ionicons } from "@expo/vector-icons";
import { Colors, Radius, Shadow, Spacing, Typography } from "@/constants/theme";
import Card from "@/components/Card";
import DemoDataBanner from "@/components/DemoDataBanner";
import BookingStatusBadge from "@/components/BookingStatusBadge";
import EmptyState from "@/components/EmptyState";
import { useBookings } from "@/hooks/useBookings";

export default function PanditDashboardScreen() {
  const { bookings, updateStatus } = useBookings();
  const [isAvailable, setIsAvailable] = useState(true);

  const pending = bookings.filter((b) => b.status === "pending");
  const upcoming = bookings.filter((b) => b.status === "confirmed");
  const completed = bookings.filter((b) => b.status === "completed");
  const earnings = completed.reduce((sum, b) => sum + b.price, 0);

  return (
    <View style={styles.screen}>
      <View style={styles.backBar}>
        <TouchableOpacity onPress={() => router.back()} style={styles.backButton} hitSlop={{ top: 10, bottom: 10, left: 10, right: 10 }}>
          <Ionicons name="chevron-back" size={24} color={Colors.textPrimary} />
        </TouchableOpacity>
        <Text style={styles.backBarTitle}>पंडित डैशबोर्ड</Text>
        <View style={{ width: 24 }} />
      </View>

      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={styles.scrollContent}>
        <DemoDataBanner message="यह एक आर्किटेक्चर डेमो है। वास्तविक ऐप में यह डैशबोर्ड केवल लॉगिन किए गए पंडित की अपनी बुकिंग्स दिखाएगा (भूमिका-आधारित प्रमाणीकरण — बाद के चरण में)।" />

        {/* Earnings + availability */}
        <View style={styles.statsRow}>
          <Card backgroundColor={Colors.secondary} style={styles.statCard}>
            <Text style={styles.statLabel}>कुल कमाई</Text>
            <Text style={styles.statValue}>₹{earnings.toLocaleString("en-IN")}</Text>
          </Card>
          <Card style={styles.statCard}>
            <Text style={[styles.statLabel, { color: Colors.textSecondary }]}>उपलब्धता</Text>
            <View style={styles.availabilityRow}>
              <Text style={styles.availabilityLabel}>{isAvailable ? "उपलब्ध" : "अनुपलब्ध"}</Text>
              <Switch
                value={isAvailable}
                onValueChange={setIsAvailable}
                trackColor={{ false: Colors.border, true: Colors.accentGreen }}
                thumbColor="#FFFFFF"
              />
            </View>
          </Card>
        </View>

        <Section title={`नई बुकिंग्स (${pending.length})`}>
          {pending.length === 0 ? (
            <EmptyState icon="mail-open-outline" title="कोई नई बुकिंग नहीं" />
          ) : (
            pending.map((b) => (
              <View key={b.id} style={styles.bookingCard}>
                <View style={styles.bookingTopRow}>
                  <Text style={styles.poojaType}>{b.poojaTypeLabel}</Text>
                  <BookingStatusBadge status={b.status} />
                </View>
                <Text style={styles.bookingMeta}>
                  {b.date} • {b.time} • {b.location}
                </Text>
                <View style={styles.actionRow}>
                  <TouchableOpacity style={styles.confirmButton} onPress={() => updateStatus(b.id, "confirmed")}>
                    <Text style={styles.confirmButtonText}>स्वीकार करें</Text>
                  </TouchableOpacity>
                  <TouchableOpacity style={styles.rejectButton} onPress={() => updateStatus(b.id, "cancelled")}>
                    <Text style={styles.rejectButtonText}>अस्वीकार करें</Text>
                  </TouchableOpacity>
                </View>
              </View>
            ))
          )}
        </Section>

        <Section title={`आगामी बुकिंग्स (${upcoming.length})`}>
          {upcoming.length === 0 ? (
            <EmptyState icon="calendar-outline" title="कोई आगामी बुकिंग नहीं" />
          ) : (
            upcoming.map((b) => (
              <View key={b.id} style={styles.bookingCard}>
                <View style={styles.bookingTopRow}>
                  <Text style={styles.poojaType}>{b.poojaTypeLabel}</Text>
                  <BookingStatusBadge status={b.status} />
                </View>
                <Text style={styles.bookingMeta}>
                  {b.date} • {b.time} • {b.location}
                </Text>
                <TouchableOpacity style={styles.completeButton} onPress={() => updateStatus(b.id, "completed")}>
                  <Text style={styles.completeButtonText}>पूर्ण के रूप में चिह्नित करें</Text>
                </TouchableOpacity>
              </View>
            ))
          )}
        </Section>

        <Section title={`पूर्ण बुकिंग्स (${completed.length})`}>
          {completed.length === 0 ? (
            <EmptyState icon="checkmark-done-outline" title="अभी तक कोई पूर्ण बुकिंग नहीं" />
          ) : (
            completed.map((b) => (
              <View key={b.id} style={styles.bookingCard}>
                <View style={styles.bookingTopRow}>
                  <Text style={styles.poojaType}>{b.poojaTypeLabel}</Text>
                  <BookingStatusBadge status={b.status} />
                </View>
                <Text style={styles.bookingMeta}>
                  {b.date} • ₹{b.price}
                </Text>
              </View>
            ))
          )}
        </Section>

        <Section title="प्रोफ़ाइल प्रबंधन">
          <Card>
            <Text style={Typography.bodySmall}>
              प्रोफ़ाइल संपादन (नाम, अनुभव, भाषाएं, विशेषज्ञता, फोटो) अगले चरण में — बैकएंड व प्रमाणीकरण जुड़ने के बाद — पूरी तरह कार्यात्मक होगा।
            </Text>
          </Card>
        </Section>
      </ScrollView>
    </View>
  );
}

function Section({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <View style={styles.section}>
      <Text style={styles.sectionTitle}>{title}</Text>
      {children}
    </View>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: Colors.background, paddingTop: 56 },
  backBar: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingHorizontal: Spacing.lg,
    paddingBottom: Spacing.md,
  },
  backButton: {
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: Colors.surface,
    alignItems: "center",
    justifyContent: "center",
    ...Shadow.card,
  },
  backBarTitle: {
    flex: 1,
    textAlign: "center",
    fontSize: 15,
    fontWeight: "700",
    color: Colors.textPrimary,
  },
  scrollContent: {
    paddingHorizontal: Spacing.lg,
    paddingBottom: Spacing.xxxl,
  },
  statsRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    marginBottom: Spacing.xl,
  },
  statCard: {
    width: "48%",
  },
  statLabel: {
    fontSize: 11.5,
    color: "#F0D9CF",
    marginBottom: 4,
  },
  statValue: {
    fontSize: 20,
    fontWeight: "700",
    color: "#FFFFFF",
  },
  availabilityRow: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
  },
  availabilityLabel: {
    fontSize: 14,
    fontWeight: "700",
    color: Colors.textPrimary,
  },
  section: {
    marginBottom: Spacing.xl,
  },
  sectionTitle: {
    fontSize: 15,
    fontWeight: "700",
    color: Colors.textPrimary,
    marginBottom: Spacing.sm,
  },
  bookingCard: {
    backgroundColor: Colors.surface,
    borderRadius: Radius.md,
    padding: Spacing.md,
    marginBottom: Spacing.sm,
    ...Shadow.card,
  },
  bookingTopRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
  },
  poojaType: {
    fontSize: 14,
    fontWeight: "700",
    color: Colors.textPrimary,
  },
  bookingMeta: {
    fontSize: 11.5,
    color: Colors.textSecondary,
    marginTop: 4,
  },
  actionRow: {
    flexDirection: "row",
    marginTop: Spacing.sm,
  },
  confirmButton: {
    backgroundColor: Colors.accentGreen,
    borderRadius: Radius.pill,
    paddingHorizontal: Spacing.md,
    paddingVertical: 6,
    marginRight: Spacing.sm,
  },
  confirmButtonText: { fontSize: 11.5, fontWeight: "700", color: "#FFFFFF" },
  rejectButton: {
    backgroundColor: Colors.border,
    borderRadius: Radius.pill,
    paddingHorizontal: Spacing.md,
    paddingVertical: 6,
  },
  rejectButtonText: { fontSize: 11.5, fontWeight: "700", color: Colors.textSecondary },
  completeButton: {
    marginTop: Spacing.sm,
    alignSelf: "flex-start",
    backgroundColor: Colors.accentBlueBg,
    borderRadius: Radius.pill,
    paddingHorizontal: Spacing.md,
    paddingVertical: 6,
  },
  completeButtonText: { fontSize: 11.5, fontWeight: "700", color: Colors.accentBlue },
});
