import React from "react";
import { View, Text, ScrollView, StyleSheet, TouchableOpacity } from "react-native";
import { router, useLocalSearchParams } from "expo-router";
import { Ionicons } from "@expo/vector-icons";
import { Colors, Radius, Shadow, Spacing, Typography } from "@/constants/theme";
import Button from "@/components/Button";
import EmptyState from "@/components/EmptyState";
import { getPanditById } from "@/constants/panditData";
import { getPoojaTypeLabel } from "@/constants/poojaTypesData";

export default function PanditProfileScreen() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const pandit = getPanditById(id);

  if (!pandit) {
    return (
      <View style={styles.screen}>
        <BackBar title="" />
        <EmptyState icon="alert-circle" title="यह पंडित नहीं मिले" subtitle="कृपया वापस जाकर दोबारा कोशिश करें।" />
      </View>
    );
  }

  return (
    <View style={styles.screen}>
      <BackBar title={pandit.name} />

      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={styles.scrollContent}>
        <View style={styles.hero}>
          <View style={styles.photoCircle}>
            <Text style={styles.photoEmoji}>{pandit.photoEmoji}</Text>
          </View>
          <Text style={styles.name}>{pandit.name}</Text>
          <Text style={styles.city}>{pandit.city}</Text>

          <View style={styles.ratingRow}>
            <Ionicons name="star" size={14} color={Colors.primary} />
            <Text style={styles.ratingText}>
              {pandit.rating.toFixed(1)} ({pandit.reviewCount} समीक्षाएं) • {pandit.experienceYears} वर्ष अनुभव
            </Text>
          </View>

          <View style={styles.availabilityBadge}>
            <View style={[styles.dot, { backgroundColor: pandit.isOnlineAvailable ? Colors.accentGreen : Colors.textSecondary }]} />
            <Text style={styles.availabilityText}>
              {pandit.isOnlineAvailable ? "ऑनलाइन परामर्श उपलब्ध" : "केवल ऑफलाइन पूजा"}
            </Text>
          </View>
        </View>

        <Section title="परिचय">
          <Text style={Typography.body}>{pandit.bio}</Text>
        </Section>

        <Section title="विशेषज्ञता">
          <View style={styles.chipsRow}>
            {pandit.specialties.map((s) => (
              <View key={s} style={styles.specialtyChip}>
                <Text style={styles.specialtyChipText}>{getPoojaTypeLabel(s)}</Text>
              </View>
            ))}
          </View>
        </Section>

        <Section title="भाषाएं">
          <View style={styles.chipsRow}>
            {pandit.languages.map((l) => (
              <View key={l} style={styles.languageChip}>
                <Text style={styles.languageChipText}>{l}</Text>
              </View>
            ))}
          </View>
        </Section>

        <Section title="उपलब्ध दिन">
          <View style={styles.chipsRow}>
            {pandit.availableDays.map((d) => (
              <View key={d} style={styles.dayChip}>
                <Text style={styles.dayChipText}>{d}</Text>
              </View>
            ))}
          </View>
        </Section>

        <Section title="शुल्क">
          <Text style={styles.price}>₹{pandit.startingPrice} से शुरू</Text>
          <Text style={Typography.bodySmall}>पूजा के प्रकार व अवधि के अनुसार शुल्क भिन्न हो सकता है।</Text>
        </Section>

        <View style={{ paddingHorizontal: Spacing.lg, marginTop: Spacing.md }}>
          <Button label="अभी बुक करें" onPress={() => router.push(`/booking/${pandit.id}`)} />
        </View>

        <View style={{ height: Spacing.xxxl }} />
      </ScrollView>
    </View>
  );
}

function BackBar({ title }: { title: string }) {
  return (
    <View style={styles.backBar}>
      <TouchableOpacity onPress={() => router.back()} style={styles.backButton} hitSlop={{ top: 10, bottom: 10, left: 10, right: 10 }}>
        <Ionicons name="chevron-back" size={24} color={Colors.textPrimary} />
      </TouchableOpacity>
      <Text style={styles.backBarTitle} numberOfLines={1}>
        {title}
      </Text>
      <View style={{ width: 24 }} />
    </View>
  );
}

function Section({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <View style={styles.section}>
      <Text style={styles.sectionTitle}>{title}</Text>
      {children}
    </View>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: Colors.background, paddingTop: 56 },
  scrollContent: { paddingBottom: Spacing.xxxl },
  backBar: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingHorizontal: Spacing.lg,
    paddingBottom: Spacing.md,
  },
  backButton: {
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: Colors.surface,
    alignItems: "center",
    justifyContent: "center",
    ...Shadow.card,
  },
  backBarTitle: {
    flex: 1,
    textAlign: "center",
    fontSize: 15,
    fontWeight: "700",
    color: Colors.textPrimary,
    marginHorizontal: Spacing.sm,
  },
  hero: {
    alignItems: "center",
    marginBottom: Spacing.lg,
  },
  photoCircle: {
    width: 88,
    height: 88,
    borderRadius: 44,
    backgroundColor: Colors.primaryLight,
    alignItems: "center",
    justifyContent: "center",
    marginBottom: Spacing.sm,
  },
  photoEmoji: { fontSize: 40 },
  name: { fontSize: 18, fontWeight: "700", color: Colors.textPrimary },
  city: { fontSize: 13, color: Colors.textSecondary, marginTop: 2 },
  ratingRow: {
    flexDirection: "row",
    alignItems: "center",
    marginTop: Spacing.sm,
  },
  ratingText: {
    fontSize: 12.5,
    fontWeight: "600",
    color: Colors.textPrimary,
    marginLeft: 4,
  },
  availabilityBadge: {
    flexDirection: "row",
    alignItems: "center",
    marginTop: Spacing.sm,
    backgroundColor: Colors.surface,
    paddingHorizontal: Spacing.md,
    paddingVertical: 6,
    borderRadius: Radius.pill,
    ...Shadow.card,
  },
  dot: { width: 8, height: 8, borderRadius: 4, marginRight: 6 },
  availabilityText: { fontSize: 11.5, fontWeight: "600", color: Colors.textPrimary },
  section: {
    paddingHorizontal: Spacing.lg,
    marginBottom: Spacing.lg,
  },
  sectionTitle: {
    fontSize: 15,
    fontWeight: "700",
    color: Colors.textPrimary,
    marginBottom: Spacing.sm,
  },
  chipsRow: {
    flexDirection: "row",
    flexWrap: "wrap",
  },
  specialtyChip: {
    backgroundColor: Colors.accentGreenBg,
    borderRadius: Radius.pill,
    paddingHorizontal: Spacing.md,
    paddingVertical: 6,
    marginRight: Spacing.xs,
    marginBottom: Spacing.xs,
  },
  specialtyChipText: { fontSize: 11.5, fontWeight: "600", color: Colors.accentGreen },
  languageChip: {
    backgroundColor: Colors.accentBlueBg,
    borderRadius: Radius.pill,
    paddingHorizontal: Spacing.md,
    paddingVertical: 6,
    marginRight: Spacing.xs,
    marginBottom: Spacing.xs,
  },
  languageChipText: { fontSize: 11.5, fontWeight: "600", color: Colors.accentBlue },
  dayChip: {
    backgroundColor: Colors.primaryLight,
    borderRadius: Radius.pill,
    paddingHorizontal: Spacing.md,
    paddingVertical: 6,
    marginRight: Spacing.xs,
    marginBottom: Spacing.xs,
  },
  dayChipText: { fontSize: 11.5, fontWeight: "600", color: Colors.primaryDark },
  price: { fontSize: 18, fontWeight: "700", color: Colors.secondary, marginBottom: 2 },
});
