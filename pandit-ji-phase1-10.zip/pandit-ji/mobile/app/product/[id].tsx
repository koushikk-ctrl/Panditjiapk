import React, { useState } from "react";
import { View, Text, ScrollView, StyleSheet, TouchableOpacity } from "react-native";
import { router, useLocalSearchParams } from "expo-router";
import { useQuery } from "@tanstack/react-query";
import { Ionicons } from "@expo/vector-icons";
import { Colors, Radius, Shadow, Spacing, Typography } from "@/constants/theme";
import Button from "@/components/Button";
import EmptyState from "@/components/EmptyState";
import { fetchProductById } from "@/services/storeService";
import { getDiscountedPrice } from "@/constants/productData";
import { useCart } from "@/hooks/useCart";

export default function ProductDetailScreen() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const [quantity, setQuantity] = useState(1);
  const { addToCart } = useCart();

  const { data: product, isLoading } = useQuery({
    queryKey: ["product", id],
    queryFn: () => fetchProductById(id as string),
    enabled: !!id,
  });

  if (isLoading) return <View style={styles.screen} />;

  if (!product) {
    return (
      <View style={styles.screen}>
        <BackBar title="" />
        <EmptyState icon="alert-circle" title="यह उत्पाद नहीं मिला" />
      </View>
    );
  }

  const discountedPrice = getDiscountedPrice(product);
  const inStock = product.stock > 0;

  const handleAddToCart = () => {
    addToCart(product.id, quantity);
  };

  const handleBuyNow = () => {
    addToCart(product.id, quantity);
    router.push("/cart");
  };

  return (
    <View style={styles.screen}>
      <BackBar title={product.name} />

      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={styles.scrollContent}>
        <View style={styles.imageWrap}>
          <Text style={styles.emoji}>{product.emoji}</Text>
        </View>

        <View style={styles.infoBlock}>
          <Text style={styles.name}>{product.name}</Text>
          <Text style={styles.unit}>{product.unit}</Text>

          <View style={styles.ratingRow}>
            <Ionicons name="star" size={14} color={Colors.primary} />
            <Text style={styles.ratingText}>
              {product.rating.toFixed(1)} ({product.reviewCount} समीक्षाएं)
            </Text>
          </View>

          <View style={styles.priceRow}>
            <Text style={styles.price}>₹{discountedPrice}</Text>
            {product.discountPercent > 0 ? (
              <>
                <Text style={styles.originalPrice}>₹{product.price}</Text>
                <View style={styles.discountBadge}>
                  <Text style={styles.discountBadgeText}>{product.discountPercent}% छूट</Text>
                </View>
              </>
            ) : null}
          </View>

          <Text style={[styles.stockText, { color: inStock ? Colors.accentGreen : Colors.error }]}>
            {inStock ? `स्टॉक में (${product.stock} उपलब्ध)` : "स्टॉक में नहीं"}
          </Text>
        </View>

        <Section title="विवरण">
          <Text style={Typography.body}>{product.description}</Text>
        </Section>

        {product.reviews.length > 0 ? (
          <Section title="समीक्षाएं">
            {product.reviews.map((r, i) => (
              <View key={i} style={styles.reviewCard}>
                <View style={styles.reviewTopRow}>
                  <Text style={styles.reviewName}>{r.name}</Text>
                  <View style={styles.reviewRatingRow}>
                    <Ionicons name="star" size={12} color={Colors.primary} />
                    <Text style={styles.reviewRating}>{r.rating}</Text>
                  </View>
                </View>
                <Text style={styles.reviewComment}>{r.comment}</Text>
              </View>
            ))}
          </Section>
        ) : null}

        <View style={{ height: 100 }} />
      </ScrollView>

      {/* Sticky bottom action bar */}
      <View style={styles.bottomBar}>
        <View style={styles.quantityStepper}>
          <TouchableOpacity
            style={styles.stepperButton}
            onPress={() => setQuantity((q) => Math.max(1, q - 1))}
            hitSlop={{ top: 10, bottom: 10, left: 10, right: 10 }}
          >
            <Ionicons name="remove" size={16} color={Colors.textPrimary} />
          </TouchableOpacity>
          <Text style={styles.quantityText}>{quantity}</Text>
          <TouchableOpacity
            style={styles.stepperButton}
            onPress={() => setQuantity((q) => q + 1)}
            hitSlop={{ top: 10, bottom: 10, left: 10, right: 10 }}
          >
            <Ionicons name="add" size={16} color={Colors.textPrimary} />
          </TouchableOpacity>
        </View>
        <Button label="कार्ट में जोड़ें" variant="outline" onPress={handleAddToCart} disabled={!inStock} style={{ flex: 1, marginRight: Spacing.sm }} />
        <Button label="अभी खरीदें" onPress={handleBuyNow} disabled={!inStock} style={{ flex: 1 }} />
      </View>
    </View>
  );
}

function BackBar({ title }: { title: string }) {
  return (
    <View style={styles.backBar}>
      <TouchableOpacity onPress={() => router.back()} style={styles.backButton} hitSlop={{ top: 10, bottom: 10, left: 10, right: 10 }}>
        <Ionicons name="chevron-back" size={24} color={Colors.textPrimary} />
      </TouchableOpacity>
      <Text style={styles.backBarTitle} numberOfLines={1}>
        {title}
      </Text>
      <View style={{ width: 24 }} />
    </View>
  );
}

function Section({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <View style={styles.section}>
      <Text style={styles.sectionTitle}>{title}</Text>
      {children}
    </View>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: Colors.background, paddingTop: 56 },
  scrollContent: { paddingBottom: Spacing.md },
  backBar: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingHorizontal: Spacing.lg,
    paddingBottom: Spacing.md,
  },
  backButton: {
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: Colors.surface,
    alignItems: "center",
    justifyContent: "center",
    ...Shadow.card,
  },
  backBarTitle: {
    flex: 1,
    textAlign: "center",
    fontSize: 15,
    fontWeight: "700",
    color: Colors.textPrimary,
    marginHorizontal: Spacing.sm,
  },
  imageWrap: {
    alignItems: "center",
    justifyContent: "center",
    height: 180,
    backgroundColor: Colors.primaryLight,
    marginHorizontal: Spacing.lg,
    borderRadius: Radius.lg,
    marginBottom: Spacing.lg,
  },
  emoji: { fontSize: 72 },
  infoBlock: {
    paddingHorizontal: Spacing.lg,
    marginBottom: Spacing.lg,
  },
  name: { fontSize: 18, fontWeight: "700", color: Colors.textPrimary },
  unit: { fontSize: 12.5, color: Colors.textSecondary, marginTop: 2 },
  ratingRow: {
    flexDirection: "row",
    alignItems: "center",
    marginTop: Spacing.sm,
  },
  ratingText: {
    fontSize: 12.5,
    fontWeight: "600",
    color: Colors.textPrimary,
    marginLeft: 4,
  },
  priceRow: {
    flexDirection: "row",
    alignItems: "center",
    marginTop: Spacing.sm,
  },
  price: {
    fontSize: 22,
    fontWeight: "700",
    color: Colors.secondary,
    marginRight: Spacing.sm,
  },
  originalPrice: {
    fontSize: 14,
    color: Colors.textSecondary,
    textDecorationLine: "line-through",
    marginRight: Spacing.sm,
  },
  discountBadge: {
    backgroundColor: Colors.accentPink,
    borderRadius: Radius.pill,
    paddingHorizontal: Spacing.sm,
    paddingVertical: 3,
  },
  discountBadgeText: { fontSize: 11, fontWeight: "700", color: "#FFFFFF" },
  stockText: {
    fontSize: 12.5,
    fontWeight: "600",
    marginTop: Spacing.sm,
  },
  section: {
    paddingHorizontal: Spacing.lg,
    marginBottom: Spacing.lg,
  },
  sectionTitle: {
    fontSize: 15,
    fontWeight: "700",
    color: Colors.textPrimary,
    marginBottom: Spacing.sm,
  },
  reviewCard: {
    backgroundColor: Colors.surface,
    borderRadius: Radius.md,
    padding: Spacing.md,
    marginBottom: Spacing.sm,
    ...Shadow.card,
  },
  reviewTopRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    marginBottom: 4,
  },
  reviewName: { fontSize: 13, fontWeight: "700", color: Colors.textPrimary },
  reviewRatingRow: { flexDirection: "row", alignItems: "center" },
  reviewRating: { fontSize: 12, fontWeight: "600", color: Colors.textPrimary, marginLeft: 3 },
  reviewComment: { fontSize: 12.5, color: Colors.textSecondary, lineHeight: 17 },
  bottomBar: {
    position: "absolute",
    bottom: 0,
    left: 0,
    right: 0,
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: Colors.surface,
    paddingHorizontal: Spacing.lg,
    paddingTop: Spacing.md,
    paddingBottom: Spacing.xl,
    borderTopWidth: 1,
    borderTopColor: Colors.border,
  },
  quantityStepper: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: Colors.background,
    borderRadius: Radius.pill,
    paddingHorizontal: Spacing.xs,
    marginRight: Spacing.md,
  },
  stepperButton: {
    width: 30,
    height: 30,
    alignItems: "center",
    justifyContent: "center",
  },
  quantityText: {
    fontSize: 14,
    fontWeight: "700",
    color: Colors.textPrimary,
    minWidth: 22,
    textAlign: "center",
  },
});
