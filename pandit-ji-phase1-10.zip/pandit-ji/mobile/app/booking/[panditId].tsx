import React, { useState } from "react";
import { View, Text, ScrollView, StyleSheet, TouchableOpacity } from "react-native";
import { router, useLocalSearchParams } from "expo-router";
import { Ionicons } from "@expo/vector-icons";
import { Colors, Radius, Shadow, Spacing, Typography } from "@/constants/theme";
import FormField from "@/components/FormField";
import Button from "@/components/Button";
import EmptyState from "@/components/EmptyState";
import { getPanditById } from "@/constants/panditData";
import { poojaTypes } from "@/constants/poojaTypesData";
import { useBookings } from "@/hooks/useBookings";

export default function BookingFormScreen() {
  const { panditId } = useLocalSearchParams<{ panditId: string }>();
  const pandit = getPanditById(panditId);
  const { addBooking } = useBookings();

  const [poojaTypeId, setPoojaTypeId] = useState<string | null>(null);
  const [date, setDate] = useState("");
  const [time, setTime] = useState("");
  const [location, setLocation] = useState("");
  const [instructions, setInstructions] = useState("");
  const [submitted, setSubmitted] = useState(false);

  if (!pandit) {
    return (
      <View style={styles.screen}>
        <BackBar title="" />
        <EmptyState icon="alert-circle" title="यह पंडित नहीं मिले" />
      </View>
    );
  }

  const selectedType = poojaTypes.find((t) => t.id === poojaTypeId);
  const isValid = poojaTypeId && date.trim() && time.trim() && location.trim();

  const handleSubmit = () => {
    if (!isValid || !selectedType) return;
    addBooking({
      panditId: pandit.id,
      panditName: pandit.name,
      poojaTypeId: selectedType.id,
      poojaTypeLabel: selectedType.label,
      date,
      time,
      location,
      instructions,
      price: pandit.startingPrice,
    });
    setSubmitted(true);
  };

  if (submitted) {
    return (
      <View style={styles.screen}>
        <BackBar title="बुकिंग की पुष्टि" />
        <View style={styles.successWrap}>
          <View style={styles.successIcon}>
            <Ionicons name="checkmark" size={40} color="#FFFFFF" />
          </View>
          <Text style={styles.successTitle}>आपकी बुकिंग दर्ज हो गई है</Text>
          <Text style={styles.successSubtitle}>
            {pandit.name} जल्द ही आपकी {selectedType?.label} बुकिंग की पुष्टि करेंगे। स्थिति "लंबित" दिखाई देगी जब तक पुष्टि नहीं होती।
          </Text>
          <Button label="मेरी बुकिंग्स देखें" onPress={() => router.replace("/bookings")} style={{ marginTop: Spacing.xl, width: "100%" }} />
          <Button
            label="वापस पंडित सूची पर जाएं"
            variant="ghost"
            onPress={() => router.replace("/(tabs)/pandit")}
            style={{ marginTop: Spacing.md, width: "100%" }}
          />
        </View>
      </View>
    );
  }

  return (
    <View style={styles.screen}>
      <BackBar title={`${pandit.name} — बुकिंग`} />

      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={styles.scrollContent}>
        <Text style={styles.label}>पूजा का प्रकार</Text>
        <View style={styles.typeGrid}>
          {poojaTypes.map((t) => {
            const isActive = poojaTypeId === t.id;
            return (
              <TouchableOpacity
                key={t.id}
                style={[styles.typeChip, isActive && styles.typeChipActive]}
                onPress={() => setPoojaTypeId(t.id)}
                activeOpacity={0.75}
              >
                <Text style={styles.typeEmoji}>{t.icon}</Text>
                <Text style={[styles.typeLabel, isActive && styles.typeLabelActive]}>{t.label}</Text>
              </TouchableOpacity>
            );
          })}
        </View>

        <FormField label="तारीख (DD/MM/YYYY)" placeholder="उदाहरण: 12/10/2026" value={date} onChangeText={setDate} />
        <FormField label="समय" placeholder="उदाहरण: सुबह 09:00" value={time} onChangeText={setTime} />
        <FormField label="स्थान / पता" placeholder="पूजा किस पते पर करानी है?" value={location} onChangeText={setLocation} />
        <FormField
          label="विशेष निर्देश (वैकल्पिक)"
          placeholder="कोई विशेष आवश्यकता हो तो लिखें..."
          value={instructions}
          onChangeText={setInstructions}
          multiline
          numberOfLines={3}
          style={{ height: 80, textAlignVertical: "top" }}
        />

        <View style={styles.priceRow}>
          <Text style={Typography.bodySmall}>अनुमानित शुल्क</Text>
          <Text style={styles.priceValue}>₹{pandit.startingPrice}+</Text>
        </View>

        <Button label="बुकिंग की पुष्टि करें" onPress={handleSubmit} disabled={!isValid} style={{ marginTop: Spacing.md }} />
      </ScrollView>
    </View>
  );
}

function BackBar({ title }: { title: string }) {
  return (
    <View style={styles.backBar}>
      <TouchableOpacity onPress={() => router.back()} style={styles.backButton} hitSlop={{ top: 10, bottom: 10, left: 10, right: 10 }}>
        <Ionicons name="chevron-back" size={24} color={Colors.textPrimary} />
      </TouchableOpacity>
      <Text style={styles.backBarTitle} numberOfLines={1}>
        {title}
      </Text>
      <View style={{ width: 24 }} />
    </View>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: Colors.background, paddingTop: 56 },
  backBar: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingHorizontal: Spacing.lg,
    paddingBottom: Spacing.md,
  },
  backButton: {
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: Colors.surface,
    alignItems: "center",
    justifyContent: "center",
    ...Shadow.card,
  },
  backBarTitle: {
    flex: 1,
    textAlign: "center",
    fontSize: 15,
    fontWeight: "700",
    color: Colors.textPrimary,
    marginHorizontal: Spacing.sm,
  },
  scrollContent: {
    paddingHorizontal: Spacing.lg,
    paddingBottom: Spacing.xxxl,
  },
  label: {
    fontSize: 13,
    fontWeight: "600",
    color: Colors.textPrimary,
    marginBottom: Spacing.sm,
  },
  typeGrid: {
    flexDirection: "row",
    flexWrap: "wrap",
    marginBottom: Spacing.md,
  },
  typeChip: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: Colors.surface,
    borderWidth: 1,
    borderColor: Colors.border,
    borderRadius: Radius.pill,
    paddingHorizontal: Spacing.md,
    paddingVertical: 8,
    marginRight: Spacing.sm,
    marginBottom: Spacing.sm,
  },
  typeChipActive: {
    backgroundColor: Colors.primary,
    borderColor: Colors.primary,
  },
  typeEmoji: { fontSize: 14, marginRight: 5 },
  typeLabel: { fontSize: 12.5, fontWeight: "600", color: Colors.textPrimary },
  typeLabelActive: { color: "#FFFFFF" },
  priceRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    marginTop: Spacing.md,
    marginBottom: Spacing.sm,
  },
  priceValue: {
    fontSize: 16,
    fontWeight: "700",
    color: Colors.secondary,
  },
  successWrap: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
    paddingHorizontal: Spacing.xl,
  },
  successIcon: {
    width: 72,
    height: 72,
    borderRadius: 36,
    backgroundColor: Colors.accentGreen,
    alignItems: "center",
    justifyContent: "center",
    marginBottom: Spacing.lg,
  },
  successTitle: {
    fontSize: 17,
    fontWeight: "700",
    color: Colors.textPrimary,
    textAlign: "center",
  },
  successSubtitle: {
    fontSize: 13,
    color: Colors.textSecondary,
    textAlign: "center",
    marginTop: Spacing.sm,
    lineHeight: 19,
  },
});
