import React from "react";
import { View, Text, ScrollView, StyleSheet, TouchableOpacity, ActivityIndicator } from "react-native";
import { router } from "expo-router";
import { useQuery } from "@tanstack/react-query";
import { Ionicons } from "@expo/vector-icons";
import { Colors, Radius, Shadow, Spacing } from "@/constants/theme";
import Card from "@/components/Card";
import DemoDataBanner from "@/components/DemoDataBanner";
import { fetchTodayPanchang } from "@/services/astrologyService";

export default function PanchangScreen() {
  const { data: panchang, isLoading } = useQuery({
    queryKey: ["panchang", "today"],
    queryFn: fetchTodayPanchang,
  });

  return (
    <View style={styles.screen}>
      <View style={styles.backBar}>
        <TouchableOpacity
          onPress={() => router.back()}
          style={styles.backButton}
          hitSlop={{ top: 10, bottom: 10, left: 10, right: 10 }}
        >
          <Ionicons name="chevron-back" size={24} color={Colors.textPrimary} />
        </TouchableOpacity>
        <Text style={styles.backBarTitle}>आज का पंचांग</Text>
        <View style={{ width: 24 }} />
      </View>

      {isLoading || !panchang ? (
        <View style={styles.centerWrap}>
          <ActivityIndicator color={Colors.primary} size="large" />
        </View>
      ) : (
        <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={styles.scrollContent}>
          <DemoDataBanner />

          <Card style={styles.dateCard} backgroundColor={Colors.secondary}>
            <Text style={styles.dateText}>{panchang.date}</Text>
            <Text style={styles.pakshaText}>{panchang.paksha}</Text>
          </Card>

          <View style={styles.grid}>
            <PanchangTile label="तिथि" value={panchang.tithi} color={Colors.primaryLight} />
            <PanchangTile label="नक्षत्र" value={panchang.nakshatra} color={Colors.accentBlueBg} />
            <PanchangTile label="योग" value={panchang.yoga} color={Colors.accentGreenBg} />
            <PanchangTile label="करण" value={panchang.karana} color={Colors.accentPurpleBg} />
          </View>

          <Card style={{ marginTop: Spacing.md }}>
            <Row icon="sunny" label="सूर्योदय" value={panchang.sunrise} />
            <Row icon="moon" label="सूर्यास्त" value={panchang.sunset} />
            <Row icon="alert-circle" label="राहु काल" value={panchang.rahuKaal} isWarning />
            <Row icon="star" label="अभिजीत मुहूर्त" value={panchang.abhijitMuhurat} isLast />
          </Card>
        </ScrollView>
      )}
    </View>
  );
}

function PanchangTile({ label, value, color }: { label: string; value: string; color: string }) {
  return (
    <View style={[styles.tile, { backgroundColor: color }]}>
      <Text style={styles.tileLabel}>{label}</Text>
      <Text style={styles.tileValue} numberOfLines={2}>
        {value}
      </Text>
    </View>
  );
}

function Row({
  icon,
  label,
  value,
  isWarning,
  isLast,
}: {
  icon: keyof typeof Ionicons.glyphMap;
  label: string;
  value: string;
  isWarning?: boolean;
  isLast?: boolean;
}) {
  return (
    <View style={[styles.row, !isLast && styles.rowBorder]}>
      <Ionicons name={icon} size={18} color={isWarning ? Colors.error : Colors.primary} />
      <Text style={styles.rowLabel}>{label}</Text>
      <Text style={[styles.rowValue, isWarning && { color: Colors.error }]}>{value}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  screen: {
    flex: 1,
    backgroundColor: Colors.background,
    paddingTop: 56,
  },
  centerWrap: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
  },
  backBar: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingHorizontal: Spacing.lg,
    paddingBottom: Spacing.md,
  },
  backButton: {
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: Colors.surface,
    alignItems: "center",
    justifyContent: "center",
    ...Shadow.card,
  },
  backBarTitle: {
    flex: 1,
    textAlign: "center",
    fontSize: 15,
    fontWeight: "700",
    color: Colors.textPrimary,
  },
  scrollContent: {
    paddingHorizontal: Spacing.lg,
    paddingBottom: Spacing.xxxl,
  },
  dateCard: {
    alignItems: "center",
    marginBottom: Spacing.lg,
  },
  dateText: {
    color: "#FFFFFF",
    fontSize: 16,
    fontWeight: "700",
  },
  pakshaText: {
    color: "#F0D9CF",
    fontSize: 12,
    marginTop: 4,
  },
  grid: {
    flexDirection: "row",
    flexWrap: "wrap",
    justifyContent: "space-between",
  },
  tile: {
    width: "48%",
    borderRadius: Radius.md,
    padding: Spacing.md,
    marginBottom: Spacing.md,
  },
  tileLabel: {
    fontSize: 11,
    color: Colors.textSecondary,
    marginBottom: 4,
  },
  tileValue: {
    fontSize: 13.5,
    fontWeight: "700",
    color: Colors.textPrimary,
  },
  row: {
    flexDirection: "row",
    alignItems: "center",
    paddingVertical: Spacing.sm,
  },
  rowBorder: {
    borderBottomWidth: 1,
    borderBottomColor: Colors.border,
  },
  rowLabel: {
    flex: 1,
    fontSize: 13.5,
    fontWeight: "600",
    color: Colors.textPrimary,
    marginLeft: Spacing.sm,
  },
  rowValue: {
    fontSize: 13,
    fontWeight: "700",
    color: Colors.textPrimary,
  },
});
