import React from "react";
import { View, Text, ScrollView, StyleSheet, TouchableOpacity } from "react-native";
import { router } from "expo-router";
import { Ionicons } from "@expo/vector-icons";
import { Colors, Shadow, Spacing, Typography } from "@/constants/theme";
import FeatureCard from "@/components/FeatureCard";

export default function JyotishHubScreen() {
  return (
    <View style={styles.screen}>
      <View style={styles.backBar}>
        <TouchableOpacity
          onPress={() => router.back()}
          style={styles.backButton}
          hitSlop={{ top: 10, bottom: 10, left: 10, right: 10 }}
        >
          <Ionicons name="chevron-back" size={24} color={Colors.textPrimary} />
        </TouchableOpacity>
        <Text style={styles.backBarTitle}>ज्योतिष</Text>
        <View style={{ width: 24 }} />
      </View>

      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={styles.scrollContent}>
        <Text style={[Typography.bodySmall, styles.subheading]}>अपने भविष्य को जानें, सही दिशा पाएं</Text>

        <View style={styles.grid}>
          <FeatureCard
            title="जन्म कुंडली"
            subtitle="नाम, जन्म तिथि व समय से"
            icon="person-circle"
            backgroundColor={Colors.accentPurpleBg}
            accentColor={Colors.accentPurple}
            onPress={() => router.push("/jyotish/kundli")}
          />
          <FeatureCard
            title="पंचांग"
            subtitle="तिथि, नक्षत्र, योग, मुहूर्त"
            icon="calendar"
            backgroundColor={Colors.accentBlueBg}
            accentColor={Colors.accentBlue}
            onPress={() => router.push("/jyotish/panchang")}
          />
          <FeatureCard
            title="मुहूर्त"
            subtitle="शुभ कार्यों हेतु उत्तम समय"
            icon="time"
            backgroundColor={Colors.primaryLight}
            accentColor={Colors.primary}
            onPress={() => router.push("/jyotish/muhurat")}
          />
          <FeatureCard
            title="नक्षत्र सीखें"
            subtitle="27 नक्षत्रों का परिचय"
            icon="planet"
            backgroundColor={Colors.accentGreenBg}
            accentColor={Colors.accentGreen}
            onPress={() => router.push("/jyotish/nakshatra")}
          />
        </View>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  screen: {
    flex: 1,
    backgroundColor: Colors.background,
    paddingTop: 56,
  },
  backBar: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingHorizontal: Spacing.lg,
    paddingBottom: Spacing.md,
  },
  backButton: {
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: Colors.surface,
    alignItems: "center",
    justifyContent: "center",
    ...Shadow.card,
  },
  backBarTitle: {
    flex: 1,
    textAlign: "center",
    fontSize: 15,
    fontWeight: "700",
    color: Colors.textPrimary,
  },
  scrollContent: {
    paddingBottom: Spacing.xxxl,
  },
  subheading: {
    textAlign: "center",
    marginBottom: Spacing.lg,
  },
  grid: {
    flexDirection: "row",
    flexWrap: "wrap",
    justifyContent: "space-between",
    paddingHorizontal: Spacing.lg,
  },
});
