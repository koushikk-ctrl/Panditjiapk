import React from "react";
import { View, Text, ScrollView, StyleSheet, TouchableOpacity, ActivityIndicator } from "react-native";
import { router } from "expo-router";
import { useQuery } from "@tanstack/react-query";
import { Ionicons } from "@expo/vector-icons";
import { Colors, Radius, Shadow, Spacing } from "@/constants/theme";
import DemoDataBanner from "@/components/DemoDataBanner";
import { fetchUpcomingMuhurats } from "@/services/astrologyService";

export default function MuhuratScreen() {
  const { data: muhurats, isLoading } = useQuery({
    queryKey: ["muhurats"],
    queryFn: fetchUpcomingMuhurats,
  });

  return (
    <View style={styles.screen}>
      <View style={styles.backBar}>
        <TouchableOpacity
          onPress={() => router.back()}
          style={styles.backButton}
          hitSlop={{ top: 10, bottom: 10, left: 10, right: 10 }}
        >
          <Ionicons name="chevron-back" size={24} color={Colors.textPrimary} />
        </TouchableOpacity>
        <Text style={styles.backBarTitle}>शुभ मुहूर्त</Text>
        <View style={{ width: 24 }} />
      </View>

      {isLoading || !muhurats ? (
        <View style={styles.centerWrap}>
          <ActivityIndicator color={Colors.primary} size="large" />
        </View>
      ) : (
        <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={styles.scrollContent}>
          <DemoDataBanner />
          {muhurats.map((m) => (
            <View key={m.id} style={styles.card}>
              <View style={styles.emojiCircle}>
                <Text style={styles.emoji}>{m.icon}</Text>
              </View>
              <View style={{ flex: 1, marginLeft: Spacing.md }}>
                <Text style={styles.purpose}>{m.purpose}</Text>
                <Text style={styles.date}>{m.date}</Text>
                <Text style={styles.time}>{m.timeWindow}</Text>
                <Text style={styles.note}>{m.note}</Text>
              </View>
            </View>
          ))}
        </ScrollView>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  screen: {
    flex: 1,
    backgroundColor: Colors.background,
    paddingTop: 56,
  },
  centerWrap: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
  },
  backBar: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingHorizontal: Spacing.lg,
    paddingBottom: Spacing.md,
  },
  backButton: {
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: Colors.surface,
    alignItems: "center",
    justifyContent: "center",
    ...Shadow.card,
  },
  backBarTitle: {
    flex: 1,
    textAlign: "center",
    fontSize: 15,
    fontWeight: "700",
    color: Colors.textPrimary,
  },
  scrollContent: {
    paddingHorizontal: Spacing.lg,
    paddingBottom: Spacing.xxxl,
  },
  card: {
    flexDirection: "row",
    backgroundColor: Colors.surface,
    borderRadius: Radius.lg,
    padding: Spacing.md,
    marginBottom: Spacing.md,
    ...Shadow.card,
  },
  emojiCircle: {
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: Colors.primaryLight,
    alignItems: "center",
    justifyContent: "center",
  },
  emoji: { fontSize: 20 },
  purpose: {
    fontSize: 15,
    fontWeight: "700",
    color: Colors.textPrimary,
  },
  date: {
    fontSize: 12.5,
    fontWeight: "600",
    color: Colors.primaryDark,
    marginTop: 2,
  },
  time: {
    fontSize: 12,
    color: Colors.textSecondary,
    marginTop: 2,
  },
  note: {
    fontSize: 11.5,
    color: Colors.textSecondary,
    marginTop: 4,
    lineHeight: 15,
  },
});
