import React, { useState } from "react";
import { View, Text, ScrollView, StyleSheet, TouchableOpacity, ActivityIndicator } from "react-native";
import { router } from "expo-router";
import { useMutation } from "@tanstack/react-query";
import { Ionicons } from "@expo/vector-icons";
import { Colors, Radius, Shadow, Spacing, Typography } from "@/constants/theme";
import FormField from "@/components/FormField";
import Button from "@/components/Button";
import DemoDataBanner from "@/components/DemoDataBanner";
import Card from "@/components/Card";
import { generateKundli } from "@/services/astrologyService";
import { KundliInput } from "@/constants/astrologyData";

export default function KundliScreen() {
  const [form, setForm] = useState<KundliInput>({ name: "", dob: "", tob: "", place: "" });

  const mutation = useMutation({
    mutationFn: (input: KundliInput) => generateKundli(input),
  });

  const isFormValid = form.name.trim() && form.dob.trim() && form.tob.trim() && form.place.trim();

  const updateField = (key: keyof KundliInput, value: string) => {
    setForm((prev) => ({ ...prev, [key]: value }));
  };

  return (
    <View style={styles.screen}>
      <View style={styles.backBar}>
        <TouchableOpacity
          onPress={() => router.back()}
          style={styles.backButton}
          hitSlop={{ top: 10, bottom: 10, left: 10, right: 10 }}
        >
          <Ionicons name="chevron-back" size={24} color={Colors.textPrimary} />
        </TouchableOpacity>
        <Text style={styles.backBarTitle}>जन्म कुंडली</Text>
        <View style={{ width: 24 }} />
      </View>

      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={styles.scrollContent}>
        <DemoDataBanner message="यह एक उदाहरण फॉर्म है। कुंडली परिणाम डेमो है — सटीक गणना हेतु भविष्य में प्रमाणित ज्योतिष API जोड़ी जाएगी।" />

        <FormField
          label="नाम"
          placeholder="अपना पूरा नाम दर्ज करें"
          value={form.name}
          onChangeText={(v) => updateField("name", v)}
        />
        <FormField
          label="जन्म तिथि (DD/MM/YYYY)"
          placeholder="उदाहरण: 15/08/1995"
          value={form.dob}
          onChangeText={(v) => updateField("dob", v)}
          keyboardType="numbers-and-punctuation"
        />
        <FormField
          label="जन्म समय (HH:MM)"
          placeholder="उदाहरण: 06:30"
          value={form.tob}
          onChangeText={(v) => updateField("tob", v)}
          keyboardType="numbers-and-punctuation"
        />
        <FormField
          label="जन्म स्थान"
          placeholder="उदाहरण: इंदौर, मध्य प्रदेश"
          value={form.place}
          onChangeText={(v) => updateField("place", v)}
        />

        <Button
          label={mutation.isPending ? "गणना हो रही है..." : "कुंडली देखें"}
          onPress={() => mutation.mutate(form)}
          disabled={!isFormValid || mutation.isPending}
          style={{ marginTop: Spacing.sm }}
        />

        {mutation.isPending ? (
          <View style={{ marginTop: Spacing.xl, alignItems: "center" }}>
            <ActivityIndicator color={Colors.primary} />
          </View>
        ) : null}

        {mutation.isSuccess ? (
          <View style={styles.resultWrap}>
            <Text style={styles.resultTitle}>{form.name} की कुंडली (उदाहरण)</Text>

            <View style={styles.resultGrid}>
              <ResultTile label="राशि" value={mutation.data.rashi} color={Colors.primaryLight} />
              <ResultTile label="जन्म नक्षत्र" value={mutation.data.nakshatra} color={Colors.accentBlueBg} />
              <ResultTile label="लग्न" value={mutation.data.lagna} color={Colors.accentGreenBg} />
              <ResultTile label="नक्षत्र पद" value={String(mutation.data.nakshatraPada)} color={Colors.accentPurpleBg} />
            </View>

            <Card backgroundColor={Colors.accentPinkBg} style={{ marginTop: Spacing.md }}>
              <Text style={Typography.bodySmall}>{mutation.data.summary}</Text>
            </Card>
          </View>
        ) : null}
      </ScrollView>
    </View>
  );
}

function ResultTile({ label, value, color }: { label: string; value: string; color: string }) {
  return (
    <View style={[styles.resultTile, { backgroundColor: color }]}>
      <Text style={styles.resultTileLabel}>{label}</Text>
      <Text style={styles.resultTileValue}>{value}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  screen: {
    flex: 1,
    backgroundColor: Colors.background,
    paddingTop: 56,
  },
  backBar: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingHorizontal: Spacing.lg,
    paddingBottom: Spacing.md,
  },
  backButton: {
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: Colors.surface,
    alignItems: "center",
    justifyContent: "center",
    ...Shadow.card,
  },
  backBarTitle: {
    flex: 1,
    textAlign: "center",
    fontSize: 15,
    fontWeight: "700",
    color: Colors.textPrimary,
  },
  scrollContent: {
    paddingHorizontal: Spacing.lg,
    paddingBottom: Spacing.xxxl,
  },
  resultWrap: {
    marginTop: Spacing.xl,
  },
  resultTitle: {
    fontSize: 16,
    fontWeight: "700",
    color: Colors.textPrimary,
    marginBottom: Spacing.md,
  },
  resultGrid: {
    flexDirection: "row",
    flexWrap: "wrap",
    justifyContent: "space-between",
  },
  resultTile: {
    width: "48%",
    borderRadius: Radius.md,
    padding: Spacing.md,
    marginBottom: Spacing.md,
  },
  resultTileLabel: {
    fontSize: 11,
    color: Colors.textSecondary,
    marginBottom: 4,
  },
  resultTileValue: {
    fontSize: 14,
    fontWeight: "700",
    color: Colors.textPrimary,
  },
});
