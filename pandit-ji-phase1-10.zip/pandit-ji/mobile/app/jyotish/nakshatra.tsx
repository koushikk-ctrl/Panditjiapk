import React from "react";
import { View, Text, ScrollView, StyleSheet, TouchableOpacity } from "react-native";
import { router } from "expo-router";
import { Ionicons } from "@expo/vector-icons";
import { Colors, Radius, Shadow, Spacing, Typography } from "@/constants/theme";
import { nakshatraLearning } from "@/constants/astrologyData";

export default function NakshatraLearnScreen() {
  return (
    <View style={styles.screen}>
      <View style={styles.backBar}>
        <TouchableOpacity
          onPress={() => router.back()}
          style={styles.backButton}
          hitSlop={{ top: 10, bottom: 10, left: 10, right: 10 }}
        >
          <Ionicons name="chevron-back" size={24} color={Colors.textPrimary} />
        </TouchableOpacity>
        <Text style={styles.backBarTitle}>नक्षत्र सीखें</Text>
        <View style={{ width: 24 }} />
      </View>

      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={styles.scrollContent}>
        <Text style={[Typography.bodySmall, styles.subheading]}>
          वैदिक ज्योतिष में 27 नक्षत्र होते हैं — यहां कुछ प्रमुख नक्षत्रों का संक्षिप्त परिचय दिया गया है।
        </Text>

        {nakshatraLearning.map((n) => (
          <View key={n.name} style={styles.card}>
            <View style={styles.nameRow}>
              <Text style={styles.name}>{n.name}</Text>
              <View style={styles.lordBadge}>
                <Text style={styles.lordText}>स्वामी: {n.lord}</Text>
              </View>
            </View>
            <Text style={styles.meaning}>{n.meaning}</Text>
          </View>
        ))}
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  screen: {
    flex: 1,
    backgroundColor: Colors.background,
    paddingTop: 56,
  },
  backBar: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingHorizontal: Spacing.lg,
    paddingBottom: Spacing.md,
  },
  backButton: {
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: Colors.surface,
    alignItems: "center",
    justifyContent: "center",
    ...Shadow.card,
  },
  backBarTitle: {
    flex: 1,
    textAlign: "center",
    fontSize: 15,
    fontWeight: "700",
    color: Colors.textPrimary,
  },
  scrollContent: {
    paddingHorizontal: Spacing.lg,
    paddingBottom: Spacing.xxxl,
  },
  subheading: {
    marginBottom: Spacing.lg,
    lineHeight: 18,
  },
  card: {
    backgroundColor: Colors.surface,
    borderRadius: Radius.md,
    padding: Spacing.md,
    marginBottom: Spacing.sm,
    ...Shadow.card,
  },
  nameRow: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    marginBottom: Spacing.xs,
  },
  name: {
    fontSize: 15,
    fontWeight: "700",
    color: Colors.textPrimary,
  },
  lordBadge: {
    backgroundColor: Colors.accentPurpleBg,
    borderRadius: Radius.pill,
    paddingHorizontal: Spacing.sm,
    paddingVertical: 3,
  },
  lordText: {
    fontSize: 10.5,
    fontWeight: "700",
    color: Colors.accentPurple,
  },
  meaning: {
    fontSize: 12.5,
    color: Colors.textSecondary,
    lineHeight: 17,
  },
});
