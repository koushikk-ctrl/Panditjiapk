import React from "react";
import { View, Text, StyleSheet } from "react-native";
import { Ionicons } from "@expo/vector-icons";
import { Colors, Radius, Spacing } from "@/constants/theme";

type DemoDataBannerProps = {
  message?: string;
};

export default function DemoDataBanner({
  message = "यह डेमो डेटा है। सटीक गणना हेतु भविष्य में प्रमाणित ज्योतिष API जोड़ी जाएगी।",
}: DemoDataBannerProps) {
  return (
    <View style={styles.banner}>
      <Ionicons name="information-circle" size={16} color={Colors.accentBlue} />
      <Text style={styles.text}>{message}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  banner: {
    flexDirection: "row",
    alignItems: "flex-start",
    backgroundColor: Colors.accentBlueBg,
    borderRadius: Radius.md,
    padding: Spacing.md,
    marginHorizontal: Spacing.lg,
    marginBottom: Spacing.lg,
  },
  text: {
    flex: 1,
    fontSize: 11.5,
    color: Colors.textPrimary,
    marginLeft: Spacing.sm,
    lineHeight: 16,
  },
});
