import React from "react";
import { View, Text, TouchableOpacity, StyleSheet } from "react-native";
import { Ionicons } from "@expo/vector-icons";
import { Colors, Radius, Shadow, Spacing } from "@/constants/theme";

type CartItemRowProps = {
  name: string;
  emoji: string;
  unit: string;
  unitPrice: number;
  quantity: number;
  lineTotal: number;
  onIncrease: () => void;
  onDecrease: () => void;
  onRemove: () => void;
};

export default function CartItemRow({
  name,
  emoji,
  unit,
  unitPrice,
  quantity,
  lineTotal,
  onIncrease,
  onDecrease,
  onRemove,
}: CartItemRowProps) {
  return (
    <View style={styles.row}>
      <View style={styles.emojiCircle}>
        <Text style={styles.emoji}>{emoji}</Text>
      </View>

      <View style={{ flex: 1, marginLeft: Spacing.md }}>
        <Text style={styles.name} numberOfLines={1}>
          {name}
        </Text>
        <Text style={styles.unit}>
          {unit} • ₹{unitPrice} प्रति नग
        </Text>

        <View style={styles.bottomRow}>
          <View style={styles.stepper}>
            <TouchableOpacity style={styles.stepperButton} onPress={onDecrease} hitSlop={{ top: 8, bottom: 8, left: 8, right: 8 }}>
              <Ionicons name="remove" size={14} color={Colors.textPrimary} />
            </TouchableOpacity>
            <Text style={styles.quantity}>{quantity}</Text>
            <TouchableOpacity style={styles.stepperButton} onPress={onIncrease} hitSlop={{ top: 8, bottom: 8, left: 8, right: 8 }}>
              <Ionicons name="add" size={14} color={Colors.textPrimary} />
            </TouchableOpacity>
          </View>
          <Text style={styles.lineTotal}>₹{lineTotal}</Text>
        </View>
      </View>

      <TouchableOpacity onPress={onRemove} hitSlop={{ top: 10, bottom: 10, left: 10, right: 10 }} style={styles.removeButton}>
        <Ionicons name="trash-outline" size={18} color={Colors.error} />
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  row: {
    flexDirection: "row",
    backgroundColor: Colors.surface,
    borderRadius: Radius.lg,
    padding: Spacing.md,
    marginBottom: Spacing.md,
    ...Shadow.card,
  },
  emojiCircle: {
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: Colors.primaryLight,
    alignItems: "center",
    justifyContent: "center",
  },
  emoji: { fontSize: 20 },
  name: {
    fontSize: 14,
    fontWeight: "700",
    color: Colors.textPrimary,
  },
  unit: {
    fontSize: 11,
    color: Colors.textSecondary,
    marginTop: 2,
  },
  bottomRow: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    marginTop: Spacing.sm,
  },
  stepper: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: Colors.background,
    borderRadius: Radius.pill,
    paddingHorizontal: Spacing.xs,
  },
  stepperButton: {
    width: 26,
    height: 26,
    alignItems: "center",
    justifyContent: "center",
  },
  quantity: {
    fontSize: 13,
    fontWeight: "700",
    color: Colors.textPrimary,
    minWidth: 20,
    textAlign: "center",
  },
  lineTotal: {
    fontSize: 14,
    fontWeight: "700",
    color: Colors.secondary,
  },
  removeButton: {
    justifyContent: "flex-start",
    paddingLeft: Spacing.xs,
  },
});
