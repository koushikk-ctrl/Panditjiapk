import React from "react";
import { View, Text, StyleSheet } from "react-native";
import { Colors, Radius, Spacing } from "@/constants/theme";
import { BookingStatus } from "@/hooks/useBookings";

const STATUS_CONFIG: Record<BookingStatus, { label: string; bg: string; color: string }> = {
  pending: { label: "लंबित", bg: Colors.primaryLight, color: Colors.primaryDark },
  confirmed: { label: "स्वीकृत", bg: Colors.accentBlueBg, color: Colors.accentBlue },
  completed: { label: "पूर्ण", bg: Colors.accentGreenBg, color: Colors.accentGreen },
  cancelled: { label: "रद्द", bg: Colors.border, color: Colors.textSecondary },
};

export default function BookingStatusBadge({ status }: { status: BookingStatus }) {
  const config = STATUS_CONFIG[status];
  return (
    <View style={[styles.badge, { backgroundColor: config.bg }]}>
      <Text style={[styles.text, { color: config.color }]}>{config.label}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  badge: {
    paddingHorizontal: Spacing.sm,
    paddingVertical: 4,
    borderRadius: Radius.pill,
  },
  text: {
    fontSize: 11,
    fontWeight: "700",
  },
});
