import React from "react";
import { TouchableOpacity, Text, View, StyleSheet } from "react-native";
import { Ionicons } from "@expo/vector-icons";
import { Colors, Radius, Shadow, Spacing } from "@/constants/theme";

type PanditCardProps = {
  name: string;
  photoEmoji: string;
  experienceYears: number;
  city: string;
  rating: number;
  reviewCount: number;
  startingPrice: number;
  specialtyLabels: string[];
  onPress: () => void;
};

export default function PanditCard({
  name,
  photoEmoji,
  experienceYears,
  city,
  rating,
  reviewCount,
  startingPrice,
  specialtyLabels,
  onPress,
}: PanditCardProps) {
  return (
    <TouchableOpacity style={styles.card} onPress={onPress} activeOpacity={0.8}>
      <View style={styles.topRow}>
        <View style={styles.photoCircle}>
          <Text style={styles.photoEmoji}>{photoEmoji}</Text>
        </View>
        <View style={{ flex: 1, marginLeft: Spacing.md }}>
          <Text style={styles.name} numberOfLines={1}>
            {name}
          </Text>
          <Text style={styles.meta}>
            {experienceYears} वर्ष अनुभव • {city}
          </Text>
          <View style={styles.ratingRow}>
            <Ionicons name="star" size={13} color={Colors.primary} />
            <Text style={styles.ratingText}>
              {rating.toFixed(1)} ({reviewCount})
            </Text>
          </View>
        </View>
        <Text style={styles.price}>₹{startingPrice}+</Text>
      </View>

      <View style={styles.chipsRow}>
        {specialtyLabels.slice(0, 3).map((label) => (
          <View key={label} style={styles.chip}>
            <Text style={styles.chipText}>{label}</Text>
          </View>
        ))}
      </View>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  card: {
    backgroundColor: Colors.surface,
    borderRadius: Radius.lg,
    padding: Spacing.md,
    marginBottom: Spacing.md,
    ...Shadow.card,
  },
  topRow: {
    flexDirection: "row",
    alignItems: "flex-start",
  },
  photoCircle: {
    width: 52,
    height: 52,
    borderRadius: 26,
    backgroundColor: Colors.primaryLight,
    alignItems: "center",
    justifyContent: "center",
  },
  photoEmoji: { fontSize: 24 },
  name: {
    fontSize: 15,
    fontWeight: "700",
    color: Colors.textPrimary,
  },
  meta: {
    fontSize: 11.5,
    color: Colors.textSecondary,
    marginTop: 2,
  },
  ratingRow: {
    flexDirection: "row",
    alignItems: "center",
    marginTop: 4,
  },
  ratingText: {
    fontSize: 11.5,
    fontWeight: "600",
    color: Colors.textPrimary,
    marginLeft: 3,
  },
  price: {
    fontSize: 13,
    fontWeight: "700",
    color: Colors.primaryDark,
  },
  chipsRow: {
    flexDirection: "row",
    flexWrap: "wrap",
    marginTop: Spacing.sm,
  },
  chip: {
    backgroundColor: Colors.accentGreenBg,
    borderRadius: Radius.pill,
    paddingHorizontal: Spacing.sm,
    paddingVertical: 4,
    marginRight: Spacing.xs,
    marginBottom: Spacing.xs,
  },
  chipText: {
    fontSize: 10.5,
    fontWeight: "600",
    color: Colors.accentGreen,
  },
});
