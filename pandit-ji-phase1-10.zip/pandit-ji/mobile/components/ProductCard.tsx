import React from "react";
import { TouchableOpacity, Text, View, StyleSheet } from "react-native";
import { Ionicons } from "@expo/vector-icons";
import { Colors, Radius, Shadow, Spacing } from "@/constants/theme";

type ProductCardProps = {
  name: string;
  emoji: string;
  price: number;
  discountPercent: number;
  discountedPrice: number;
  rating: number;
  unit: string;
  onPress: () => void;
};

export default function ProductCard({
  name,
  emoji,
  price,
  discountPercent,
  discountedPrice,
  rating,
  unit,
  onPress,
}: ProductCardProps) {
  return (
    <TouchableOpacity style={styles.card} onPress={onPress} activeOpacity={0.8}>
      {discountPercent > 0 ? (
        <View style={styles.discountBadge}>
          <Text style={styles.discountBadgeText}>{discountPercent}% छूट</Text>
        </View>
      ) : null}

      <View style={styles.emojiCircle}>
        <Text style={styles.emoji}>{emoji}</Text>
      </View>

      <Text style={styles.name} numberOfLines={2}>
        {name}
      </Text>
      <Text style={styles.unit} numberOfLines={1}>
        {unit}
      </Text>

      <View style={styles.ratingRow}>
        <Ionicons name="star" size={11} color={Colors.primary} />
        <Text style={styles.ratingText}>{rating.toFixed(1)}</Text>
      </View>

      <View style={styles.priceRow}>
        <Text style={styles.price}>₹{discountedPrice}</Text>
        {discountPercent > 0 ? <Text style={styles.originalPrice}>₹{price}</Text> : null}
      </View>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  card: {
    width: "48%",
    backgroundColor: Colors.surface,
    borderRadius: Radius.lg,
    padding: Spacing.md,
    marginBottom: Spacing.md,
    ...Shadow.card,
  },
  discountBadge: {
    position: "absolute",
    top: Spacing.sm,
    right: Spacing.sm,
    backgroundColor: Colors.accentPink,
    borderRadius: Radius.pill,
    paddingHorizontal: 6,
    paddingVertical: 2,
    zIndex: 1,
  },
  discountBadgeText: {
    fontSize: 9.5,
    fontWeight: "700",
    color: "#FFFFFF",
  },
  emojiCircle: {
    width: 48,
    height: 48,
    borderRadius: 24,
    backgroundColor: Colors.primaryLight,
    alignItems: "center",
    justifyContent: "center",
    marginBottom: Spacing.sm,
  },
  emoji: { fontSize: 22 },
  name: {
    fontSize: 13,
    fontWeight: "700",
    color: Colors.textPrimary,
    lineHeight: 17,
    minHeight: 34,
  },
  unit: {
    fontSize: 10.5,
    color: Colors.textSecondary,
    marginTop: 2,
  },
  ratingRow: {
    flexDirection: "row",
    alignItems: "center",
    marginTop: Spacing.xs,
  },
  ratingText: {
    fontSize: 10.5,
    fontWeight: "600",
    color: Colors.textPrimary,
    marginLeft: 3,
  },
  priceRow: {
    flexDirection: "row",
    alignItems: "center",
    marginTop: Spacing.xs,
  },
  price: {
    fontSize: 14,
    fontWeight: "700",
    color: Colors.secondary,
    marginRight: Spacing.xs,
  },
  originalPrice: {
    fontSize: 11,
    color: Colors.textSecondary,
    textDecorationLine: "line-through",
  },
});
