export type PoojaTypeOption = { id: string; label: string; icon: string };

export const poojaTypes: PoojaTypeOption[] = [
  { id: "griha-pravesh", label: "गृह प्रवेश", icon: "🏠" },
  { id: "satyanarayan-katha", label: "सत्यनारायण कथा", icon: "🪷" },
  { id: "ganesh-pooja", label: "गणेश पूजा", icon: "🕉️" },
  { id: "shiv-pooja", label: "शिव पूजा", icon: "🔱" },
  { id: "havan", label: "हवन", icon: "🔥" },
  { id: "marriage-rituals", label: "विवाह संस्कार", icon: "💍" },
  { id: "mundan", label: "मुंडन संस्कार", icon: "👶" },
  { id: "naamkaran", label: "नामकरण संस्कार", icon: "📜" },
  { id: "shradh", label: "श्राद्ध", icon: "🪔" },
  { id: "other", label: "अन्य", icon: "✨" },
];

export function getPoojaTypeLabel(id: string) {
  return poojaTypes.find((p) => p.id === id)?.label || id;
}
