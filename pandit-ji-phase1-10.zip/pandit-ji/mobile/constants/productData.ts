// NOTE: Demo product catalog for MVP/UI purposes. In production this comes
// from the backend (Product model) with real inventory, pricing, and
// uploaded images (Cloudinary/S3) managed via the admin panel.

export type ProductCategory = "samagri" | "kit" | "book" | "spiritual";

export const productCategories: { id: ProductCategory; label: string }[] = [
  { id: "samagri", label: "पूजा सामग्री" },
  { id: "kit", label: "पूजा किट" },
  { id: "book", label: "धार्मिक पुस्तकें" },
  { id: "spiritual", label: "आध्यात्मिक उत्पाद" },
];

export type Review = { name: string; rating: number; comment: string };

export type Product = {
  id: string;
  name: string;
  category: ProductCategory;
  emoji: string;
  price: number;
  discountPercent: number;
  stock: number;
  rating: number;
  reviewCount: number;
  unit: string;
  description: string;
  reviews: Review[];
};

export const products: Product[] = [
  {
    id: "incense-sticks",
    name: "अगरबत्ती (चंदन)",
    category: "samagri",
    emoji: "🕯️",
    price: 60,
    discountPercent: 10,
    stock: 120,
    rating: 4.5,
    reviewCount: 210,
    unit: "1 पैकेट (20 सिटक्स)",
    description: "शुद्ध चंदन की सुगंध वाली अगरबत्ती, प्रतिदिन पूजा हेतु उपयुक्त।",
    reviews: [
      { name: "अनिता शर्मा", rating: 5, comment: "बहुत अच्छी खुशबू है, लंबे समय तक टिकती है।" },
      { name: "राजेश गुप्ता", rating: 4, comment: "गुणवत्ता अच्छी है, पैकेजिंग भी ठीक थी।" },
    ],
  },
  {
    id: "cotton-wicks",
    name: "रुई की बत्ती",
    category: "samagri",
    emoji: "🪔",
    price: 25,
    discountPercent: 0,
    stock: 200,
    rating: 4.3,
    reviewCount: 88,
    unit: "1 पैकेट (100 नग)",
    description: "दीपक जलाने हेतु शुद्ध रुई से बनी बत्तियां।",
    reviews: [{ name: "सुनीता वर्मा", rating: 4, comment: "अच्छी गुणवत्ता, जल्दी टूटती नहीं।" }],
  },
  {
    id: "kumkum-haldi-set",
    name: "कुमकुम-हल्दी सेट",
    category: "samagri",
    emoji: "🔴",
    price: 45,
    discountPercent: 5,
    stock: 150,
    rating: 4.4,
    reviewCount: 64,
    unit: "1 सेट (2 डिब्बी)",
    description: "शुद्ध कुमकुम व हल्दी, तिलक व पूजा हेतु।",
    reviews: [],
  },
  {
    id: "camphor-pack",
    name: "कपूर पैक",
    category: "samagri",
    emoji: "❄️",
    price: 35,
    discountPercent: 0,
    stock: 180,
    rating: 4.6,
    reviewCount: 102,
    unit: "1 पैकेट (50 ग्राम)",
    description: "शुद्ध कपूर, आरती व हवन हेतु उपयुक्त।",
    reviews: [{ name: "मीना जोशी", rating: 5, comment: "बहुत शुद्ध कपूर है, धुआं भी कम होता है।" }],
  },
  {
    id: "ganesh-pooja-kit",
    name: "गणेश पूजा किट",
    category: "kit",
    emoji: "🕉️",
    price: 499,
    discountPercent: 15,
    stock: 40,
    rating: 4.7,
    reviewCount: 156,
    unit: "1 संपूर्ण किट",
    description: "गणेश पूजा हेतु आवश्यक सभी सामग्री एक ही पैकेट में — दूर्वा, मोदक सांचा, रोली, अक्षत, अगरबत्ती व अधिक।",
    reviews: [
      { name: "विकास पटेल", rating: 5, comment: "सब कुछ एक ही जगह मिल गया, बहुत सुविधाजनक।" },
      { name: "प्रिया शाह", rating: 4, comment: "अच्छी क्वालिटी, समय पर डिलीवरी हुई।" },
    ],
  },
  {
    id: "satyanarayan-pooja-kit",
    name: "सत्यनारायण पूजा किट",
    category: "kit",
    emoji: "🪷",
    price: 799,
    discountPercent: 10,
    stock: 25,
    rating: 4.8,
    reviewCount: 92,
    unit: "1 संपूर्ण किट",
    description: "सत्यनारायण कथा व पूजा हेतु संपूर्ण सामग्री — पंचामृत सामग्री, पान, सुपारी, फल-प्रसाद सामग्री सहित।",
    reviews: [{ name: "देवेन्द्र सिंह", rating: 5, comment: "पंडित जी ने भी सामग्री की तारीफ की।" }],
  },
  {
    id: "navratri-pooja-kit",
    name: "नवरात्रि पूजा किट",
    category: "kit",
    emoji: "🪔",
    price: 599,
    discountPercent: 20,
    stock: 60,
    rating: 4.6,
    reviewCount: 74,
    unit: "1 संपूर्ण किट",
    description: "नवरात्रि की 9 दिनों की पूजा हेतु सम्पूर्ण सामग्री — कलश, लाल चुनरी, नारियल व अन्य आवश्यक वस्तुएं।",
    reviews: [],
  },
  {
    id: "bhagavad-gita-hindi",
    name: "श्रीमद्भगवद्गीता (हिंदी टीका सहित)",
    category: "book",
    emoji: "📖",
    price: 220,
    discountPercent: 0,
    stock: 90,
    rating: 4.9,
    reviewCount: 340,
    unit: "1 प्रति (हार्डबाउंड)",
    description: "सरल हिंदी भावार्थ सहित श्रीमद्भगवद्गीता, नए पाठकों के लिए उपयुक्त।",
    reviews: [{ name: "अनिल कुमार", rating: 5, comment: "भाषा बहुत सरल है, समझने में आसान।" }],
  },
  {
    id: "hanuman-chalisa-book",
    name: "हनुमान चालीसा (अर्थ सहित)",
    category: "book",
    emoji: "📕",
    price: 60,
    discountPercent: 0,
    stock: 150,
    rating: 4.7,
    reviewCount: 198,
    unit: "1 प्रति",
    description: "हनुमान चालीसा मूल पाठ, शुद्ध उच्चारण मार्गदर्शिका व हिंदी अर्थ सहित।",
    reviews: [],
  },
  {
    id: "durga-saptashati-book",
    name: "दुर्गा सप्तशती",
    category: "book",
    emoji: "📗",
    price: 180,
    discountPercent: 5,
    stock: 70,
    rating: 4.8,
    reviewCount: 121,
    unit: "1 प्रति (संस्कृत + हिंदी)",
    description: "नवरात्रि पाठ हेतु संस्कृत मूल पाठ के साथ हिंदी अनुवाद।",
    reviews: [],
  },
  {
    id: "rudraksha-mala",
    name: "रुद्राक्ष माला (108 मनके)",
    category: "spiritual",
    emoji: "📿",
    price: 349,
    discountPercent: 12,
    stock: 55,
    rating: 4.5,
    reviewCount: 87,
    unit: "1 माला",
    description: "जाप हेतु प्रामाणिक 108 मनकों वाली रुद्राक्ष माला।",
    reviews: [{ name: "सुरेश यादव", rating: 4, comment: "असली रुद्राक्ष लगता है, अच्छी गुणवत्ता।" }],
  },
  {
    id: "brass-diya-pair",
    name: "पीतल का दीपक जोड़ा",
    category: "spiritual",
    emoji: "🪘",
    price: 299,
    discountPercent: 0,
    stock: 65,
    rating: 4.6,
    reviewCount: 53,
    unit: "1 जोड़ा (2 नग)",
    description: "हस्तनिर्मित पीतल के दीपक, रोज़ाना पूजा व त्योहारों हेतु उपयुक्त।",
    reviews: [],
  },
];

export function getProductById(id?: string | string[]) {
  const key = Array.isArray(id) ? id[0] : id;
  return products.find((p) => p.id === key);
}

export function getDiscountedPrice(product: Product) {
  return Math.round(product.price * (1 - product.discountPercent / 100));
}
