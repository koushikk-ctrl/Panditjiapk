// NOTE: Demo pandit profiles for MVP/UI purposes. In production these come
// from the backend (Pandit model), populated via pandit registration +
// admin approval (see later phases).

export type Pandit = {
  id: string;
  name: string;
  photoEmoji: string;
  experienceYears: number;
  languages: string[];
  specialties: string[]; // pooja type ids from poojaTypesData
  rating: number;
  reviewCount: number;
  city: string;
  startingPrice: number;
  bio: string;
  availableDays: string[];
  isOnlineAvailable: boolean;
};

export const pandits: Pandit[] = [
  {
    id: "pandit-ramesh-sharma",
    name: "पं. रमेश शर्मा",
    photoEmoji: "🧑‍🦳",
    experienceYears: 22,
    languages: ["हिंदी", "संस्कृत"],
    specialties: ["griha-pravesh", "satyanarayan-katha", "havan"],
    rating: 4.8,
    reviewCount: 156,
    city: "इंदौर",
    startingPrice: 2100,
    bio: "22 वर्षों के अनुभव के साथ गृह प्रवेश, सत्यनारायण कथा व हवन विशेषज्ञ। शुद्ध वैदिक विधि से पूजा सम्पन्न कराते हैं।",
    availableDays: ["सोम", "बुध", "शुक्र", "रवि"],
    isOnlineAvailable: true,
  },
  {
    id: "pandit-suresh-tripathi",
    name: "पं. सुरेश त्रिपाठी",
    photoEmoji: "👳",
    experienceYears: 15,
    languages: ["हिंदी", "संस्कृत", "अंग्रेज़ी"],
    specialties: ["marriage-rituals", "naamkaran", "mundan"],
    rating: 4.6,
    reviewCount: 98,
    city: "भोपाल",
    startingPrice: 5100,
    bio: "विवाह संस्कार व संस्कार-विधि में विशेषज्ञ। शहर के बाहर भी सेवा उपलब्ध।",
    availableDays: ["मंगल", "गुरु", "शनि", "रवि"],
    isOnlineAvailable: true,
  },
  {
    id: "pandit-omprakash-dubey",
    name: "पं. ओमप्रकाश दुबे",
    photoEmoji: "🧔",
    experienceYears: 30,
    languages: ["हिंदी", "संस्कृत"],
    specialties: ["shradh", "shiv-pooja", "havan"],
    rating: 4.9,
    reviewCount: 210,
    city: "उज्जैन",
    startingPrice: 1800,
    bio: "श्राद्ध व शिव पूजा में 30 वर्षों का गहन अनुभव। महाकाल नगरी उज्जैन से।",
    availableDays: ["सोम", "मंगल", "बुध", "गुरु", "शुक्र"],
    isOnlineAvailable: false,
  },
  {
    id: "pandit-vinod-joshi",
    name: "पं. विनोद जोशी",
    photoEmoji: "🧑",
    experienceYears: 10,
    languages: ["हिंदी", "गुजराती"],
    specialties: ["ganesh-pooja", "griha-pravesh", "other"],
    rating: 4.5,
    reviewCount: 64,
    city: "इंदौर",
    startingPrice: 1500,
    bio: "गणेश पूजा व गृह प्रवेश हेतु किफायती व भरोसेमंद सेवा।",
    availableDays: ["बुध", "शुक्र", "शनि", "रवि"],
    isOnlineAvailable: true,
  },
  {
    id: "pandit-krishnamurthy-iyer",
    name: "पं. कृष्णमूर्ति अय्यर",
    photoEmoji: "🙏",
    experienceYears: 18,
    languages: ["हिंदी", "तमिल", "अंग्रेज़ी"],
    specialties: ["satyanarayan-katha", "naamkaran", "havan"],
    rating: 4.7,
    reviewCount: 132,
    city: "बेंगलुरु",
    startingPrice: 3100,
    bio: "दक्षिण भारतीय व उत्तर भारतीय — दोनों परंपराओं में पूजा कराने में सक्षम।",
    availableDays: ["सोम", "मंगल", "गुरु", "रवि"],
    isOnlineAvailable: true,
  },
  {
    id: "pandit-mahesh-pandey",
    name: "पं. महेश पांडे",
    photoEmoji: "👴",
    experienceYears: 35,
    languages: ["हिंदी", "संस्कृत"],
    specialties: ["shiv-pooja", "shradh", "mundan"],
    rating: 5.0,
    reviewCount: 289,
    city: "वाराणसी",
    startingPrice: 2500,
    bio: "काशी के प्रतिष्ठित पंडित। सभी प्रकार के संस्कार व शास्त्रोक्त विधि में पारंगत।",
    availableDays: ["सोम", "बुध", "शुक्र"],
    isOnlineAvailable: false,
  },
];

export function getPanditById(id?: string | string[]) {
  const key = Array.isArray(id) ? id[0] : id;
  return pandits.find((p) => p.id === key);
}
