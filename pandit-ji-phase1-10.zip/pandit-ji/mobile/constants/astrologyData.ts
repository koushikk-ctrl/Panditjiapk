// ============================================================================
// IMPORTANT: Everything in this file is DEMO/PLACEHOLDER data.
// Real Vedic astrology requires precise astronomical ephemeris calculations
// (planetary positions, ayanamsa, house systems, etc.) that must come from a
// licensed astrology API or calculation library — NOT invented here.
// This file exists purely so the UI has realistic-looking data to render
// while the app is being built. See services/astrologyService.ts for where
// a real provider would be plugged in.
// ============================================================================

export type PanchangDetail = {
  date: string;
  weekday: string;
  tithi: string;
  nakshatra: string;
  yoga: string;
  karana: string;
  sunrise: string;
  sunset: string;
  rahuKaal: string;
  abhijitMuhurat: string;
  paksha: string;
};

export const demoPanchangDetail: PanchangDetail = {
  date: "25 सितंबर 2026, शुक्रवार",
  weekday: "शुक्रवार",
  tithi: "भाद्रपद कृष्ण त्रयोदशी",
  nakshatra: "पुष्य",
  yoga: "सिद्धि",
  karana: "गर",
  sunrise: "06:12 AM",
  sunset: "06:24 PM",
  rahuKaal: "10:45 AM – 12:15 PM",
  abhijitMuhurat: "11:52 AM – 12:40 PM",
  paksha: "कृष्ण पक्ष",
};

export type Muhurat = {
  id: string;
  purpose: string;
  icon: string;
  date: string;
  timeWindow: string;
  note: string;
};

export const demoMuhurats: Muhurat[] = [
  {
    id: "griha-pravesh",
    purpose: "गृह प्रवेश",
    icon: "🏠",
    date: "3 अक्टूबर 2026",
    timeWindow: "प्रातः 07:15 – 09:30",
    note: "शुक्ल पक्ष व शुभ वार होने से उत्तम मुहूर्त।",
  },
  {
    id: "vivah",
    purpose: "विवाह",
    icon: "💍",
    date: "18 नवंबर 2026",
    timeWindow: "रात्रि 08:00 – 10:00",
    note: "देव उठनी एकादशी के पश्चात विवाह मुहूर्त प्रारंभ।",
  },
  {
    id: "vehicle-purchase",
    purpose: "वाहन क्रय",
    icon: "🚗",
    date: "8 नवंबर 2026 (धनतेरस)",
    timeWindow: "पूरे दिन शुभ",
    note: "धनतेरस पर नए वाहन/संपत्ति की खरीद अत्यंत शुभ मानी जाती है।",
  },
  {
    id: "naming-ceremony",
    purpose: "नामकरण संस्कार",
    icon: "👶",
    date: "12 अक्टूबर 2026",
    timeWindow: "प्रातः 09:00 – 11:00",
    note: "शिशु के जन्म के 11वें या 12वें दिन उपयुक्त मुहूर्त।",
  },
];

export type NakshatraInfo = {
  name: string;
  lord: string;
  meaning: string;
};

// A representative subset for the "learn" screen — not the full 27, kept
// concise for MVP.
export const nakshatraLearning: NakshatraInfo[] = [
  { name: "अश्विनी", lord: "केतु", meaning: "आरंभ व गति का प्रतीक — नई शुरुआत के लिए शुभ।" },
  { name: "भरणी", lord: "शुक्र", meaning: "धैर्य व जिम्मेदारी का नक्षत्र।" },
  { name: "रोहिणी", lord: "चंद्र", meaning: "सुंदरता, समृद्धि व सृजनात्मकता से जुड़ा नक्षत्र।" },
  { name: "पुष्य", lord: "शनि", meaning: "पोषण व शुभता का नक्षत्र — अधिकांश शुभ कार्यों हेतु उत्तम।" },
  { name: "मघा", lord: "केतु", meaning: "राजसी शक्ति व पूर्वजों के सम्मान से जुड़ा नक्षत्र।" },
  { name: "स्वाति", lord: "राहु", meaning: "स्वतंत्रता व संतुलन का प्रतीक नक्षत्र।" },
  { name: "मूल", lord: "केतु", meaning: "गहन खोज व परिवर्तन का नक्षत्र।" },
  { name: "उत्तराषाढ़ा", lord: "सूर्य", meaning: "विजय व स्थायित्व से जुड़ा नक्षत्र।" },
  { name: "श्रवण", lord: "चंद्र", meaning: "श्रवण/शिक्षा व ज्ञान संचय का नक्षत्र।" },
  { name: "रेवती", lord: "बुध", meaning: "पूर्णता व करुणा का अंतिम नक्षत्र।" },
];

export type KundliInput = {
  name: string;
  dob: string; // DD/MM/YYYY as entered by user
  tob: string; // HH:MM as entered by user
  place: string;
};

export type KundliResult = {
  rashi: string;
  nakshatra: string;
  lagna: string;
  nakshatraPada: number;
  summary: string;
};

// A single fixed demo result returned regardless of input, clearly labelled
// in the UI as illustrative only — a real provider computes this from the
// exact birth date/time/place using ephemeris data.
export const demoKundliResult: KundliResult = {
  rashi: "मेष (Aries)",
  nakshatra: "अश्विनी",
  lagna: "वृषभ (Taurus)",
  nakshatraPada: 2,
  summary:
    "यह एक उदाहरण परिणाम है। वास्तविक कुंडली गणना हेतु सटीक जन्म तिथि, समय व स्थान के आधार पर पंचांग गणना आवश्यक है, जो भविष्य में एक प्रमाणित ज्योतिष API से जोड़ी जाएगी।",
};
