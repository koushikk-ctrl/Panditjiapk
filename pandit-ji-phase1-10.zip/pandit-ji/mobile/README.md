# Pandit Ji — Mobile App (Phase 1)

## Prerequisites

- Node.js 18+ installed (check: `node -v`)
- The **Expo Go** app on your phone (Android: Play Store, iOS: App Store) — easiest way to preview
- OR Android Studio / Xcode if you want a simulator instead

## Setup (run these exactly, in order)

1. Open a terminal in the `mobile/` folder (the folder containing this README).
2. Install dependencies:

   ```
   npm install
   ```

3. Start the dev server:

   ```
   npx expo start
   ```

4. A QR code will appear in your terminal.
   - **On your phone**: open the Expo Go app and scan the QR code.
   - **On a simulator**: press `a` for Android emulator or `i` for iOS simulator (in the terminal).

That's it — the Home screen should load.

## What you should see

- A cream background app with an "ॐ Pandit Ji" header and greeting
- A saffron/maroon hero banner: "सनातन ज्ञान सदैव आपके साथ"
- A 4-icon Quick Access row (Daily Sadhana, Pooja Vidhi, Panchang, Mantra & Audio)
- A Today's Panchang card with demo tithi/nakshatra/yoga/muhurat
- A horizontally scrolling Quick Pooja deity row
- A dark "Today's Sadhana" progress teaser card
- A 6-tile "Explore" grid (Sadhana, Pooja Library, Sanatan Knowledge, Jyotish, Pooja Samagri, Pandit Booking)
- Featured Festival and Daily Mantra cards
- A 5-tab bottom bar: Home, Library, Store, Pandit, More (the last 4 are placeholder screens for now)

## Phase 5: Daily Sadhana

Tap "दैनिक साधना" (Quick Access, the Explore grid, or the dark progress card) to open the Daily Sadhana screen:

- A checklist of 5 daily items (Ganesh Vandana, Gayatri Mantra, Shiv Mantra, Hanuman Chalisa, Evening Aarti) — tap any row to mark it done/undone.
- Today's completion % and a 🔥 streak counter (consecutive fully-completed days).
- A 7-day weekly strip showing which recent days were fully completed.
- A monthly progress bar (days fully completed out of days elapsed this month).

This is **real, working state** — not a mockup. It's saved to your device via AsyncStorage, so if you close and reopen the app, your progress and streak persist. Try checking off all 5 items today, then come back tomorrow — the streak should increment automatically once "today" changes.

## Phase 6: Mantra & Audio

Tap "मंत्र व ऑडियो" from Home's Quick Access row, or "पूरी आरती सुनें" on any Pooja detail page, to reach the audio module:

- **Library** (`/audio`): category filter chips (सभी, पसंदीदा, मंत्र, आरती, भजन, स्तोत्र, ध्यान), a "हाल ही में सुना गया" (recently played) section, and a tap-anywhere heart icon to favorite/unfavorite each track. A mini player bar sticks to the bottom once something is loaded.
- **Full player** (`/audio/player`): real playback controls — play/pause, next/previous (cycles through the whole library), a tap-to-seek progress bar, elapsed/total time, and a favorite toggle.

This uses a **real audio engine** (`expo-av`), not a mockup — one shared player instance lives in `contexts/AudioPlayerContext.tsx` so playback continues correctly as you navigate between the library and player screens. Favorites and recently-played are persisted to your device via AsyncStorage.

**Important**: the actual audio files playing are royalty-free placeholder demo tracks (not real mantra/aarti recordings) — see the disclaimer at the bottom of the player screen and the comment at the top of `constants/audioData.ts`. Swap in licensed devotional audio (via Cloudinary/S3, per the architecture) before production.

## Phase 7: Festival Calendar

The Home screen's "Featured Festival" card now shows the **real, soonest-upcoming** festival (computed from actual dates, not a static demo number). Tap it, or tap "सभी देखें", to open the full calendar at `/festivals`:

- A list of 8 major festivals (महाशिवरात्रि, होली, राम नवमी, गणेश चतुर्थी, शारदीय नवरात्रि, एकादशी, जन्माष्टमी, दीपावली), sorted so the soonest upcoming one appears first and already-passed ones (for this year) show a "बीत चुका" badge instead of a countdown.
- Tapping any festival opens its detail page: date, tithi, muhurat, description, required samagri, step-by-step vidhi, and mantras — the same structure as the Pooja Library detail pages.
- **Architecture note**: screens never read festival data directly — they go through `services/festivalService.ts`, which currently returns local data but is already shaped to swap in a real panchang/backend API later without touching any screen code (see the comments in that file). The list screen also demonstrates this by using React Query (`useQuery`) with proper loading/error states, exactly as it would with a real network call.
- Dates for most festivals come from public 2026 panchang references; Ekadashi's date is explicitly marked "(अनुमानित)" (approximate) since it recurs twice a month and needs a real panchang calculation for precision — a deliberate example of where the production astrology API (Phase 8) will matter.

## Phase 8: Astrology (Jyotish)

Tap "ज्योतिष" from the Explore grid, or "पंचांग" from Quick Access / the Today's Panchang card, to reach `/jyotish`:

- **जन्म कुंडली** (`/jyotish/kundli`) — a form for name, date of birth, time of birth, and place of birth. Submitting shows a demo result (rashi, nakshatra, lagna, nakshatra pada) with a clear on-screen note that this is illustrative only.
- **पंचांग** (`/jyotish/panchang`) — full daily panchang: tithi, nakshatra, yoga, karana, sunrise/sunset, Rahu Kaal, Abhijit Muhurat.
- **मुहूर्त** (`/jyotish/muhurat`) — upcoming auspicious time windows for common life events (Griha Pravesh, marriage, vehicle purchase, naming ceremony).
- **नक्षत्र सीखें** (`/jyotish/nakshatra`) — a short educational reference for 10 nakshatras (name, ruling planet, meaning).

**Important**: per the brief, no real astronomical calculations are invented here. Every screen shows a visible "यह डेमो डेटा है..." banner, and all four screens are powered by `services/astrologyService.ts` — a single file that currently returns local demo data but is structured so a licensed Vedic astrology/panchang API can be plugged in later without changing any screen.

## Phase 9: Pandit Booking

The **Pandit** tab is now the real Browse Pandits screen:

- Search by name/city + filter chips by specialty (गृह प्रवेश, विवाह संस्कार, हवन, etc.)
- Tap any pandit → full profile (bio, specialties, languages, available days, starting price, "अभी बुक करें")
- Booking form → pooja type chips, date/time/location fields, optional special instructions → submits to a **real, persisted** booking (AsyncStorage via `hooks/useBookings.ts`), landing on a confirmation screen
- **"मेरी बुकिंग्स"** (top-right of the Pandit tab) → lists all your bookings with status badges (लंबित / स्वीकृत / पूर्ण / रद्द) and lets you cancel a pending one
- **"पंडित डैशबोर्ड (डेमो)"** link at the bottom of the Pandit tab → a demo of the *other side* of the marketplace: new/upcoming/completed bookings, a running earnings total, an availability toggle, and a placeholder profile-management card. It's explicitly labelled as an architecture demo since it isn't scoped to a single logged-in pandit yet — that needs the role-based auth from Phase 13.

Try booking a pandit, then open the Pandit Dashboard — you'll see the same booking appear under "नई बुकिंग्स", and tapping "स्वीकार करें" there will flip its status, which you'll then see reflected back in "मेरी बुकिंग्स". This proves the shared booking state actually works end-to-end.

## Phase 10: Store & Cart

The **Store** tab is now the real product catalog:

- Search + category filter chips (पूजा सामग्री, पूजा किट, धार्मिक पुस्तकें, आध्यात्मिक उत्पाद) over 12 demo products, each with price, discount, stock, rating, and a couple of demo reviews.
- Tap any product → detail page (image placeholder, price/discount, stock status, description, reviews, quantity stepper, "कार्ट में जोड़ें" / "अभी खरीदें").
- A cart icon with a live item-count badge sits top-right of the Store tab.
- **Cart** (`/cart`) — quantity +/- controls, remove, a free-delivery progress banner (free above ₹500, otherwise ₹49), subtotal/delivery/total.
- **Checkout** (`/checkout`) — delivery address form, order summary, and a choice between Cash on Delivery or a clearly-labelled **mock** online payment (per the brief: "keep payment architecture ready for Razorpay, use mock payment mode during development" — see the comments in `services/storeService.ts` for exactly where Razorpay would plug in). Placing an order clears the cart and shows an order ID + estimated delivery.

Cart contents are persisted via AsyncStorage (`hooks/useCart.ts`), so they survive closing and reopening the app, same pattern as Sadhana and Bookings.

## Notes

- All Panchang/mantra/festival data on this screen is **demo data** (see `constants/mockData.ts`). It is not astronomically calculated — that comes in Phase 8 with a real API-ready service layer.
- Tapping "Pooja Vidhi", "Pooja Samagri" and "Pandit Booking" navigates to their (placeholder) tabs to prove routing works end-to-end.
- No backend is connected yet — `services/apiClient.ts` is a ready-to-use axios client (with JWT auto-attach) pointed at `http://localhost:5000/api`, which we'll wire up once the backend exists (Phase 11+).

## Troubleshooting

- If `npm install` fails, make sure you're using Node 18 or newer.
- If the QR code doesn't load on your phone, make sure your phone and computer are on the **same Wi-Fi network**.
- If you see a red error screen mentioning a missing package, stop the server (Ctrl+C) and re-run `npm install`, then `npx expo start` again.
