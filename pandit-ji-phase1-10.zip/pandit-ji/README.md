# Pandit Ji — "Har Pooja, Har Vidhi — Ab Aapke Mobile Mein"

A digital Sanatan/Dharmic platform: daily sadhana, pooja library, sanatan
knowledge, jyotish, pandit booking, pooja samagri store, and an AI assistant.

## Project structure

```
pandit-ji/
├── mobile/     ← React Native (Expo) app — PHASE 1 (this delivery)
├── backend/    ← Node.js/Express API — later phase
├── admin/      ← Admin dashboard — later phase
└── README.md
```

## Build status

- [x] Phase 1: Project foundation + Home screen (mobile)
- [x] Phase 2: Navigation & reusable components (partially done alongside Phase 1)
- [x] Phase 3: Home screen polish
- [x] Phase 4: Pooja Library
- [x] Phase 5: Daily Sadhana (with AsyncStorage persistence, streak & monthly tracking)
- [x] Phase 6: Mantra & Audio (real playback via expo-av, favorites, recently played)
- [x] Phase 7: Festival Calendar (real 2026 dates, API-ready service layer)
- [x] Phase 8: Astrology / Jyotish (Kundli form, Panchang, Muhurat, Nakshatra — clearly labelled demo data)
- [x] Phase 9: Pandit Booking (browse, profile, booking form, my bookings, pandit dashboard demo)
- [x] Phase 10: Store & Cart (products, cart, checkout, mock payment — Razorpay-ready)

## Mobile frontend phases done (1-10)

The mobile app (`mobile/`) is now feature-complete for the frontend-only phases of this plan. Phases 11 onward move to a real backend, database, and auth — see "What's next" below.
- [ ] Phase 11+: Backend, DB, Auth, Admin, AI, Testing, Production

See `mobile/README.md` for how to run what's built so far.
