import React from "react";
import { View, Text, ScrollView, StyleSheet, TouchableOpacity } from "react-native";
import { router, useLocalSearchParams } from "expo-router";
import { Ionicons } from "@expo/vector-icons";
import { Colors, Radius, Shadow, Spacing, Typography } from "@/constants/theme";
import Card from "@/components/Card";
import EmptyState from "@/components/EmptyState";
import { getPoojaById } from "@/constants/poojaData";

export default function PoojaDetailScreen() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const pooja = getPoojaById(id);

  if (!pooja) {
    return (
      <View style={styles.screen}>
        <BackBar onBack={() => router.back()} title="" />
        <EmptyState icon="alert-circle" title="यह पूजा नहीं मिली" subtitle="कृपया वापस जाकर दोबारा कोशिश करें।" />
      </View>
    );
  }

  return (
    <View style={styles.screen}>
      <BackBar onBack={() => router.back()} title={pooja.name} />

      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={styles.scrollContent}>
        {/* Hero */}
        <View style={[styles.hero, { backgroundColor: pooja.color }]}>
          <Text style={styles.heroEmoji}>{pooja.emoji}</Text>
          <Text style={styles.heroName}>{pooja.name}</Text>
          <Text style={[styles.heroPurpose, { color: pooja.accent }]}>{pooja.shortPurpose}</Text>

          <View style={styles.metaRow}>
            <MetaPill icon="time-outline" label={pooja.duration} />
            <MetaPill icon="sunny-outline" label={pooja.bestTime} />
          </View>
        </View>

        {/* Purpose */}
        <Section title="उद्देश्य">
          <Text style={Typography.body}>{pooja.purpose}</Text>
        </Section>

        {/* Samagri */}
        <Section title="आवश्यक सामग्री">
          <Card backgroundColor={Colors.accentGreenBg}>
            {pooja.samagri.map((item, i) => (
              <View key={i} style={styles.samagriRow}>
                <Ionicons name="checkmark-circle" size={16} color={Colors.accentGreen} />
                <Text style={[Typography.body, { marginLeft: Spacing.sm }]}>{item}</Text>
              </View>
            ))}
          </Card>
        </Section>

        {/* Vidhi steps */}
        <Section title="पूजा विधि (चरण-दर-चरण)">
          {pooja.vidhiSteps.map((step, i) => (
            <View key={i} style={styles.stepRow}>
              <View style={styles.stepNumber}>
                <Text style={styles.stepNumberText}>{i + 1}</Text>
              </View>
              <View style={{ flex: 1 }}>
                <Text style={styles.stepTitle}>{step.title}</Text>
                <Text style={Typography.bodySmall}>{step.description}</Text>
              </View>
            </View>
          ))}
        </Section>

        {/* Mantras */}
        <Section title="मंत्र">
          {pooja.mantras.map((m, i) => (
            <Card key={i} backgroundColor={Colors.primaryLight} style={{ marginBottom: Spacing.sm }}>
              <Text style={styles.mantraSanskrit}>{m.sanskrit}</Text>
              <Text style={[Typography.bodySmall, { marginTop: Spacing.xs }]}>{m.meaning}</Text>
            </Card>
          ))}
        </Section>

        {/* Aarti */}
        <Section title="आरती">
          <Card backgroundColor={Colors.accentPinkBg}>
            <Text style={styles.aartiTitle}>{pooja.aartiTitle}</Text>
            <Text style={[Typography.bodySmall, { marginTop: Spacing.xs, fontStyle: "italic" }]}>
              {pooja.aartiOpeningLine}
            </Text>
            <TouchableOpacity style={styles.audioButton} activeOpacity={0.8}>
              <Ionicons name="play-circle" size={20} color={Colors.textOnPrimary} />
              <Text style={styles.audioButtonText}>पूरी आरती सुनें</Text>
            </TouchableOpacity>
          </Card>
        </Section>

        {/* Explanation */}
        <Section title="सरल व्याख्या">
          <Text style={Typography.body}>{pooja.hindiExplanation}</Text>
        </Section>

        <View style={{ height: Spacing.xxxl }} />
      </ScrollView>
    </View>
  );
}

function BackBar({ onBack, title }: { onBack: () => void; title: string }) {
  return (
    <View style={styles.backBar}>
      <TouchableOpacity onPress={onBack} style={styles.backButton} hitSlop={{ top: 10, bottom: 10, left: 10, right: 10 }}>
        <Ionicons name="chevron-back" size={24} color={Colors.textPrimary} />
      </TouchableOpacity>
      <Text style={styles.backBarTitle} numberOfLines={1}>
        {title}
      </Text>
      <View style={{ width: 24 }} />
    </View>
  );
}

function MetaPill({ icon, label }: { icon: keyof typeof Ionicons.glyphMap; label: string }) {
  return (
    <View style={styles.metaPill}>
      <Ionicons name={icon} size={13} color={Colors.textPrimary} />
      <Text style={styles.metaPillText}>{label}</Text>
    </View>
  );
}

function Section({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <View style={styles.section}>
      <Text style={styles.sectionTitle}>{title}</Text>
      {children}
    </View>
  );
}

const styles = StyleSheet.create({
  screen: {
    flex: 1,
    backgroundColor: Colors.background,
    paddingTop: 56,
  },
  scrollContent: {
    paddingBottom: Spacing.xxxl,
  },
  backBar: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingHorizontal: Spacing.lg,
    paddingBottom: Spacing.md,
  },
  backButton: {
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: Colors.surface,
    alignItems: "center",
    justifyContent: "center",
    ...Shadow.card,
  },
  backBarTitle: {
    flex: 1,
    textAlign: "center",
    fontSize: 15,
    fontWeight: "700",
    color: Colors.textPrimary,
    marginHorizontal: Spacing.sm,
  },
  hero: {
    marginHorizontal: Spacing.lg,
    borderRadius: Radius.lg,
    padding: Spacing.xl,
    alignItems: "center",
    marginBottom: Spacing.lg,
  },
  heroEmoji: { fontSize: 40, marginBottom: Spacing.sm },
  heroName: { fontSize: 20, fontWeight: "700", color: Colors.textPrimary },
  heroPurpose: { fontSize: 13, fontWeight: "600", marginTop: 4 },
  metaRow: {
    flexDirection: "row",
    marginTop: Spacing.md,
  },
  metaPill: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: Colors.surface,
    borderRadius: Radius.pill,
    paddingHorizontal: Spacing.md,
    paddingVertical: 6,
    marginHorizontal: Spacing.xs,
  },
  metaPillText: {
    fontSize: 11.5,
    fontWeight: "600",
    color: Colors.textPrimary,
    marginLeft: 4,
  },
  section: {
    paddingHorizontal: Spacing.lg,
    marginBottom: Spacing.xl,
  },
  sectionTitle: {
    fontSize: 16,
    fontWeight: "700",
    color: Colors.textPrimary,
    marginBottom: Spacing.sm,
  },
  samagriRow: {
    flexDirection: "row",
    alignItems: "center",
    marginBottom: Spacing.sm,
  },
  stepRow: {
    flexDirection: "row",
    marginBottom: Spacing.md,
  },
  stepNumber: {
    width: 26,
    height: 26,
    borderRadius: 13,
    backgroundColor: Colors.primary,
    alignItems: "center",
    justifyContent: "center",
    marginRight: Spacing.md,
    marginTop: 2,
  },
  stepNumberText: {
    color: Colors.textOnPrimary,
    fontSize: 12,
    fontWeight: "700",
  },
  stepTitle: {
    fontSize: 14,
    fontWeight: "700",
    color: Colors.textPrimary,
    marginBottom: 2,
  },
  mantraSanskrit: {
    fontSize: 16,
    fontWeight: "700",
    color: Colors.secondary,
  },
  aartiTitle: {
    fontSize: 15,
    fontWeight: "700",
    color: Colors.textPrimary,
  },
  audioButton: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: Colors.accentPink,
    borderRadius: Radius.pill,
    paddingVertical: Spacing.sm,
    marginTop: Spacing.md,
  },
  audioButtonText: {
    color: Colors.textOnPrimary,
    fontWeight: "700",
    fontSize: 13,
    marginLeft: Spacing.xs,
  },
});
