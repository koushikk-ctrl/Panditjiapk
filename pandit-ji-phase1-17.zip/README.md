# Pandit Ji — "Har Pooja, Har Vidhi — Ab Aapke Mobile Mein"

A digital Sanatan/Dharmic platform: daily sadhana, pooja library, sanatan
knowledge, jyotish, pandit booking, pooja samagri store, and an AI assistant.

## Project structure

```
pandit-ji/
├── mobile/     ← React Native (Expo) app — PHASE 1 (this delivery)
├── backend/    ← Node.js/Express API — later phase
├── admin/      ← Admin dashboard — later phase
└── README.md
```

## Build status

- [x] Phase 1: Project foundation + Home screen (mobile)
- [x] Phase 2: Navigation & reusable components (partially done alongside Phase 1)
- [x] Phase 3: Home screen polish
- [x] Phase 4: Pooja Library
- [x] Phase 5: Daily Sadhana (with AsyncStorage persistence, streak & monthly tracking)
- [x] Phase 6: Mantra & Audio (real playback via expo-av, favorites, recently played)
- [x] Phase 7: Festival Calendar (real 2026 dates, API-ready service layer)
- [x] Phase 8: Astrology / Jyotish (Kundli form, Panchang, Muhurat, Nakshatra — clearly labelled demo data)
- [x] Phase 9: Pandit Booking (browse, profile, booking form, my bookings, pandit dashboard demo)
- [x] Phase 10: Store & Cart (products, cart, checkout, mock payment — Razorpay-ready)

- [x] Phase 11: Node.js/Express backend (working API, in-memory data, auth & AI explicitly stubbed)
- [x] Phase 12: MongoDB connected (real persistence for Poojas, Mantras, Festivals, Pandits, Products, Bookings, Cart, Orders)
- [x] Phase 13: Authentication (bcrypt password hashing, JWT, roles: user/pandit/admin; bookings/cart/orders now require login and are scoped to the logged-in person)
- [x] Phase 14: Admin dashboard (React + Vite web app in `admin/`: CRUD for poojas, mantras, festivals, articles, products, pandit approval, bookings, orders, users, notifications)
- [x] Phase 15: Pandit Ji AI assistant (server-side LLM call, mobile chat screen with disclaimer)
- [x] Phase 16: Testing pass (static checks, AI validation tests, manual checklist in `TESTING.md`)
- [x] Phase 17: Production setup (Dockerfile, EAS config, production safety checks, `DEPLOYMENT.md`)

## Mobile frontend phases done (1-10)

The mobile app (`mobile/`) is feature-complete for the frontend-only phases of this plan.

## Backend phases (11+)

`backend/` is a real, runnable Express + TypeScript API backed by a real MongoDB database — see `backend/README.md` for setup (including getting MongoDB running locally via Docker), seeding starter data, and a full list of example `curl` commands to test every endpoint.

It is **not yet connected to the mobile app**: the mobile app still uses its own local demo data for every screen. The backend now has everything needed to connect for real (a working auth flow, per-user data), but wiring up real login/signup screens and swapping every mobile screen over to call the API is bigger than one phase and comes later.
- [ ] Phase 11+: Backend, DB, Auth, Admin, AI, Testing, Production

See `mobile/README.md` for how to run what's built so far.
