import mongoose from "mongoose";
import { env } from "../config/env";
import { Pooja } from "../models/Pooja";
import { Mantra } from "../models/Mantra";
import { Festival } from "../models/Festival";
import { Pandit } from "../models/Pandit";
import { Product } from "../models/Product";
import { User } from "../models/User";
import { Article } from "../models/Article";

import { poojas } from "../data/poojas";
import { mantras } from "../data/mantras";
import { festivals } from "../data/festivals";
import { pandits } from "../data/pandits";
import { products } from "../data/products";

// DEV-ONLY demo accounts, one per role, so auth can be tested immediately
// after seeding without registering manually first. Never do this in a
// real production seed script.
const DEMO_PASSWORD = "password123";
const demoArticles = [
  {
    slug: "what-is-dharma",
    title: "धर्म क्या है?",
    category: "Dharma",
    shortDescription: "धर्म की संक्षिप्त एवं सरल व्याख्या।",
    content: "धर्म का अर्थ केवल पूजा-पाठ नहीं, बल्कि सही आचरण और कर्तव्य पालन भी है...",
  },
  {
    slug: "intro-to-vedas",
    title: "वेदों का परिचय",
    category: "Vedas",
    shortDescription: "चार वेदों का संक्षिप्त परिचय।",
    content: "वेद सनातन धर्म के सबसे प्राचीन ग्रंथ माने जाते हैं...",
  },
];

const demoUsers = [
  { name: "Test User", email: "user@test.com", password: DEMO_PASSWORD, role: "user" as const },
  { name: "Pandit Ramesh Sharma", email: "pandit@test.com", password: DEMO_PASSWORD, role: "pandit" as const },
  { name: "Admin", email: "admin@test.com", password: DEMO_PASSWORD, role: "admin" as const },
];

/**
 * Populates MongoDB with the same demo data the API used to serve from
 * in-memory arrays (src/data/*.ts) before Phase 12. Safe to re-run — it
 * clears each collection first, so running `npm run seed` again just
 * resets back to this starter data.
 *
 * Run with: npm run seed
 */
async function seed() {
  // The seed script DELETES existing data and creates demo accounts with a known password.
  if (env.isProduction) {
    console.error("❌ Refusing to run the seed script with NODE_ENV=production.");
    process.exit(1);
  }

  if (!env.mongodbUri) {
    console.error("❌ MONGODB_URI is not set. Copy .env.example to .env first.");
    process.exit(1);
  }

  await mongoose.connect(env.mongodbUri);
  console.log(`✅ Connected to MongoDB (${mongoose.connection.name})`);

  await Promise.all([
    Pooja.deleteMany({}),
    Mantra.deleteMany({}),
    Festival.deleteMany({}),
    Pandit.deleteMany({}),
    Product.deleteMany({}),
    User.deleteMany({}),
    Article.deleteMany({}),
  ]);
  console.log("🧹 Cleared existing Pooja/Mantra/Festival/Pandit/Product/User/Article collections");

  await Pooja.insertMany(poojas.map(({ id, ...rest }) => ({ slug: id, ...rest })));
  console.log(`🕉️  Seeded ${poojas.length} poojas`);

  await Mantra.insertMany(mantras.map(({ id, ...rest }) => ({ slug: id, ...rest })));
  console.log(`📿 Seeded ${mantras.length} mantras`);

  await Festival.insertMany(festivals.map(({ id, ...rest }) => ({ slug: id, ...rest })));
  console.log(`🪔 Seeded ${festivals.length} festivals`);

  await Pandit.insertMany(pandits.map(({ id, ...rest }) => ({ slug: id, ...rest })));
  console.log(`🙏 Seeded ${pandits.length} pandits`);

  await Product.insertMany(products.map(({ id, ...rest }) => ({ slug: id, ...rest })));
  console.log(`🛍️  Seeded ${products.length} products`);

  await Article.insertMany(demoArticles);
  console.log(`📰 Seeded ${demoArticles.length} articles`);

  // Create one demo account per role. User.create() (not insertMany) so the
  // model's pre-save hook actually hashes each password.
  const createdUsers = [];
  for (const u of demoUsers) {
    createdUsers.push(await User.create(u));
  }
  console.log(`👤 Seeded ${createdUsers.length} demo accounts (user/pandit/admin), all with password "${DEMO_PASSWORD}"`);

  // Link the demo pandit *account* to an existing Pandit *profile* so the
  // pandit-role booking view (see bookingController.listBookings) has
  // something real to show immediately.
  const panditUser = createdUsers.find((u) => u.role === "pandit");
  if (panditUser) {
    await Pandit.updateOne({ slug: "pandit-ramesh-sharma" }, { user: panditUser._id });
    console.log(`🔗 Linked demo pandit account to Pandit profile "pandit-ramesh-sharma"`);
  }

  console.log("✅ Done! Database is ready.");
  await mongoose.disconnect();
  process.exit(0);
}

seed().catch((err) => {
  console.error("❌ Seeding failed:", err);
  process.exit(1);
});
