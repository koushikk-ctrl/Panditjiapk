import dotenv from "dotenv";

dotenv.config();

export const env = {
  port: parseInt(process.env.PORT || "5000", 10),
  nodeEnv: process.env.NODE_ENV || "development",
  corsOrigin: process.env.CORS_ORIGIN || "*",

  // Added in Phase 12
  mongodbUri: process.env.MONGODB_URI || "",

  // Added in Phase 13
  jwtSecret: process.env.JWT_SECRET || "",
  jwtExpiresIn: process.env.JWT_EXPIRES_IN || "7d",

  // Added in Phase 15
  anthropicApiKey: process.env.ANTHROPIC_API_KEY || "",
  anthropicModel: process.env.ANTHROPIC_MODEL || "claude-sonnet-5-5",

  isProduction: process.env.NODE_ENV === "production",
};

/**
 * Refuses to boot in production with unsafe settings, so a forgotten
 * secret or a wide-open CORS rule is caught at startup, not after launch.
 */
export function validateProductionEnv(): void {
  if (!env.isProduction) return;

  const problems: string[] = [];
  if (!env.mongodbUri) problems.push("MONGODB_URI is not set");
  if (env.jwtSecret.length < 32 || env.jwtSecret.startsWith("replace-with"))
    problems.push("JWT_SECRET must be a random string of at least 32 characters");
  if (env.corsOrigin === "*")
    problems.push("CORS_ORIGIN must list your real admin/web origins (not *) in production");

  if (problems.length) {
    console.error("❌ Unsafe production configuration:\n - " + problems.join("\n - "));
    process.exit(1);
  }
}
