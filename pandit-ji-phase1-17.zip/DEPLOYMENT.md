# PANDIT JI — Production guide (Phase 17)

> None of this has been executed from the build sandbox (no network/package access). Treat the
> first deploy as a staging run and fix anything it surfaces.

## 1. Database — MongoDB Atlas
1. Create a free/paid cluster at mongodb.com/atlas, create a DB user with a strong password.
2. Network access: allow only your backend host's IP (avoid 0.0.0.0/0 if you can).
3. Copy the connection string; it becomes `MONGODB_URI` (keep it ending in `/pandit-ji`).
4. **Never run `npm run seed` against production** (it now refuses when `NODE_ENV=production`).
   Create your first admin by registering normally, then promote that user in Atlas
   (set `role: "admin"` on the document). Delete any demo accounts.

## 2. Backend (Docker, on Render / Railway / Fly.io / a VPS)
Environment variables to set in the host's dashboard (never in git):
| Variable | Value |
|---|---|
| `NODE_ENV` | `production` |
| `MONGODB_URI` | Atlas connection string |
| `JWT_SECRET` | `node -e "console.log(require('crypto').randomBytes(48).toString('hex'))"` |
| `CORS_ORIGIN` | your admin URL, e.g. `https://admin.yourdomain.com` (comma-separate several) |
| `ANTHROPIC_API_KEY` | your key (server-side only) |

The server **refuses to start** in production if the JWT secret is weak/default, MONGODB_URI is missing,
or CORS is `*`.
```bash
cd backend
docker build -t pandit-ji-api .
docker run -p 5000:5000 --env-file .env pandit-ji-api    # local smoke test
```
Serve it over HTTPS (Render/Railway/Fly do this automatically). Check `https://YOUR-API/api/health`.

## 3. Admin dashboard (static site on Netlify / Vercel / Cloudflare Pages)
```bash
cd admin
cp .env.example .env      # set VITE_API_URL=https://YOUR-API/api
npm run build             # output in admin/dist
```
Upload `admin/dist`. Add a rewrite of all paths to `/index.html` (single-page app routing).

## 4. Mobile app (Expo EAS)
```bash
npm install -g eas-cli
cd mobile
eas login
eas build:configure
```
1. Edit `mobile/eas.json`: set `EXPO_PUBLIC_API_URL` for the `preview` and `production` profiles.
2. Add real app icon, adaptive icon and splash images and reference them in `app.json`
   (`icon`, `android.adaptiveIcon.foregroundImage`, `splash.image`). The store builds need them.
3. Test build (Android APK to share): `eas build --profile preview --platform android`
4. Store build: `eas build --profile production --platform all`, then `eas submit`.
   Google Play needs a developer account (one-time fee); Apple needs the Apple Developer Program (yearly fee).
5. Bundle IDs are `com.panditji.app`; change if you want your own.

## 5. Pre-launch checklist
- [ ] Mobile app is wired to the backend with login/signup (NOT done yet: still local demo data)
- [ ] Demo accounts deleted; real admin created; seed never run in production
- [ ] `JWT_SECRET` and API keys only in host environment variables; `.env` not in git
- [ ] CORS limited to real origins; HTTPS everywhere
- [ ] `ANTHROPIC_API_KEY` has a spend limit set in the provider console; add `protect` to `/api/ai/chat` once login exists
- [ ] Jyotish screens still say "demo data" (no real calculations), or are wired to a real, licensed source
- [ ] Audio: replace placeholder audio with content you have the right to use
- [ ] Razorpay (payments): keys server-side only, create orders and verify signatures on the backend. Mock payment is still in place.
- [ ] Push notifications: not implemented (admin only records them)
- [ ] Privacy policy + terms published (required by both app stores; you collect names, emails, phone numbers, addresses)
- [ ] MongoDB backups enabled in Atlas
- [ ] Error monitoring (e.g. Sentry) and uptime check on `/api/health`
- [ ] Run everything in `TESTING.md` against the staging deployment
