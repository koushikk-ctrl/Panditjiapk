# PANDIT JI — Testing checklist (Phase 16)

## Automated
```bash
cd backend && npm install && npm test     # AI input validation (4 tests)
```
Also run once after `npm install` in each project to catch type errors:
```bash
cd backend && npx tsc --noEmit
cd admin   && npx tsc --noEmit
cd mobile  && npx tsc --noEmit
```

## Backend (with MongoDB running and `npm run seed` done)
- [ ] `GET /api/health` returns success
- [ ] `GET /api/poojas`, `/mantras`, `/festivals`, `/pandits`, `/products`, `/articles` return seeded data
- [ ] `POST /api/auth/login` with user@test.com / password123 returns a token; wrong password gives 401
- [ ] `GET /api/bookings` without a token gives 401
- [ ] A normal user token gets 403 on `POST /api/poojas` and `GET /api/users`
- [ ] 11+ rapid login attempts get rate-limited (429)
- [ ] `POST /api/ai/chat` with no API key gives a clear 500 message; with a key it returns `reply` + `disclaimer`

## Admin (http://localhost:5173)
- [ ] user@test.com is rejected; admin@test.com works
- [ ] Dashboard shows counts
- [ ] Create, edit and delete a pooja, mantra, festival, article and product
- [ ] Approve and revoke a pandit
- [ ] Change booking and order statuses
- [ ] Send a notification, and see it in history
- [ ] Refresh the page: still logged in; Logout returns to login

## Mobile (Expo Go)
- [ ] All 5 tabs open; More menu links all work
- [ ] Sadhana ticks persist after closing the app
- [ ] Audio plays, mini player persists across screens
- [ ] Add to cart, change quantity, checkout (mock)
- [ ] Create a booking, see it in My Bookings
- [ ] Pandit Ji AI: disclaimer visible, answers appear, offline shows error bubble
- [ ] Airplane mode: screens show friendly errors/empty states, no crashes

## Known limitations
- The mobile app still uses local demo data and has no login screens (not wired to the backend yet).
- Jyotish (Panchang, Muhurat, Nakshatra, Kundli) is clearly labelled demo data, not real calculations.
- Notifications are recorded only; Expo push delivery is not implemented.
- Payments are mocked; Razorpay is not connected.
