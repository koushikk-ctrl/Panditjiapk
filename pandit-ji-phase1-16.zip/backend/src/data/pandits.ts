// Used only by the seed script (src/utils/seed.ts) to populate MongoDB.
export const pandits = [
  {
    id: "pandit-ramesh-sharma",
    name: "पं. रमेश शर्मा",
    experienceYears: 22,
    city: "इंदौर",
    languages: ["हिंदी", "संस्कृत"],
    specialties: ["griha-pravesh", "satyanarayan-katha", "havan"],
    rating: 4.8,
    startingPrice: 2100,
  },
  {
    id: "pandit-suresh-tripathi",
    name: "पं. सुरेश त्रिपाठी",
    experienceYears: 15,
    city: "भोपाल",
    languages: ["हिंदी", "संस्कृत", "अंग्रेज़ी"],
    specialties: ["marriage-rituals", "naamkaran", "mundan"],
    rating: 4.6,
    startingPrice: 5100,
  },
  {
    id: "pandit-omprakash-dubey",
    name: "पं. ओमप्रकाश दुबे",
    experienceYears: 30,
    city: "उज्जैन",
    languages: ["हिंदी", "संस्कृत"],
    specialties: ["shradh", "shiv-pooja", "havan"],
    rating: 4.9,
    startingPrice: 1800,
  },
];
