// Used only by the seed script (src/utils/seed.ts) to populate MongoDB.
export const mantras = [
  { id: "ganesh-mantra", title: "गणेश मंत्र", sanskrit: "ॐ गं गणपतये नमः", meaning: "विघ्नहर्ता गणेश जी को नमन।", deity: "गणेश" },
  { id: "shiv-mantra", title: "शिव पंचाक्षर मंत्र", sanskrit: "ॐ नमः शिवाय", meaning: "भगवान शिव को नमन।", deity: "शिव" },
  { id: "vishnu-mantra", title: "विष्णु मंत्र", sanskrit: "ॐ नमो भगवते वासुदेवाय", meaning: "भगवान विष्णु को नमन।", deity: "विष्णु" },
  { id: "lakshmi-mantra", title: "लक्ष्मी मंत्र", sanskrit: "ॐ श्रीं महालक्ष्म्यै नमः", meaning: "माँ लक्ष्मी को नमन।", deity: "लक्ष्मी" },
];
