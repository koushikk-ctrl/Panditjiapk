// DEMO DATA ONLY — see note in the mobile app's astrologyData.ts. Real
// panchang/astrology calculations must come from a licensed provider.

export const demoPanchang = {
  date: "25 सितंबर 2026, शुक्रवार",
  tithi: "भाद्रपद कृष्ण त्रयोदशी",
  nakshatra: "पुष्य",
  yoga: "सिद्धि",
  karana: "गर",
  sunrise: "06:12 AM",
  sunset: "06:24 PM",
  rahuKaal: "10:45 AM – 12:15 PM",
  abhijitMuhurat: "11:52 AM – 12:40 PM",
};

export const demoMuhurats = [
  { id: "griha-pravesh", purpose: "गृह प्रवेश", date: "2026-10-03", timeWindow: "07:15 – 09:30" },
  { id: "vivah", purpose: "विवाह", date: "2026-11-18", timeWindow: "20:00 – 22:00" },
  { id: "vehicle-purchase", purpose: "वाहन क्रय", date: "2026-11-08", timeWindow: "पूरे दिन शुभ" },
];
