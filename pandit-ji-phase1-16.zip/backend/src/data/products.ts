// Used only by the seed script (src/utils/seed.ts) to populate MongoDB.
export const products = [
  { id: "incense-sticks", name: "अगरबत्ती (चंदन)", category: "samagri", price: 60, discountPercent: 10, stock: 120 },
  { id: "camphor-pack", name: "कपूर पैक", category: "samagri", price: 35, discountPercent: 0, stock: 180 },
  { id: "ganesh-pooja-kit", name: "गणेश पूजा किट", category: "kit", price: 499, discountPercent: 15, stock: 40 },
  { id: "bhagavad-gita-hindi", name: "श्रीमद्भगवद्गीता (हिंदी टीका सहित)", category: "book", price: 220, discountPercent: 0, stock: 90 },
  { id: "rudraksha-mala", name: "रुद्राक्ष माला (108 मनके)", category: "spiritual", price: 349, discountPercent: 12, stock: 55 },
];
