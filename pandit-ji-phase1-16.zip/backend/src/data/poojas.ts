// Used only by the seed script (src/utils/seed.ts) to populate MongoDB.
// Controllers now query MongoDB directly via src/models/Pooja.ts.
export const poojas = [
  {
    id: "ganesh-pooja",
    name: "गणेश पूजा",
    category: "गणेश",
    purpose: "विघ्नों को दूर करने के लिए",
    duration: "30–40 मिनट",
    bestTime: "प्रातःकाल या शुभ मुहूर्त में",
    samagri: ["गणेश प्रतिमा", "रोली, अक्षत", "दूर्वा घास", "मोदक", "धूप, दीप"],
    vidhiSteps: ["तैयारी", "संकल्प", "आवाहन", "पूजन", "नैवेद्य", "आरती", "प्रार्थना"],
    mantras: ["ॐ गं गणपतये नमः"],
  },
  {
    id: "shiv-pooja",
    name: "शिव पूजा",
    category: "शिव",
    purpose: "शांति व मोक्ष की प्राप्ति के लिए",
    duration: "30–45 मिनट",
    bestTime: "प्रातःकाल या प्रदोष काल में",
    samagri: ["शिवलिंग", "गंगाजल", "बेलपत्र", "सफेद पुष्प", "धूप, दीप"],
    vidhiSteps: ["तैयारी", "संकल्प", "अभिषेक", "बेलपत्र अर्पण", "मंत्र जाप", "आरती"],
    mantras: ["ॐ नमः शिवाय"],
  },
  {
    id: "durga-pooja",
    name: "दुर्गा पूजा",
    category: "दुर्गा",
    purpose: "शक्ति व रक्षा के लिए",
    duration: "40–60 मिनट",
    bestTime: "प्रातःकाल या संध्या समय",
    samagri: ["दुर्गा प्रतिमा", "लाल चुनरी", "कुमकुम", "नारियल", "घी/तेल"],
    vidhiSteps: ["कलश स्थापना", "संकल्प", "श्रृंगार", "पूजन", "आरती"],
    mantras: ["ॐ दुं दुर्गायै नमः"],
  },
];
