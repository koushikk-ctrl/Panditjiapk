// Used only by the seed script (src/utils/seed.ts) to populate MongoDB.
// Dates for the 2026 calendar year (same references as the mobile app's
// festivalData.ts). PRODUCTION: compute from a licensed panchang provider.
export const festivals = [
  { id: "mahashivratri", name: "महाशिवरात्रि", date: "2026-02-16", tithi: "फाल्गुन कृष्ण चतुर्दशी" },
  { id: "holi", name: "होली", date: "2026-03-03", tithi: "फाल्गुन पूर्णिमा" },
  { id: "ram-navami", name: "राम नवमी", date: "2026-03-27", tithi: "चैत्र शुक्ल नवमी" },
  { id: "janmashtami", name: "जन्माष्टमी", date: "2026-08-23", tithi: "भाद्रपद कृष्ण अष्टमी" },
  { id: "ganesh-chaturthi", name: "गणेश चतुर्थी", date: "2026-09-02", tithi: "भाद्रपद शुक्ल चतुर्थी" },
  { id: "navratri", name: "शारदीय नवरात्रि", date: "2026-10-12", tithi: "आश्विन शुक्ल प्रतिपदा" },
  { id: "diwali", name: "दीपावली", date: "2026-11-08", tithi: "कार्तिक अमावस्या" },
];
