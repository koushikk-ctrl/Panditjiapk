import jwt from "jsonwebtoken";
import { env } from "../config/env";
import { ApiError } from "./ApiError";
import { UserRole } from "../models/User";

export type TokenPayload = { id: string; role: UserRole };

export function generateToken(payload: TokenPayload): string {
  if (!env.jwtSecret) {
    throw ApiError.internal(
      "JWT_SECRET is not set on the server. Copy backend/.env.example to backend/.env, set JWT_SECRET, and restart."
    );
  }
  return jwt.sign(payload, env.jwtSecret, { expiresIn: env.jwtExpiresIn } as jwt.SignOptions);
}

export function verifyToken(token: string): TokenPayload {
  if (!env.jwtSecret) {
    throw ApiError.internal("JWT_SECRET is not set on the server.");
  }
  return jwt.verify(token, env.jwtSecret) as TokenPayload;
}
