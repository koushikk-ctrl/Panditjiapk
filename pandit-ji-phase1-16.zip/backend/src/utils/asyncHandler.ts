import { Request, Response, NextFunction, RequestHandler } from "express";

/**
 * Wraps an async controller so a thrown/rejected error is forwarded to
 * Express's error-handling middleware instead of crashing the process or
 * requiring a try/catch in every single controller.
 *
 * Usage: router.get("/", asyncHandler(async (req, res) => { ... }));
 */
export function asyncHandler(fn: RequestHandler): RequestHandler {
  return (req: Request, res: Response, next: NextFunction) => {
    Promise.resolve(fn(req, res, next)).catch(next);
  };
}
