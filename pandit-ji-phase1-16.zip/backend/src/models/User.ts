import { Schema, model, Document } from "mongoose";
import bcrypt from "bcryptjs";

export type UserRole = "user" | "pandit" | "admin";

export interface UserDocument extends Document {
  name: string;
  email: string;
  phone?: string;
  password: string;
  role: UserRole;
  comparePassword(candidate: string): Promise<boolean>;
}

const userSchema = new Schema<UserDocument>(
  {
    name: { type: String, required: true, trim: true },
    email: {
      type: String,
      required: true,
      unique: true,
      lowercase: true,
      trim: true,
      match: [/^\S+@\S+\.\S+$/, "Please provide a valid email"],
    },
    // OTP-ready architecture: phone is stored but OTP verification flow
    // itself isn't implemented yet — email/password is the working path
    // for now, matching "Email/mobile login, OTP-ready architecture" from
    // the mobile app's auth requirements.
    phone: { type: String, trim: true },
    password: { type: String, required: true, minlength: 6, select: false },
    role: { type: String, enum: ["user", "pandit", "admin"], default: "user" },
  },
  { timestamps: true }
);

// Hash the password automatically whenever it's set/changed — controllers
// never hash passwords themselves, which avoids ever accidentally storing
// one in plain text.
userSchema.pre("save", async function (next) {
  if (!this.isModified("password")) return next();
  const salt = await bcrypt.genSalt(10);
  this.password = await bcrypt.hash(this.password, salt);
  next();
});

userSchema.methods.comparePassword = function (candidate: string) {
  return bcrypt.compare(candidate, this.password);
};

export const User = model<UserDocument>("User", userSchema);
