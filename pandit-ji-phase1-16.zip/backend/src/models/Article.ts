import { Schema, model } from "mongoose";

const articleSchema = new Schema(
  {
    slug: { type: String, required: true, unique: true, lowercase: true, trim: true },
    title: { type: String, required: true, trim: true },
    category: { type: String, required: true, trim: true },
    imageUrl: { type: String },
    shortDescription: { type: String, required: true },
    content: { type: String, required: true },
  },
  { timestamps: true }
);

articleSchema.index({ category: 1 });

export const Article = model("Article", articleSchema);
