import { Schema, model } from "mongoose";

const festivalSchema = new Schema(
  {
    slug: { type: String, required: true, unique: true, lowercase: true, trim: true },
    name: { type: String, required: true, trim: true },
    // Stored as a plain ISO date string (yyyy-mm-dd) to match the mobile
    // app's date handling. PRODUCTION TODO: compute/update this from a
    // licensed panchang provider instead of storing it statically.
    date: { type: String, required: true },
    tithi: { type: String, required: true },
  },
  { timestamps: true }
);

festivalSchema.index({ date: 1 });

export const Festival = model("Festival", festivalSchema);
