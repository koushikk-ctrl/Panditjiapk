import { Schema, model } from "mongoose";

const poojaSchema = new Schema(
  {
    slug: { type: String, required: true, unique: true, lowercase: true, trim: true },
    name: { type: String, required: true, trim: true },
    category: { type: String, required: true, trim: true },
    purpose: { type: String, required: true },
    duration: { type: String, required: true },
    bestTime: { type: String, required: true },
    samagri: { type: [String], default: [] },
    vidhiSteps: { type: [String], default: [] },
    mantras: { type: [String], default: [] },
  },
  { timestamps: true }
);

poojaSchema.index({ category: 1 });

export const Pooja = model("Pooja", poojaSchema);
