import { Schema, model } from "mongoose";

// PRODUCTION TODO: real delivery needs Expo push tokens registered per device
// and a push-send step in the controller. For now this records that an admin
// "sent" something so the dashboard has a working send + history flow.
const notificationSchema = new Schema(
  {
    title: { type: String, required: true, trim: true },
    message: { type: String, required: true },
    audience: { type: String, enum: ["all", "users", "pandits"], default: "all" },
    sentBy: { type: Schema.Types.ObjectId, ref: "User", required: true },
  },
  { timestamps: true }
);

export const Notification = model("Notification", notificationSchema);
