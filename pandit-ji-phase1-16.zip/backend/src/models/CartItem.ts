import { Schema, model } from "mongoose";

// PHASE 13: once auth exists, add a required `user` field and scope all
// queries to req.user.id so each person has their own cart. Until then this
// is a single shared cart, matching the behavior from Phase 11's in-memory
// version — it just now survives server restarts.
const cartItemSchema = new Schema(
  {
    product: { type: Schema.Types.ObjectId, ref: "Product", required: true },
    quantity: { type: Number, required: true, min: 1 },
    user: { type: Schema.Types.ObjectId, ref: "User" },
  },
  { timestamps: true }
);

cartItemSchema.index({ product: 1 });

export const CartItem = model("CartItem", cartItemSchema);
