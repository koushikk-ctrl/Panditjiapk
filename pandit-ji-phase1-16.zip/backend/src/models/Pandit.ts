import { Schema, model } from "mongoose";

const panditSchema = new Schema(
  {
    slug: { type: String, required: true, unique: true, lowercase: true, trim: true },
    name: { type: String, required: true, trim: true },
    experienceYears: { type: Number, required: true, min: 0 },
    city: { type: String, required: true, trim: true },
    languages: { type: [String], default: [] },
    specialties: { type: [String], default: [] },
    rating: { type: Number, default: 0, min: 0, max: 5 },
    startingPrice: { type: Number, required: true, min: 0 },

    // Added for forward-compatibility with Phase 13 (Auth) and Phase 14
    // (Admin approval workflow) — unused by the API until then.
    user: { type: Schema.Types.ObjectId, ref: "User" },
    isApproved: { type: Boolean, default: true }, // true for now since there's no registration flow yet
  },
  { timestamps: true }
);

panditSchema.index({ city: 1 });
panditSchema.index({ specialties: 1 });

export const Pandit = model("Pandit", panditSchema);
