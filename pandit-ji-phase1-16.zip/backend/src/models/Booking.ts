import { Schema, model } from "mongoose";

const bookingSchema = new Schema(
  {
    pandit: { type: Schema.Types.ObjectId, ref: "Pandit", required: true },
    poojaType: { type: String, required: true },
    date: { type: String, required: true },
    time: { type: String, required: true },
    location: { type: String, required: true },
    specialInstructions: { type: String },
    status: {
      type: String,
      enum: ["pending", "confirmed", "completed", "cancelled"],
      default: "pending",
    },

    // Added for forward-compatibility with Phase 13 (Auth) — once a user
    // is authenticated, this will be set from req.user.id instead of being
    // left empty, and bookings will be filtered per-user.
    user: { type: Schema.Types.ObjectId, ref: "User" },
  },
  { timestamps: true }
);

bookingSchema.index({ pandit: 1, status: 1 });

export const Booking = model("Booking", bookingSchema);
