import { Schema, model } from "mongoose";

const mantraSchema = new Schema(
  {
    slug: { type: String, required: true, unique: true, lowercase: true, trim: true },
    title: { type: String, required: true, trim: true },
    sanskrit: { type: String, required: true },
    meaning: { type: String, required: true },
    deity: { type: String, trim: true },
  },
  { timestamps: true }
);

mantraSchema.index({ deity: 1 });

export const Mantra = model("Mantra", mantraSchema);
