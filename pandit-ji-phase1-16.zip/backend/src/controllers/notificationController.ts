import { Request, Response } from "express";
import { Notification } from "../models/Notification";
import { ApiError } from "../utils/ApiError";

export async function listNotifications(req: Request, res: Response) {
  res.json({ success: true, data: await Notification.find().sort({ createdAt: -1 }) });
}

export async function sendNotification(req: Request, res: Response) {
  const { title, message, audience } = req.body;
  if (!title || !message) throw ApiError.badRequest("title and message are required");

  // PRODUCTION TODO: deliver via Expo push notifications here, using device
  // push tokens registered by the mobile app. For now this only records it.
  const notification = await Notification.create({
    title,
    message,
    audience: audience || "all",
    sentBy: req.user!.id,
  });
  res.status(201).json({ success: true, data: notification });
}
