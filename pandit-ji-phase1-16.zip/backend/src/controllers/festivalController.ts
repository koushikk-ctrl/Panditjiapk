import { Request, Response } from "express";
import { Festival } from "../models/Festival";
import { ApiError } from "../utils/ApiError";

export async function listFestivals(req: Request, res: Response) {
  res.json({ success: true, data: await Festival.find().sort({ date: 1 }) });
}

export async function getFestivalById(req: Request, res: Response) {
  const item = await Festival.findOne({ slug: req.params.id });
  if (!item) throw ApiError.notFound("Festival not found");
  res.json({ success: true, data: item });
}

// --- Admin-only below (routes gate these with authorize("admin")) ---

export async function createFestival(req: Request, res: Response) {
  const item = await Festival.create(req.body);
  res.status(201).json({ success: true, data: item });
}

export async function updateFestival(req: Request, res: Response) {
  const item = await Festival.findOneAndUpdate({ slug: req.params.id }, req.body, { new: true, runValidators: true });
  if (!item) throw ApiError.notFound("Festival not found");
  res.json({ success: true, data: item });
}

export async function deleteFestival(req: Request, res: Response) {
  const item = await Festival.findOneAndDelete({ slug: req.params.id });
  if (!item) throw ApiError.notFound("Festival not found");
  res.json({ success: true, data: { deleted: true } });
}
