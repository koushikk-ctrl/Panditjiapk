import { Request, Response } from "express";
import { ApiError } from "../utils/ApiError";
import { demoMuhurats } from "../data/astrology";

export function getMuhurats(req: Request, res: Response) {
  res.json({ success: true, data: demoMuhurats });
}

export function generateKundli(req: Request, res: Response) {
  const { name, dob, tob, place } = req.body;
  if (!name || !dob || !tob || !place) {
    throw ApiError.badRequest("name, dob, tob, and place are required");
  }

  // DEMO RESULT ONLY. A real implementation needs an ephemeris-based Vedic
  // astrology calculation library or licensed API — never invent real
  // astronomical results here.
  res.json({
    success: true,
    data: {
      rashi: "मेष (Aries)",
      nakshatra: "अश्विनी",
      lagna: "वृषभ (Taurus)",
      nakshatraPada: 2,
      summary: "यह एक उदाहरण परिणाम है। वास्तविक गणना हेतु भविष्य में प्रमाणित ज्योतिष API जोड़ी जाएगी।",
    },
  });
}
