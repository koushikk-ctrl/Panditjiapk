import { Request, Response } from "express";
import { User } from "../models/User";
import { ApiError } from "../utils/ApiError";
import { generateToken } from "../utils/generateToken";

function toSafeUser(user: InstanceType<typeof User>) {
  return {
    id: user._id,
    name: user.name,
    email: user.email,
    phone: user.phone,
    role: user.role,
  };
}

export async function register(req: Request, res: Response) {
  const { name, email, password, phone, role } = req.body;

  if (!name || !email || !password) {
    throw ApiError.badRequest("name, email, and password are required");
  }
  if (password.length < 6) {
    throw ApiError.badRequest("Password must be at least 6 characters");
  }

  const existing = await User.findOne({ email: email.toLowerCase() });
  if (existing) {
    throw ApiError.badRequest("An account with this email already exists");
  }

  // Only "user" and "pandit" can self-register; "admin" accounts must be
  // created directly in the database or promoted by an existing admin
  // (once the admin dashboard exists in Phase 14) — never from a public API.
  const safeRole = role === "pandit" ? "pandit" : "user";

  const user = await User.create({ name, email: email.toLowerCase(), password, phone, role: safeRole });
  const token = generateToken({ id: user._id.toString(), role: user.role });

  res.status(201).json({ success: true, data: { user: toSafeUser(user), token } });
}

export async function login(req: Request, res: Response) {
  const { email, password } = req.body;
  if (!email || !password) {
    throw ApiError.badRequest("email and password are required");
  }

  const user = await User.findOne({ email: email.toLowerCase() }).select("+password");
  if (!user) throw ApiError.unauthorized("Invalid email or password");

  const isMatch = await user.comparePassword(password);
  if (!isMatch) throw ApiError.unauthorized("Invalid email or password");

  const token = generateToken({ id: user._id.toString(), role: user.role });
  res.json({ success: true, data: { user: toSafeUser(user), token } });
}

export async function getMe(req: Request, res: Response) {
  const user = await User.findById(req.user!.id);
  if (!user) throw ApiError.notFound("User not found");
  res.json({ success: true, data: toSafeUser(user) });
}
