import { Request, Response } from "express";
import { demoPanchang } from "../data/astrology";

// DEMO DATA — see data/astrology.ts. A real implementation would calculate
// this from a licensed panchang provider based on the requested date/location.
export function getTodayPanchang(req: Request, res: Response) {
  res.json({ success: true, data: demoPanchang });
}
