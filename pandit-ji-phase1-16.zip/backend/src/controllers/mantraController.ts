import { Request, Response } from "express";
import { Mantra } from "../models/Mantra";
import { ApiError } from "../utils/ApiError";

export async function listMantras(req: Request, res: Response) {
  res.json({ success: true, data: await Mantra.find().sort({ createdAt: -1 }) });
}

export async function getMantraById(req: Request, res: Response) {
  const item = await Mantra.findOne({ slug: req.params.id });
  if (!item) throw ApiError.notFound("Mantra not found");
  res.json({ success: true, data: item });
}

// --- Admin-only below (routes gate these with authorize("admin")) ---

export async function createMantra(req: Request, res: Response) {
  const item = await Mantra.create(req.body);
  res.status(201).json({ success: true, data: item });
}

export async function updateMantra(req: Request, res: Response) {
  const item = await Mantra.findOneAndUpdate({ slug: req.params.id }, req.body, { new: true, runValidators: true });
  if (!item) throw ApiError.notFound("Mantra not found");
  res.json({ success: true, data: item });
}

export async function deleteMantra(req: Request, res: Response) {
  const item = await Mantra.findOneAndDelete({ slug: req.params.id });
  if (!item) throw ApiError.notFound("Mantra not found");
  res.json({ success: true, data: { deleted: true } });
}
