import { Request, Response } from "express";
import { Booking } from "../models/Booking";
import { Pandit } from "../models/Pandit";
import { ApiError } from "../utils/ApiError";

export async function listBookings(req: Request, res: Response) {
  const { id: userId, role } = req.user!;

  let bookings;
  if (role === "admin") {
    // Admins see everything (full admin dashboard arrives in Phase 14).
    bookings = await Booking.find().populate("pandit").sort({ createdAt: -1 });
  } else if (role === "pandit") {
    // A pandit sees bookings made WITH them, not bookings they made as a
    // customer — resolve their own Pandit profile first.
    const panditProfile = await Pandit.findOne({ user: userId });
    if (!panditProfile) {
      return res.json({ success: true, data: [] }); // no linked pandit profile yet
    }
    bookings = await Booking.find({ pandit: panditProfile._id }).populate("pandit").sort({ createdAt: -1 });
  } else {
    bookings = await Booking.find({ user: userId }).populate("pandit").sort({ createdAt: -1 });
  }

  res.json({ success: true, data: bookings });
}

export async function createBooking(req: Request, res: Response) {
  const { panditId, poojaType, date, time, location, specialInstructions } = req.body;

  if (!panditId || !poojaType || !date || !time || !location) {
    throw ApiError.badRequest("panditId, poojaType, date, time, and location are required");
  }

  const pandit = await Pandit.findOne({ slug: panditId });
  if (!pandit) throw ApiError.notFound("Pandit not found");

  const booking = await Booking.create({
    pandit: pandit._id,
    poojaType,
    date,
    time,
    location,
    specialInstructions,
    user: req.user!.id,
  });

  const populated = await booking.populate("pandit");
  res.status(201).json({ success: true, data: populated });
}

const VALID_STATUSES = ["pending", "confirmed", "completed", "cancelled"];

/**
 * Updates a booking's status. Allowed for an admin (any booking) or the
 * pandit the booking was made WITH (via their linked Pandit profile).
 * Anyone else gets 403 — a regular user can't confirm their own booking.
 */
export async function updateBookingStatus(req: Request, res: Response) {
  const { status } = req.body;
  if (!VALID_STATUSES.includes(status)) {
    throw ApiError.badRequest(`status must be one of: ${VALID_STATUSES.join(", ")}`);
  }

  const booking = await Booking.findById(req.params.id).populate("pandit");
  if (!booking) throw ApiError.notFound("Booking not found");

  const { id: userId, role } = req.user!;
  // `as any`: TypeScript doesn't know booking.pandit was populated into a full document.
  const panditOwnsThisBooking = role === "pandit" && (booking.pandit as any)?.user?.toString() === userId;

  if (role !== "admin" && !panditOwnsThisBooking) {
    throw ApiError.forbidden("You don't have permission to update this booking.");
  }

  booking.status = status;
  await booking.save();
  res.json({ success: true, data: booking });
}
