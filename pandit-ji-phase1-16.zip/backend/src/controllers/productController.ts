import { Request, Response } from "express";
import { Product } from "../models/Product";
import { ApiError } from "../utils/ApiError";

export async function listProducts(req: Request, res: Response) {
  res.json({ success: true, data: await Product.find().sort({ createdAt: -1 }) });
}

export async function getProductById(req: Request, res: Response) {
  const item = await Product.findOne({ slug: req.params.id });
  if (!item) throw ApiError.notFound("Product not found");
  res.json({ success: true, data: item });
}

// --- Admin-only below (routes gate these with authorize("admin")) ---

export async function createProduct(req: Request, res: Response) {
  const item = await Product.create(req.body);
  res.status(201).json({ success: true, data: item });
}

export async function updateProduct(req: Request, res: Response) {
  const item = await Product.findOneAndUpdate({ slug: req.params.id }, req.body, { new: true, runValidators: true });
  if (!item) throw ApiError.notFound("Product not found");
  res.json({ success: true, data: item });
}

export async function deleteProduct(req: Request, res: Response) {
  const item = await Product.findOneAndDelete({ slug: req.params.id });
  if (!item) throw ApiError.notFound("Product not found");
  res.json({ success: true, data: { deleted: true } });
}
