import { Request, Response } from "express";
import { User } from "../models/User";

// Admin-only. Passwords are `select: false` on the model, so never returned.
export async function listUsers(req: Request, res: Response) {
  res.json({ success: true, data: await User.find().sort({ createdAt: -1 }) });
}
