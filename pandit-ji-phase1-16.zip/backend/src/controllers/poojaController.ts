import { Request, Response } from "express";
import { Pooja } from "../models/Pooja";
import { ApiError } from "../utils/ApiError";

export async function listPoojas(req: Request, res: Response) {
  res.json({ success: true, data: await Pooja.find().sort({ createdAt: -1 }) });
}

export async function getPoojaById(req: Request, res: Response) {
  const item = await Pooja.findOne({ slug: req.params.id });
  if (!item) throw ApiError.notFound("Pooja not found");
  res.json({ success: true, data: item });
}

// --- Admin-only below (routes gate these with authorize("admin")) ---

export async function createPooja(req: Request, res: Response) {
  const item = await Pooja.create(req.body);
  res.status(201).json({ success: true, data: item });
}

export async function updatePooja(req: Request, res: Response) {
  const item = await Pooja.findOneAndUpdate({ slug: req.params.id }, req.body, { new: true, runValidators: true });
  if (!item) throw ApiError.notFound("Pooja not found");
  res.json({ success: true, data: item });
}

export async function deletePooja(req: Request, res: Response) {
  const item = await Pooja.findOneAndDelete({ slug: req.params.id });
  if (!item) throw ApiError.notFound("Pooja not found");
  res.json({ success: true, data: { deleted: true } });
}
