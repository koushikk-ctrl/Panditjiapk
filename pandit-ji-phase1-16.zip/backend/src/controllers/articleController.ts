import { Request, Response } from "express";
import { Article } from "../models/Article";
import { ApiError } from "../utils/ApiError";

export async function listArticles(req: Request, res: Response) {
  res.json({ success: true, data: await Article.find().sort({ createdAt: -1 }) });
}

export async function getArticleById(req: Request, res: Response) {
  const item = await Article.findOne({ slug: req.params.id });
  if (!item) throw ApiError.notFound("Article not found");
  res.json({ success: true, data: item });
}

// --- Admin-only below (routes gate these with authorize("admin")) ---

export async function createArticle(req: Request, res: Response) {
  const item = await Article.create(req.body);
  res.status(201).json({ success: true, data: item });
}

export async function updateArticle(req: Request, res: Response) {
  const item = await Article.findOneAndUpdate({ slug: req.params.id }, req.body, { new: true, runValidators: true });
  if (!item) throw ApiError.notFound("Article not found");
  res.json({ success: true, data: item });
}

export async function deleteArticle(req: Request, res: Response) {
  const item = await Article.findOneAndDelete({ slug: req.params.id });
  if (!item) throw ApiError.notFound("Article not found");
  res.json({ success: true, data: { deleted: true } });
}
