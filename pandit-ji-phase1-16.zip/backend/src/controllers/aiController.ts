import { Request, Response } from "express";
import { ApiError } from "../utils/ApiError";
import { env } from "../config/env";

export const AI_DISCLAIMER =
  "AI assistant for informational and devotional guidance. For complex religious matters, consult a qualified Pandit.";

const SYSTEM_PROMPT = `You are "Pandit Ji AI", an AI assistant inside a Sanatan Dharma devotional app.
Rules:
- You are an AI, NOT a priest or pandit. Never claim to be one, never claim personal spiritual authority, and never say you performed or can perform a ritual.
- Help with: pooja vidhi and samagri, meanings of festivals, general mantra meanings, Sanatan Dharma concepts, and how to use the app.
- Be respectful of all traditions; where practices differ by region or sampradaya, say so.
- Do not give definitive astrology predictions, medical, legal or financial advice. For those, say it is outside what you can reliably answer and suggest a qualified person.
- Do not quote long passages of copyrighted books or song lyrics; summarise instead.
- For complex or doubtful religious matters, suggest consulting a qualified Pandit (the app has a Pandit booking section).
- Keep answers short, clear and kind. Reply in the language the user writes in (English, Hindi or Hinglish).`;

const MAX_MESSAGES = 10; // recent turns sent to the model
const MAX_CHARS = 1000; // per message

type ChatMessage = { role: "user" | "assistant"; content: string };

export function parseMessages(body: any): ChatMessage[] {
  const raw = body?.messages;
  if (!Array.isArray(raw) || raw.length === 0) throw ApiError.badRequest("messages must be a non-empty array");

  const cleaned: ChatMessage[] = raw
    .filter((m) => m && (m.role === "user" || m.role === "assistant") && typeof m.content === "string")
    .map((m) => ({ role: m.role, content: m.content.trim().slice(0, MAX_CHARS) }))
    .filter((m) => m.content.length > 0)
    .slice(-MAX_MESSAGES);

  // The API requires the conversation to start with, and end with, a user turn.
  while (cleaned.length && cleaned[0].role !== "user") cleaned.shift();
  if (!cleaned.length || cleaned[cleaned.length - 1].role !== "user") {
    throw ApiError.badRequest("The last message must be from the user");
  }
  return cleaned;
}

export async function chat(req: Request, res: Response) {
  const messages = parseMessages(req.body);

  if (!env.anthropicApiKey) {
    throw ApiError.internal("AI assistant is not configured on the server (ANTHROPIC_API_KEY is missing).");
  }

  let upstream: Awaited<ReturnType<typeof fetch>>;
  try {
    upstream = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: {
        "content-type": "application/json",
        "x-api-key": env.anthropicApiKey,
        "anthropic-version": "2023-06-01",
      },
      body: JSON.stringify({
        model: env.anthropicModel,
        max_tokens: 600,
        system: SYSTEM_PROMPT,
        messages,
      }),
      signal: AbortSignal.timeout(30000),
    });
  } catch {
    throw ApiError.internal("Could not reach the AI service. Please try again.");
  }

  if (!upstream.ok) {
    // Log details server-side only; never leak upstream errors or keys to the client.
    console.error("AI upstream error:", upstream.status, await upstream.text().catch(() => ""));
    throw ApiError.internal("The AI service is unavailable right now. Please try again later.");
  }

  const data: any = await upstream.json();
  const reply = (data?.content || [])
    .filter((b: any) => b.type === "text")
    .map((b: any) => b.text)
    .join("\n")
    .trim();

  if (!reply) throw ApiError.internal("The AI service returned an empty answer. Please try again.");

  res.json({ success: true, data: { reply, disclaimer: AI_DISCLAIMER } });
}
