import { Request, Response } from "express";

export function getHealth(req: Request, res: Response) {
  res.json({
    success: true,
    message: "Pandit Ji API is running",
    timestamp: new Date().toISOString(),
  });
}
