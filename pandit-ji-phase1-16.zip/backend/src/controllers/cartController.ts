import { Request, Response } from "express";
import { CartItem } from "../models/CartItem";
import { Product } from "../models/Product";
import { ApiError } from "../utils/ApiError";

export async function getCart(req: Request, res: Response) {
  const items = await CartItem.find({ user: req.user!.id }).populate("product").sort({ createdAt: -1 });
  res.json({ success: true, data: items });
}

export async function addToCart(req: Request, res: Response) {
  const { productId, quantity } = req.body;
  if (!productId || typeof quantity !== "number" || quantity <= 0) {
    throw ApiError.badRequest("productId and a positive quantity are required");
  }

  const product = await Product.findOne({ slug: productId });
  if (!product) throw ApiError.notFound("Product not found");

  const existing = await CartItem.findOne({ product: product._id, user: req.user!.id });
  let item;
  if (existing) {
    existing.quantity += quantity;
    item = await existing.save();
  } else {
    item = await CartItem.create({ product: product._id, quantity, user: req.user!.id });
  }

  const populated = await item.populate("product");
  res.status(201).json({ success: true, data: populated });
}
