import { Request, Response } from "express";
import { Pandit } from "../models/Pandit";
import { ApiError } from "../utils/ApiError";

export async function listPandits(req: Request, res: Response) {
  // Public listing only shows approved pandits.
  res.json({ success: true, data: await Pandit.find({ isApproved: true }).sort({ rating: -1 }) });
}

// Admins see every pandit (approved or not) so they can review pending ones.
export async function listPanditsForAdmin(req: Request, res: Response) {
  res.json({ success: true, data: await Pandit.find().sort({ createdAt: -1 }) });
}

export async function getPanditById(req: Request, res: Response) {
  const pandit = await Pandit.findOne({ slug: req.params.id });
  if (!pandit) throw ApiError.notFound("Pandit not found");
  res.json({ success: true, data: pandit });
}

export async function createPandit(req: Request, res: Response) {
  const pandit = await Pandit.create(req.body);
  res.status(201).json({ success: true, data: pandit });
}

export async function updatePandit(req: Request, res: Response) {
  const pandit = await Pandit.findOneAndUpdate({ slug: req.params.id }, req.body, { new: true, runValidators: true });
  if (!pandit) throw ApiError.notFound("Pandit not found");
  res.json({ success: true, data: pandit });
}

export async function deletePandit(req: Request, res: Response) {
  const pandit = await Pandit.findOneAndDelete({ slug: req.params.id });
  if (!pandit) throw ApiError.notFound("Pandit not found");
  res.json({ success: true, data: { deleted: true } });
}

// A pandit only appears in the public listing once approved.
export async function setPanditApproval(req: Request, res: Response) {
  const { isApproved } = req.body;
  if (typeof isApproved !== "boolean") {
    throw ApiError.badRequest("isApproved (true/false) is required");
  }
  const pandit = await Pandit.findOneAndUpdate({ slug: req.params.id }, { isApproved }, { new: true });
  if (!pandit) throw ApiError.notFound("Pandit not found");
  res.json({ success: true, data: pandit });
}
