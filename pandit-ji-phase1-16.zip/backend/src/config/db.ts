import mongoose from "mongoose";
import { env } from "./env";

export async function connectDB(): Promise<void> {
  if (!env.mongodbUri) {
    console.error(
      "❌ MONGODB_URI is not set. Copy backend/.env.example to backend/.env and set MONGODB_URI, then restart."
    );
    process.exit(1);
  }

  try {
    await mongoose.connect(env.mongodbUri);
    console.log(`✅ MongoDB connected (${mongoose.connection.name})`);
  } catch (err) {
    console.error("❌ MongoDB connection failed. Is MongoDB actually running?");
    console.error("   If you're using Docker, check: docker ps");
    console.error("   Underlying error:", err instanceof Error ? err.message : err);
    process.exit(1);
  }

  mongoose.connection.on("disconnected", () => {
    console.warn("⚠️  MongoDB disconnected");
  });
}
