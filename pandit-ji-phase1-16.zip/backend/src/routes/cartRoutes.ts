import { Router } from "express";
import { getCart, addToCart } from "../controllers/cartController";
import { asyncHandler } from "../utils/asyncHandler";
import { protect } from "../middleware/auth";

const router = Router();
router.get("/", protect, asyncHandler(getCart));
router.post("/", protect, asyncHandler(addToCart));

export default router;
