import { Router } from "express";
import { listFestivals, getFestivalById, createFestival, updateFestival, deleteFestival } from "../controllers/festivalController";
import { asyncHandler } from "../utils/asyncHandler";
import { protect, authorize } from "../middleware/auth";

const router = Router();
router.get("/", asyncHandler(listFestivals));
router.get("/:id", asyncHandler(getFestivalById));
router.post("/", protect, authorize("admin"), asyncHandler(createFestival));
router.put("/:id", protect, authorize("admin"), asyncHandler(updateFestival));
router.delete("/:id", protect, authorize("admin"), asyncHandler(deleteFestival));

export default router;
