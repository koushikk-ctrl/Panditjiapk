import { Router } from "express";
import {
  listPandits, listPanditsForAdmin, getPanditById,
  createPandit, updatePandit, deletePandit, setPanditApproval,
} from "../controllers/panditController";
import { asyncHandler } from "../utils/asyncHandler";
import { protect, authorize } from "../middleware/auth";

const router = Router();
router.get("/", asyncHandler(listPandits));
// Must be registered BEFORE "/:id", otherwise "admin" would be read as an id.
router.get("/admin/all", protect, authorize("admin"), asyncHandler(listPanditsForAdmin));
router.get("/:id", asyncHandler(getPanditById));
router.post("/", protect, authorize("admin"), asyncHandler(createPandit));
router.put("/:id", protect, authorize("admin"), asyncHandler(updatePandit));
router.delete("/:id", protect, authorize("admin"), asyncHandler(deletePandit));
router.patch("/:id/approve", protect, authorize("admin"), asyncHandler(setPanditApproval));

export default router;
