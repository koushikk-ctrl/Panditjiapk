import { Router } from "express";
import { listArticles, getArticleById, createArticle, updateArticle, deleteArticle } from "../controllers/articleController";
import { asyncHandler } from "../utils/asyncHandler";
import { protect, authorize } from "../middleware/auth";

const router = Router();
router.get("/", asyncHandler(listArticles));
router.get("/:id", asyncHandler(getArticleById));
router.post("/", protect, authorize("admin"), asyncHandler(createArticle));
router.put("/:id", protect, authorize("admin"), asyncHandler(updateArticle));
router.delete("/:id", protect, authorize("admin"), asyncHandler(deleteArticle));

export default router;
