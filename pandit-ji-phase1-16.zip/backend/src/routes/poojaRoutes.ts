import { Router } from "express";
import { listPoojas, getPoojaById, createPooja, updatePooja, deletePooja } from "../controllers/poojaController";
import { asyncHandler } from "../utils/asyncHandler";
import { protect, authorize } from "../middleware/auth";

const router = Router();
router.get("/", asyncHandler(listPoojas));
router.get("/:id", asyncHandler(getPoojaById));
router.post("/", protect, authorize("admin"), asyncHandler(createPooja));
router.put("/:id", protect, authorize("admin"), asyncHandler(updatePooja));
router.delete("/:id", protect, authorize("admin"), asyncHandler(deletePooja));

export default router;
