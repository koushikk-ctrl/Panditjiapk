import { Router } from "express";
import { getMuhurats, generateKundli } from "../controllers/astrologyController";

const router = Router();
router.get("/muhurat", getMuhurats);
router.post("/kundli", generateKundli);

export default router;
