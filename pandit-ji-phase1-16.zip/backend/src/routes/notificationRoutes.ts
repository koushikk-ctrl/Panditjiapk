import { Router } from "express";
import { listNotifications, sendNotification } from "../controllers/notificationController";
import { asyncHandler } from "../utils/asyncHandler";
import { protect, authorize } from "../middleware/auth";

const router = Router();
router.get("/", protect, authorize("admin"), asyncHandler(listNotifications));
router.post("/", protect, authorize("admin"), asyncHandler(sendNotification));

export default router;
