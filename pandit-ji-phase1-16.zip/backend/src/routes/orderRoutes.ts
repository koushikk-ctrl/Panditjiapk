import { Router } from "express";
import { createOrder, listOrders, updateOrderStatus } from "../controllers/orderController";
import { asyncHandler } from "../utils/asyncHandler";
import { protect, authorize } from "../middleware/auth";

const router = Router();
router.get("/", protect, asyncHandler(listOrders));
router.post("/", protect, asyncHandler(createOrder));
router.patch("/:id/status", protect, authorize("admin"), asyncHandler(updateOrderStatus));

export default router;
