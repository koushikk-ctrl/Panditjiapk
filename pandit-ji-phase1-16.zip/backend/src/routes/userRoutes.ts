import { Router } from "express";
import { listUsers } from "../controllers/userController";
import { asyncHandler } from "../utils/asyncHandler";
import { protect, authorize } from "../middleware/auth";

const router = Router();
router.get("/", protect, authorize("admin"), asyncHandler(listUsers));

export default router;
