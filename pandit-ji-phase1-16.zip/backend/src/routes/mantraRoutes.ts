import { Router } from "express";
import { listMantras, getMantraById, createMantra, updateMantra, deleteMantra } from "../controllers/mantraController";
import { asyncHandler } from "../utils/asyncHandler";
import { protect, authorize } from "../middleware/auth";

const router = Router();
router.get("/", asyncHandler(listMantras));
router.get("/:id", asyncHandler(getMantraById));
router.post("/", protect, authorize("admin"), asyncHandler(createMantra));
router.put("/:id", protect, authorize("admin"), asyncHandler(updateMantra));
router.delete("/:id", protect, authorize("admin"), asyncHandler(deleteMantra));

export default router;
