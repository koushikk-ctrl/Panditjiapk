import { Router } from "express";
import healthRoutes from "./healthRoutes";
import authRoutes from "./authRoutes";
import poojaRoutes from "./poojaRoutes";
import mantraRoutes from "./mantraRoutes";
import festivalRoutes from "./festivalRoutes";
import panditRoutes from "./panditRoutes";
import bookingRoutes from "./bookingRoutes";
import productRoutes from "./productRoutes";
import cartRoutes from "./cartRoutes";
import orderRoutes from "./orderRoutes";
import panchangRoutes from "./panchangRoutes";
import astrologyRoutes from "./astrologyRoutes";
import aiRoutes from "./aiRoutes";
import userRoutes from "./userRoutes";
import articleRoutes from "./articleRoutes";
import notificationRoutes from "./notificationRoutes";

const router = Router();

router.use("/health", healthRoutes);
router.use("/auth", authRoutes);
router.use("/poojas", poojaRoutes);
router.use("/mantras", mantraRoutes);
router.use("/festivals", festivalRoutes);
router.use("/pandits", panditRoutes);
router.use("/bookings", bookingRoutes);
router.use("/products", productRoutes);
router.use("/cart", cartRoutes);
router.use("/orders", orderRoutes);
router.use("/panchang", panchangRoutes);
router.use("/astrology", astrologyRoutes);
router.use("/ai", aiRoutes);
router.use("/users", userRoutes);
router.use("/articles", articleRoutes);
router.use("/notifications", notificationRoutes);

export default router;
