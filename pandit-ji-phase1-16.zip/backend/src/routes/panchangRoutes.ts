import { Router } from "express";
import { getTodayPanchang } from "../controllers/panchangController";

const router = Router();
router.get("/today", getTodayPanchang);

export default router;
