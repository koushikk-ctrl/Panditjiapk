import { Router } from "express";
import { listProducts, getProductById, createProduct, updateProduct, deleteProduct } from "../controllers/productController";
import { asyncHandler } from "../utils/asyncHandler";
import { protect, authorize } from "../middleware/auth";

const router = Router();
router.get("/", asyncHandler(listProducts));
router.get("/:id", asyncHandler(getProductById));
router.post("/", protect, authorize("admin"), asyncHandler(createProduct));
router.put("/:id", protect, authorize("admin"), asyncHandler(updateProduct));
router.delete("/:id", protect, authorize("admin"), asyncHandler(deleteProduct));

export default router;
