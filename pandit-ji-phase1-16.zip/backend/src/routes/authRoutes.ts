import { Router } from "express";
import { authLimiter } from "../middleware/rateLimiter";
import { protect } from "../middleware/auth";
import { asyncHandler } from "../utils/asyncHandler";
import { register, login, getMe } from "../controllers/authController";

const router = Router();
router.post("/register", authLimiter, asyncHandler(register));
router.post("/login", authLimiter, asyncHandler(login));
router.get("/me", protect, asyncHandler(getMe));

export default router;
