import { Router } from "express";
import { listBookings, createBooking, updateBookingStatus } from "../controllers/bookingController";
import { asyncHandler } from "../utils/asyncHandler";
import { protect } from "../middleware/auth";

const router = Router();
router.get("/", protect, asyncHandler(listBookings));
router.post("/", protect, asyncHandler(createBooking));
// Permission check (admin, or the linked pandit) happens inside the controller.
router.patch("/:id/status", protect, asyncHandler(updateBookingStatus));

export default router;
