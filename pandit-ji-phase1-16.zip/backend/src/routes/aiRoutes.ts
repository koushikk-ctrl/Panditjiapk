import { Router } from "express";
import { chat } from "../controllers/aiController";
import { aiLimiter } from "../middleware/rateLimiter";
import { asyncHandler } from "../utils/asyncHandler";

const router = Router();

// Public for now because the mobile app has no login screens yet; the strict
// aiLimiter protects cost. Once mobile login exists, add `protect` here.
router.post("/chat", aiLimiter, asyncHandler(chat));

export default router;
