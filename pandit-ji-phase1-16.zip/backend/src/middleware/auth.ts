import { Request, Response, NextFunction } from "express";
import { ApiError } from "../utils/ApiError";
import { verifyToken, TokenPayload } from "../utils/generateToken";

// Augment Express's Request type so `req.user` is recognized everywhere
// without needing `as any` casts in controllers.
declare global {
  // eslint-disable-next-line @typescript-eslint/no-namespace
  namespace Express {
    interface Request {
      user?: TokenPayload;
    }
  }
}

/**
 * Requires a valid "Authorization: Bearer <token>" header. On success,
 * attaches { id, role } to req.user for downstream handlers.
 */
export function protect(req: Request, res: Response, next: NextFunction) {
  const header = req.headers.authorization;
  if (!header || !header.startsWith("Bearer ")) {
    throw ApiError.unauthorized("Please log in to continue.");
  }

  const token = header.split(" ")[1];
  try {
    req.user = verifyToken(token);
    next();
  } catch {
    throw ApiError.unauthorized("Your session has expired. Please log in again.");
  }
}

/**
 * Restricts a route to specific roles. Must run AFTER `protect`.
 * Usage: router.delete("/:id", protect, authorize("admin"), deletePooja)
 */
export function authorize(...allowedRoles: Array<"user" | "pandit" | "admin">) {
  return (req: Request, res: Response, next: NextFunction) => {
    if (!req.user) {
      throw ApiError.unauthorized("Please log in to continue.");
    }
    if (!allowedRoles.includes(req.user.role)) {
      throw ApiError.forbidden("You don't have permission to do that.");
    }
    next();
  };
}
