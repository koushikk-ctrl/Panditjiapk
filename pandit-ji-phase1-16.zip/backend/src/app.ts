import express from "express";
import cors from "cors";
import helmet from "helmet";
import morgan from "morgan";
import { env } from "./config/env";
import { apiLimiter } from "./middleware/rateLimiter";
import { notFoundHandler } from "./middleware/notFound";
import { errorHandler } from "./middleware/errorHandler";
import routes from "./routes";

const app = express();

// --- Security & parsing middleware ---
app.use(helmet()); // sets safe default HTTP headers
app.use(
  cors({
    origin: env.corsOrigin === "*" ? true : env.corsOrigin.split(",").map((o) => o.trim()),
  })
);
app.use(express.json({ limit: "1mb" })); // reject oversized JSON bodies
app.use(morgan(env.isProduction ? "combined" : "dev")); // request logging

// --- Routes ---
app.use("/api", apiLimiter, routes);

// --- 404 + error handling (must be registered LAST) ---
app.use(notFoundHandler);
app.use(errorHandler);

export default app;
