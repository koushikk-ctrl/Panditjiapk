import app from "./app";
import { env } from "./config/env";
import { connectDB } from "./config/db";

async function start() {
  await connectDB();

  app.listen(env.port, () => {
    console.log(`🪔 Pandit Ji API running on http://localhost:${env.port}/api (${env.nodeEnv})`);
    console.log(`   Health check: http://localhost:${env.port}/api/health`);
  });
}

start();
