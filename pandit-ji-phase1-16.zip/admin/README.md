# PANDIT JI — Admin Dashboard

Small React + Vite + TypeScript web app for managing content, pandits,
bookings, orders, users and notifications. Admin accounts only.

## Run it
1. Start the backend first (see `../backend/README.md`; run `npm run seed` once).
2. Then:
```bash
cd admin
npm install
npm run dev
```
3. Open http://localhost:5173 and sign in with `admin@test.com` / `password123` (demo seed account).

The API URL defaults to `http://localhost:5000/api`; override with `VITE_API_URL` in `admin/.env`.
The token is kept in `localStorage` (fine for development; use httpOnly cookies for production).
