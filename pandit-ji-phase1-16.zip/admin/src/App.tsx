import React from "react";
import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import { AuthProvider } from "./context/AuthContext";
import ProtectedRoute from "./components/ProtectedRoute";
import Layout from "./components/Layout";
import LoginPage from "./pages/LoginPage";
import DashboardPage from "./pages/DashboardPage";
import PoojasPage from "./pages/PoojasPage";
import MantrasPage from "./pages/MantrasPage";
import FestivalsPage from "./pages/FestivalsPage";
import ArticlesPage from "./pages/ArticlesPage";
import ProductsPage from "./pages/ProductsPage";
import PanditsPage from "./pages/PanditsPage";
import BookingsPage from "./pages/BookingsPage";
import OrdersPage from "./pages/OrdersPage";
import UsersPage from "./pages/UsersPage";
import NotificationsPage from "./pages/NotificationsPage";

export default function App() {
  return (
    <AuthProvider>
      <BrowserRouter>
        <Routes>
          <Route path="/login" element={<LoginPage />} />
          <Route element={<ProtectedRoute><Layout /></ProtectedRoute>}>
            <Route path="/" element={<DashboardPage />} />
            <Route path="/poojas" element={<PoojasPage />} />
            <Route path="/mantras" element={<MantrasPage />} />
            <Route path="/festivals" element={<FestivalsPage />} />
            <Route path="/articles" element={<ArticlesPage />} />
            <Route path="/products" element={<ProductsPage />} />
            <Route path="/pandits" element={<PanditsPage />} />
            <Route path="/bookings" element={<BookingsPage />} />
            <Route path="/orders" element={<OrdersPage />} />
            <Route path="/users" element={<UsersPage />} />
            <Route path="/notifications" element={<NotificationsPage />} />
          </Route>
          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </BrowserRouter>
    </AuthProvider>
  );
}
