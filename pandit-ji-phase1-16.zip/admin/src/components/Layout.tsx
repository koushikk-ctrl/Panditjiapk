import React from "react";
import { NavLink, Outlet, useNavigate } from "react-router-dom";
import { useAuth } from "../context/AuthContext";

const NAV_ITEMS = [
  { to: "/", label: "Dashboard", end: true },
  { to: "/poojas", label: "Poojas" },
  { to: "/mantras", label: "Mantras" },
  { to: "/festivals", label: "Festivals" },
  { to: "/articles", label: "Articles" },
  { to: "/products", label: "Products" },
  { to: "/pandits", label: "Pandits" },
  { to: "/bookings", label: "Bookings" },
  { to: "/orders", label: "Orders" },
  { to: "/users", label: "Users" },
  { to: "/notifications", label: "Notifications" },
];

export default function Layout() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();

  return (
    <div className="app-shell">
      <aside className="sidebar">
        <h1>ॐ Pandit Ji</h1>
        <p className="tagline">Admin Dashboard</p>
        <nav>
          {NAV_ITEMS.map((item) => (
            <NavLink key={item.to} to={item.to} end={item.end}>{item.label}</NavLink>
          ))}
        </nav>
        <div style={{ marginTop: 28, fontSize: 12, color: "#f0d9cf" }}>
          Logged in as<br /><strong>{user?.name}</strong>
        </div>
        <button className="logout-btn" onClick={() => { logout(); navigate("/login"); }}>Log out</button>
      </aside>
      <main className="main-content"><Outlet /></main>
    </div>
  );
}
