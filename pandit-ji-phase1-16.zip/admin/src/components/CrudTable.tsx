import React, { useEffect, useState, useCallback } from "react";
import { apiRequest, ApiRequestError } from "../api/client";

export type FieldType = "text" | "number" | "textarea" | "array";
export type FieldConfig = { key: string; label: string; type?: FieldType; fullWidth?: boolean };
export type ColumnConfig = { key: string; label: string; render?: (row: any) => React.ReactNode };

type CrudTableProps = {
  title: string;
  endpoint: string;       // used for create / update / delete, e.g. "/poojas"
  listEndpoint?: string;  // optional different endpoint for loading the list (e.g. "/pandits/admin/all")
  columns: ColumnConfig[];
  fields: FieldConfig[];
  idKey?: string;         // defaults to "slug"
  extraRowActions?: (row: any, reload: () => void) => React.ReactNode;
};

export default function CrudTable({ title, endpoint, listEndpoint, columns, fields, idKey = "slug", extraRowActions }: CrudTableProps) {
  const [items, setItems] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [formOpen, setFormOpen] = useState(false);
  const [editingItem, setEditingItem] = useState<any | null>(null);
  const [formValues, setFormValues] = useState<Record<string, string>>({});
  const [submitting, setSubmitting] = useState(false);

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      setItems(await apiRequest<any[]>(listEndpoint || endpoint));
    } catch (err) {
      setError(err instanceof ApiRequestError ? err.message : "Failed to load data");
    } finally {
      setLoading(false);
    }
  }, [endpoint, listEndpoint]);

  useEffect(() => { load(); }, [load]);

  const openCreate = () => {
    const blank: Record<string, string> = {};
    fields.forEach((f) => (blank[f.key] = ""));
    setFormValues(blank);
    setEditingItem(null);
    setError(null);
    setFormOpen(true);
  };

  const openEdit = (item: any) => {
    const values: Record<string, string> = {};
    fields.forEach((f) => {
      const raw = item[f.key];
      values[f.key] = f.type === "array" ? (Array.isArray(raw) ? raw.join("\n") : "") : String(raw ?? "");
    });
    setFormValues(values);
    setEditingItem(item);
    setError(null);
    setFormOpen(true);
  };

  const buildPayload = () => {
    const payload: Record<string, unknown> = {};
    fields.forEach((f) => {
      const raw = formValues[f.key] ?? "";
      if (f.type === "number") payload[f.key] = raw === "" ? 0 : Number(raw);
      else if (f.type === "array") payload[f.key] = raw.split("\n").map((s) => s.trim()).filter(Boolean);
      else payload[f.key] = raw;
    });
    return payload;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitting(true);
    setError(null);
    try {
      const payload = buildPayload();
      if (editingItem) await apiRequest(`${endpoint}/${editingItem[idKey]}`, { method: "PUT", body: payload });
      else await apiRequest(endpoint, { method: "POST", body: payload });
      setFormOpen(false);
      await load();
    } catch (err) {
      setError(err instanceof ApiRequestError ? err.message : "Save failed");
    } finally {
      setSubmitting(false);
    }
  };

  const handleDelete = async (item: any) => {
    if (!confirm(`Delete "${item.name || item.title || item[idKey]}"? This can't be undone.`)) return;
    try {
      await apiRequest(`${endpoint}/${item[idKey]}`, { method: "DELETE" });
      await load();
    } catch (err) {
      alert(err instanceof ApiRequestError ? err.message : "Delete failed");
    }
  };

  return (
    <div>
      <div className="page-header">
        <h2>{title}</h2>
        <button className="btn" onClick={openCreate}>+ Add New</button>
      </div>

      {formOpen ? (
        <form className="card" style={{ marginBottom: 20 }} onSubmit={handleSubmit}>
          <div className="form-grid">
            {fields.map((f) => (
              <div key={f.key} className={`form-field ${f.fullWidth ? "full-width" : ""}`}>
                <label>{f.label}{f.type === "array" ? " (one per line)" : ""}</label>
                {f.type === "textarea" || f.type === "array" ? (
                  <textarea value={formValues[f.key] || ""} onChange={(e) => setFormValues((p) => ({ ...p, [f.key]: e.target.value }))} />
                ) : (
                  <input type={f.type === "number" ? "number" : "text"} value={formValues[f.key] || ""} onChange={(e) => setFormValues((p) => ({ ...p, [f.key]: e.target.value }))} />
                )}
              </div>
            ))}
          </div>
          {error ? <p className="error-text">{error}</p> : null}
          <div className="action-row">
            <button className="btn" type="submit" disabled={submitting}>{submitting ? "Saving..." : editingItem ? "Save Changes" : "Create"}</button>
            <button type="button" className="btn btn-outline" onClick={() => setFormOpen(false)}>Cancel</button>
          </div>
        </form>
      ) : null}

      {loading ? <p className="empty-state">Loading...</p>
        : error && !formOpen ? <p className="empty-state">{error}</p>
        : items.length === 0 ? <p className="empty-state">No records yet. Click "+ Add New" to create one.</p>
        : (
          <table>
            <thead><tr>{columns.map((c) => <th key={c.key}>{c.label}</th>)}<th>Actions</th></tr></thead>
            <tbody>
              {items.map((row) => (
                <tr key={row[idKey] || row._id}>
                  {columns.map((c) => <td key={c.key}>{c.render ? c.render(row) : String(row[c.key] ?? "")}</td>)}
                  <td>
                    <div className="action-row">
                      <button className="btn btn-outline btn-small" onClick={() => openEdit(row)}>Edit</button>
                      <button className="btn btn-danger btn-small" onClick={() => handleDelete(row)}>Delete</button>
                      {extraRowActions ? extraRowActions(row, load) : null}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
    </div>
  );
}
