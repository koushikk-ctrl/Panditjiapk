import React, { useCallback, useEffect, useState } from "react";
import { apiRequest, ApiRequestError } from "../api/client";

const STATUSES = ["pending", "confirmed", "completed", "cancelled"];

export default function BookingsPage() {
  const [items, setItems] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const load = useCallback(async () => {
    try {
      setError(null);
      setItems(await apiRequest<any[]>("/bookings"));
    } catch (err) {
      setError((err as Error).message || "Could not load bookings");
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { load(); }, [load]);

  const changeStatus = async (id: string, status: string) => {
    try {
      await apiRequest(`/bookings/${id}/status`, { method: "PATCH", body: { status } });
      load();
    } catch (err) {
      alert(err instanceof ApiRequestError ? err.message : "Could not update status");
    }
  };

  return (
    <div>
      <div className="page-header"><h2>Bookings</h2></div>
      {loading ? <p className="empty-state">Loading...</p>
        : error ? <p className="empty-state">{error}</p>
        : items.length === 0 ? <p className="empty-state">No bookings yet.</p>
        : (
          <table>
            <thead><tr><th>Pandit</th><th>Pooja</th><th>Date</th><th>Time</th><th>Location</th><th>Status</th></tr></thead>
            <tbody>
              {items.map((b) => (
                <tr key={b._id}>
                  <td>{b.pandit?.name || "—"}</td>
                  <td>{b.poojaType}</td>
                  <td>{b.date}</td>
                  <td>{b.time}</td>
                  <td>{b.location}</td>
                  <td>
                    <select className="status-select" value={b.status} onChange={(e) => changeStatus(b._id, e.target.value)}>
                      {STATUSES.map((s) => <option key={s} value={s}>{s}</option>)}
                    </select>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
    </div>
  );
}
