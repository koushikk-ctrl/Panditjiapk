import React from "react";
import CrudTable from "../components/CrudTable";

export default function PoojasPage() {
  return (
    <CrudTable
      title="Poojas"
      endpoint="/poojas"
      columns={[
        { key: "name", label: "Name" },
        { key: "category", label: "Category" },
        { key: "duration", label: "Duration" },
        { key: "bestTime", label: "Best Time" },
      ]}
      fields={[
        { key: "slug", label: "Slug (unique id, e.g. ganesh-pooja)", type: "text" },
        { key: "name", label: "Name" },
        { key: "category", label: "Category" },
        { key: "duration", label: "Duration" },
        { key: "bestTime", label: "Best Time", fullWidth: true },
        { key: "purpose", label: "Purpose", type: "textarea", fullWidth: true },
        { key: "samagri", label: "Samagri (one per line)", type: "array", fullWidth: true },
        { key: "vidhiSteps", label: "Vidhi Steps (one per line)", type: "array", fullWidth: true },
        { key: "mantras", label: "Mantras (one per line)", type: "array", fullWidth: true },
      ]}
    />
  );
}
