import React, { useCallback, useEffect, useState } from "react";
import { apiRequest, ApiRequestError } from "../api/client";

export default function NotificationsPage() {
  const [items, setItems] = useState<any[]>([]);
  const [title, setTitle] = useState("");
  const [message, setMessage] = useState("");
  const [audience, setAudience] = useState("all");
  const [sending, setSending] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const load = useCallback(async () => {
    try {
      setItems(await apiRequest<any[]>("/notifications"));
    } catch (err) {
      setError((err as Error).message || "Could not load notifications");
    }
  }, []);

  useEffect(() => { load(); }, [load]);

  const handleSend = async (e: React.FormEvent) => {
    e.preventDefault();
    setSending(true);
    setError(null);
    try {
      await apiRequest("/notifications", { method: "POST", body: { title, message, audience } });
      setTitle("");
      setMessage("");
      load();
    } catch (err) {
      setError(err instanceof ApiRequestError ? err.message : "Could not send notification");
    } finally {
      setSending(false);
    }
  };

  return (
    <div>
      <div className="page-header"><h2>Notifications</h2></div>
      <form className="card" style={{ marginBottom: 20 }} onSubmit={handleSend}>
        <div className="form-grid">
          <div className="form-field">
            <label>Title</label>
            <input value={title} onChange={(e) => setTitle(e.target.value)} required />
          </div>
          <div className="form-field">
            <label>Audience</label>
            <select value={audience} onChange={(e) => setAudience(e.target.value)}>
              <option value="all">Everyone</option>
              <option value="users">Users</option>
              <option value="pandits">Pandits</option>
            </select>
          </div>
          <div className="form-field full-width">
            <label>Message</label>
            <textarea value={message} onChange={(e) => setMessage(e.target.value)} required />
          </div>
        </div>
        {error ? <p className="error-text">{error}</p> : null}
        <button className="btn" type="submit" disabled={sending}>{sending ? "Sending..." : "Send Notification"}</button>
        <p style={{ fontSize: 12, color: "var(--text-secondary)" }}>
          Note: notifications are recorded here; real Expo push delivery is a production TODO.
        </p>
      </form>
      {items.length === 0 ? <p className="empty-state">No notifications sent yet.</p> : (
        <table>
          <thead><tr><th>Title</th><th>Message</th><th>Audience</th><th>Sent</th></tr></thead>
          <tbody>
            {items.map((n) => (
              <tr key={n._id}>
                <td>{n.title}</td><td>{n.message}</td><td>{n.audience}</td>
                <td>{new Date(n.createdAt).toLocaleString()}</td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  );
}
