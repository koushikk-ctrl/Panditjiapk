import React from "react";
import CrudTable from "../components/CrudTable";

export default function ArticlesPage() {
  return (
    <CrudTable
      title="Articles (Sanatan Knowledge)"
      endpoint="/articles"
      columns={[
        { key: "title", label: "Title" },
        { key: "category", label: "Category" },
        { key: "shortDescription", label: "Summary" },
      ]}
      fields={[
        { key: "slug", label: "Slug (unique id, e.g. what-is-dharma)", type: "text" },
        { key: "title", label: "Title" },
        { key: "category", label: "Category (Vedas, Puranas, Dharma...)" },
        { key: "imageUrl", label: "Image URL (optional)", fullWidth: true },
        { key: "shortDescription", label: "Short Description", type: "textarea", fullWidth: true },
        { key: "content", label: "Full Content", type: "textarea", fullWidth: true },
      ]}
    />
  );
}
