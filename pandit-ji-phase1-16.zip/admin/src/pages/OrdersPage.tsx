import React, { useCallback, useEffect, useState } from "react";
import { apiRequest, ApiRequestError } from "../api/client";

const STATUSES = ["placed", "shipped", "delivered", "cancelled"];

export default function OrdersPage() {
  const [items, setItems] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const load = useCallback(async () => {
    try {
      setError(null);
      setItems(await apiRequest<any[]>("/orders"));
    } catch (err) {
      setError((err as Error).message || "Could not load orders");
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { load(); }, [load]);

  const changeStatus = async (id: string, status: string) => {
    try {
      await apiRequest(`/orders/${id}/status`, { method: "PATCH", body: { status } });
      load();
    } catch (err) {
      alert(err instanceof ApiRequestError ? err.message : "Could not update status");
    }
  };

  return (
    <div>
      <div className="page-header"><h2>Orders</h2></div>
      {loading ? <p className="empty-state">Loading...</p>
        : error ? <p className="empty-state">{error}</p>
        : items.length === 0 ? <p className="empty-state">No orders yet.</p>
        : (
          <table>
            <thead><tr><th>Customer</th><th>City</th><th>Items</th><th>Total (₹)</th><th>Payment</th><th>Status</th></tr></thead>
            <tbody>
              {items.map((o) => (
                <tr key={o._id}>
                  <td>{o.address?.name}<br /><small>{o.address?.phone}</small></td>
                  <td>{o.address?.city}</td>
                  <td>{(o.items || []).map((i: any) => `${i.product?.name || "Product"} ×${i.quantity}`).join(", ")}</td>
                  <td>{o.total}</td>
                  <td>{o.paymentMethod}</td>
                  <td>
                    <select className="status-select" value={o.status} onChange={(e) => changeStatus(o._id, e.target.value)}>
                      {STATUSES.map((s) => <option key={s} value={s}>{s}</option>)}
                    </select>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
    </div>
  );
}
