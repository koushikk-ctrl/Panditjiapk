import React from "react";
import CrudTable from "../components/CrudTable";

export default function FestivalsPage() {
  return (
    <CrudTable
      title="Festivals"
      endpoint="/festivals"
      columns={[
        { key: "name", label: "Name" },
        { key: "date", label: "Date" },
        { key: "tithi", label: "Tithi" },
      ]}
      fields={[
        { key: "slug", label: "Slug (unique id, e.g. diwali)", type: "text" },
        { key: "name", label: "Name" },
        { key: "date", label: "Date (yyyy-mm-dd)" },
        { key: "tithi", label: "Tithi", fullWidth: true },
      ]}
    />
  );
}
