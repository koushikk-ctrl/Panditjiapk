import React, { useEffect, useState } from "react";
import { apiRequest } from "../api/client";

type Stats = { users: number; pandits: number; bookings: number; orders: number; pendingBookings: number; revenue: number };

export default function DashboardPage() {
  const [stats, setStats] = useState<Stats | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    (async () => {
      try {
        // No dedicated stats endpoint yet: counts are derived from the list endpoints.
        const [users, pandits, bookings, orders] = await Promise.all([
          apiRequest<any[]>("/users"),
          apiRequest<any[]>("/pandits/admin/all"),
          apiRequest<any[]>("/bookings"),
          apiRequest<any[]>("/orders"),
        ]);
        setStats({
          users: users.length,
          pandits: pandits.length,
          bookings: bookings.length,
          orders: orders.length,
          pendingBookings: bookings.filter((b) => b.status === "pending").length,
          revenue: orders.filter((o) => o.status !== "cancelled").reduce((sum, o) => sum + (o.total || 0), 0),
        });
      } catch (err) {
        setError((err as Error).message || "Could not load dashboard");
      }
    })();
  }, []);

  if (error) return <p className="empty-state">{error}</p>;
  if (!stats) return <p className="empty-state">Loading...</p>;

  const cards = [
    { label: "Total Users", value: stats.users },
    { label: "Pandits", value: stats.pandits },
    { label: "Bookings", value: stats.bookings },
    { label: "Pending Bookings", value: stats.pendingBookings },
    { label: "Orders", value: stats.orders },
    { label: "Order Revenue (₹)", value: stats.revenue },
  ];

  return (
    <div>
      <div className="page-header"><h2>Dashboard</h2></div>
      <div className="stat-grid">
        {cards.map((c) => (
          <div className="stat-card" key={c.label}>
            <div className="label">{c.label}</div>
            <div className="value">{c.value}</div>
          </div>
        ))}
      </div>
    </div>
  );
}
