import React from "react";
import CrudTable from "../components/CrudTable";

export default function MantrasPage() {
  return (
    <CrudTable
      title="Mantras"
      endpoint="/mantras"
      columns={[
        { key: "title", label: "Title" },
        { key: "deity", label: "Deity" },
        { key: "sanskrit", label: "Sanskrit" },
      ]}
      fields={[
        { key: "slug", label: "Slug (unique id, e.g. gayatri-mantra)", type: "text" },
        { key: "title", label: "Title" },
        { key: "deity", label: "Deity" },
        { key: "sanskrit", label: "Sanskrit text", type: "textarea", fullWidth: true },
        { key: "meaning", label: "Meaning", type: "textarea", fullWidth: true },
      ]}
    />
  );
}
