import React from "react";
import CrudTable from "../components/CrudTable";

export default function ProductsPage() {
  return (
    <CrudTable
      title="Products"
      endpoint="/products"
      columns={[
        { key: "name", label: "Name" },
        { key: "category", label: "Category" },
        { key: "price", label: "Price (₹)" },
        { key: "discountPercent", label: "Discount %" },
        { key: "stock", label: "Stock" },
      ]}
      fields={[
        { key: "slug", label: "Slug (unique id, e.g. camphor-pack)", type: "text" },
        { key: "name", label: "Name" },
        { key: "category", label: "Category (samagri, kit, book, spiritual)" },
        { key: "price", label: "Price (₹)", type: "number" },
        { key: "discountPercent", label: "Discount %", type: "number" },
        { key: "stock", label: "Stock", type: "number" },
      ]}
    />
  );
}
