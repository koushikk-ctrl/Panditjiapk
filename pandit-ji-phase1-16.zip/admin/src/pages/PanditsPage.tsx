import React from "react";
import CrudTable from "../components/CrudTable";
import { apiRequest, ApiRequestError } from "../api/client";

export default function PanditsPage() {
  const setApproval = async (slug: string, isApproved: boolean, reload: () => void) => {
    try {
      await apiRequest(`/pandits/${slug}/approve`, { method: "PATCH", body: { isApproved } });
      reload();
    } catch (err) {
      alert(err instanceof ApiRequestError ? err.message : "Could not update approval");
    }
  };

  return (
    <CrudTable
      title="Pandits"
      endpoint="/pandits"
      listEndpoint="/pandits/admin/all" // admin view includes unapproved pandits
      columns={[
        { key: "name", label: "Name" },
        { key: "city", label: "City" },
        { key: "experienceYears", label: "Exp. (yrs)" },
        { key: "startingPrice", label: "From (₹)" },
        {
          key: "isApproved",
          label: "Status",
          render: (row) => (
            <span className={`badge ${row.isApproved ? "badge-completed" : "badge-pending"}`}>
              {row.isApproved ? "Approved" : "Pending approval"}
            </span>
          ),
        },
      ]}
      fields={[
        { key: "slug", label: "Slug (unique id, e.g. pandit-ramesh-sharma)", type: "text" },
        { key: "name", label: "Name" },
        { key: "city", label: "City" },
        { key: "experienceYears", label: "Experience (years)", type: "number" },
        { key: "startingPrice", label: "Starting Price (₹)", type: "number" },
        { key: "languages", label: "Languages", type: "array", fullWidth: true },
        { key: "specialties", label: "Specialties (pooja type ids)", type: "array", fullWidth: true },
      ]}
      extraRowActions={(row, reload) =>
        row.isApproved ? (
          <button className="btn btn-outline btn-small" onClick={() => setApproval(row.slug, false, reload)}>
            Revoke
          </button>
        ) : (
          <button className="btn btn-small" onClick={() => setApproval(row.slug, true, reload)}>
            Approve
          </button>
        )
      }
    />
  );
}
