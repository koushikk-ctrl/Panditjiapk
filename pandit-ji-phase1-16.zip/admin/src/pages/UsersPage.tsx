import React, { useEffect, useState } from "react";
import { apiRequest } from "../api/client";

export default function UsersPage() {
  const [items, setItems] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    apiRequest<any[]>("/users")
      .then(setItems)
      .catch((err) => setError(err.message || "Could not load users"))
      .finally(() => setLoading(false));
  }, []);

  return (
    <div>
      <div className="page-header"><h2>Users</h2></div>
      {loading ? <p className="empty-state">Loading...</p>
        : error ? <p className="empty-state">{error}</p>
        : items.length === 0 ? <p className="empty-state">No users yet.</p>
        : (
          <table>
            <thead><tr><th>Name</th><th>Email</th><th>Phone</th><th>Role</th><th>Joined</th></tr></thead>
            <tbody>
              {items.map((u) => (
                <tr key={u._id}>
                  <td>{u.name}</td>
                  <td>{u.email}</td>
                  <td>{u.phone || "—"}</td>
                  <td>{u.role}</td>
                  <td>{u.createdAt ? new Date(u.createdAt).toLocaleDateString() : "—"}</td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
    </div>
  );
}
