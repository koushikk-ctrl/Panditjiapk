import React, { createContext, useContext, useEffect, useState, useCallback } from "react";
import { apiRequest, ApiRequestError } from "../api/client";

type AdminUser = { id: string; name: string; email: string; role: "user" | "pandit" | "admin" };

type AuthContextValue = {
  user: AdminUser | null;
  loading: boolean;
  error: string | null;
  login: (email: string, password: string) => Promise<void>;
  logout: () => void;
};

const AuthContext = createContext<AuthContextValue | undefined>(undefined);
const TOKEN_KEY = "pandit_ji_admin_token";
const USER_KEY = "pandit_ji_admin_user";

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<AdminUser | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    try {
      const storedUser = localStorage.getItem(USER_KEY);
      if (storedUser && localStorage.getItem(TOKEN_KEY)) setUser(JSON.parse(storedUser));
    } catch {
      localStorage.removeItem(USER_KEY);
    }
    setLoading(false);
  }, []);

  const login = useCallback(async (email: string, password: string) => {
    setError(null);
    try {
      const data = await apiRequest<{ user: AdminUser; token: string }>("/auth/login", {
        method: "POST",
        body: { email, password },
      });
      // The dashboard is admin-only; reject other roles before storing anything.
      if (data.user.role !== "admin") throw new Error("This account doesn't have admin access.");

      localStorage.setItem(TOKEN_KEY, data.token);
      localStorage.setItem(USER_KEY, JSON.stringify(data.user));
      setUser(data.user);
    } catch (err) {
      setError(err instanceof ApiRequestError ? err.message : (err as Error).message || "Login failed");
      throw err;
    }
  }, []);

  const logout = useCallback(() => {
    localStorage.removeItem(TOKEN_KEY);
    localStorage.removeItem(USER_KEY);
    setUser(null);
  }, []);

  return <AuthContext.Provider value={{ user, loading, error, login, logout }}>{children}</AuthContext.Provider>;
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error("useAuth must be used within AuthProvider");
  return ctx;
}
