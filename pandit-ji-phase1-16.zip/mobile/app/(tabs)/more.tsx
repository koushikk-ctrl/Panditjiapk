import React from "react";
import { View, Text, StyleSheet, TouchableOpacity, ScrollView } from "react-native";
import { useRouter } from "expo-router";
import { Ionicons } from "@expo/vector-icons";
import { Colors, Spacing, Radius, Typography } from "@/constants/theme";

type Item = { label: string; subtitle: string; icon: keyof typeof Ionicons.glyphMap; path: string };

const ITEMS: Item[] = [
  { label: "Pandit Ji AI", subtitle: "Ask about poojas, festivals, mantras", icon: "chatbubbles", path: "/ai" },
  { label: "Daily Sadhana", subtitle: "Track your daily practice", icon: "checkmark-done", path: "/sadhana" },
  { label: "Mantra & Audio", subtitle: "Listen and chant", icon: "musical-notes", path: "/audio" },
  { label: "Festival Calendar", subtitle: "Upcoming festivals", icon: "calendar", path: "/festivals" },
  { label: "Jyotish", subtitle: "Panchang, muhurat, nakshatra (demo)", icon: "planet", path: "/jyotish" },
  { label: "My Bookings", subtitle: "Your pandit bookings", icon: "people", path: "/bookings" },
  { label: "Cart", subtitle: "Your store cart", icon: "cart", path: "/cart" },
];

export default function MoreScreen() {
  const router = useRouter();
  return (
    <ScrollView style={styles.screen} contentContainerStyle={{ padding: Spacing.xl, paddingTop: 60 }}>
      <Text style={Typography.h1}>More</Text>
      {ITEMS.map((item) => (
        <TouchableOpacity key={item.path} style={styles.row} onPress={() => router.push(item.path as any)}>
          <View style={styles.iconWrap}>
            <Ionicons name={item.icon} size={20} color={Colors.primaryDark} />
          </View>
          <View style={{ flex: 1 }}>
            <Text style={Typography.h3}>{item.label}</Text>
            <Text style={Typography.bodySmall}>{item.subtitle}</Text>
          </View>
          <Ionicons name="chevron-forward" size={18} color={Colors.textSecondary} />
        </TouchableOpacity>
      ))}
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: Colors.background },
  row: {
    flexDirection: "row", alignItems: "center", gap: Spacing.md, padding: Spacing.md,
    marginTop: Spacing.md, backgroundColor: Colors.surface, borderRadius: Radius.md,
    borderWidth: 1, borderColor: Colors.border,
  },
  iconWrap: {
    width: 40, height: 40, borderRadius: 20, backgroundColor: Colors.primaryLight,
    alignItems: "center", justifyContent: "center",
  },
});
