import React, { useRef, useState } from "react";
import {
  View, Text, StyleSheet, TextInput, TouchableOpacity, FlatList,
  KeyboardAvoidingView, Platform, ActivityIndicator,
} from "react-native";
import { useRouter } from "expo-router";
import { Ionicons } from "@expo/vector-icons";
import { Colors, Spacing, Radius, Typography } from "@/constants/theme";
import { askPanditJiAI, AI_DISCLAIMER, ChatMessage } from "@/services/aiService";

const SUGGESTIONS = [
  "What is the vidhi for Ganesh Pooja?",
  "Samagri list for Satyanarayan Katha",
  "Why do we celebrate Diwali?",
  "Meaning of the Gayatri Mantra",
];

type UiMessage = ChatMessage & { error?: boolean };

export default function AiScreen() {
  const router = useRouter();
  const [messages, setMessages] = useState<UiMessage[]>([]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const listRef = useRef<FlatList<UiMessage>>(null);

  const send = async (text: string) => {
    const question = text.trim();
    if (!question || loading) return;

    const next: UiMessage[] = [...messages, { role: "user", content: question }];
    setMessages(next);
    setInput("");
    setLoading(true);
    try {
      // Failed (error) bubbles are UI-only and never sent back to the server.
      const history = next.filter((m) => !m.error).map(({ role, content }) => ({ role, content }));
      const reply = await askPanditJiAI(history);
      setMessages([...next, { role: "assistant", content: reply }]);
    } catch (err) {
      setMessages([...next, { role: "assistant", content: (err as Error).message, error: true }]);
    } finally {
      setLoading(false);
      setTimeout(() => listRef.current?.scrollToEnd({ animated: true }), 100);
    }
  };

  return (
    <KeyboardAvoidingView
      style={styles.screen}
      behavior={Platform.OS === "ios" ? "padding" : undefined}
    >
      <View style={styles.header}>
        <TouchableOpacity onPress={() => router.back()} hitSlop={10}>
          <Ionicons name="arrow-back" size={24} color={Colors.textPrimary} />
        </TouchableOpacity>
        <Text style={Typography.h2}>Pandit Ji AI</Text>
        <View style={{ width: 24 }} />
      </View>

      <View style={styles.disclaimer}>
        <Ionicons name="information-circle" size={16} color={Colors.primaryDark} />
        <Text style={styles.disclaimerText}>{AI_DISCLAIMER}</Text>
      </View>

      <FlatList
        ref={listRef}
        data={messages}
        keyExtractor={(_, i) => String(i)}
        contentContainerStyle={styles.list}
        ListEmptyComponent={
          <View>
            <Text style={styles.emptyTitle}>🙏 Namaste! Ask me about poojas, festivals or mantras.</Text>
            {SUGGESTIONS.map((s) => (
              <TouchableOpacity key={s} style={styles.suggestion} onPress={() => send(s)}>
                <Text style={styles.suggestionText}>{s}</Text>
              </TouchableOpacity>
            ))}
          </View>
        }
        renderItem={({ item }) => (
          <View
            style={[
              styles.bubble,
              item.role === "user" ? styles.userBubble : styles.aiBubble,
              item.error && styles.errorBubble,
            ]}
          >
            <Text style={[styles.bubbleText, item.role === "user" && { color: Colors.textOnPrimary }]}>
              {item.content}
            </Text>
          </View>
        )}
        ListFooterComponent={
          loading ? (
            <View style={[styles.bubble, styles.aiBubble]}>
              <ActivityIndicator color={Colors.primary} />
            </View>
          ) : null
        }
        onContentSizeChange={() => listRef.current?.scrollToEnd({ animated: true })}
      />

      <View style={styles.inputRow}>
        <TextInput
          style={styles.input}
          placeholder="Ask a question..."
          placeholderTextColor={Colors.textSecondary}
          value={input}
          onChangeText={setInput}
          maxLength={1000}
          multiline
        />
        <TouchableOpacity
          style={[styles.sendBtn, (!input.trim() || loading) && { opacity: 0.5 }]}
          disabled={!input.trim() || loading}
          onPress={() => send(input)}
        >
          <Ionicons name="send" size={18} color={Colors.textOnPrimary} />
        </TouchableOpacity>
      </View>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: Colors.background },
  header: {
    flexDirection: "row", alignItems: "center", justifyContent: "space-between",
    paddingHorizontal: Spacing.lg, paddingTop: 56, paddingBottom: Spacing.md,
  },
  disclaimer: {
    flexDirection: "row", gap: 6, marginHorizontal: Spacing.lg, padding: Spacing.md,
    backgroundColor: Colors.primaryLight, borderRadius: Radius.md,
  },
  disclaimerText: { flex: 1, fontSize: 12, color: Colors.secondary },
  list: { padding: Spacing.lg, flexGrow: 1 },
  emptyTitle: { ...Typography.h3, marginBottom: Spacing.md },
  suggestion: {
    padding: Spacing.md, marginBottom: Spacing.sm, backgroundColor: Colors.surface,
    borderRadius: Radius.md, borderWidth: 1, borderColor: Colors.border,
  },
  suggestionText: { ...Typography.body },
  bubble: { maxWidth: "85%", padding: Spacing.md, borderRadius: Radius.md, marginBottom: Spacing.sm },
  userBubble: { alignSelf: "flex-end", backgroundColor: Colors.primary },
  aiBubble: { alignSelf: "flex-start", backgroundColor: Colors.surface, borderWidth: 1, borderColor: Colors.border },
  errorBubble: { backgroundColor: "#FBE9E7", borderColor: Colors.error },
  bubbleText: { ...Typography.body },
  inputRow: {
    flexDirection: "row", alignItems: "flex-end", gap: Spacing.sm,
    padding: Spacing.md, paddingBottom: Spacing.xl, backgroundColor: Colors.surface,
    borderTopWidth: 1, borderTopColor: Colors.border,
  },
  input: {
    flex: 1, maxHeight: 100, paddingHorizontal: Spacing.md, paddingVertical: Spacing.sm,
    borderRadius: Radius.md, borderWidth: 1, borderColor: Colors.border, color: Colors.textPrimary,
  },
  sendBtn: {
    width: 42, height: 42, borderRadius: 21, backgroundColor: Colors.primary,
    alignItems: "center", justifyContent: "center",
  },
});
