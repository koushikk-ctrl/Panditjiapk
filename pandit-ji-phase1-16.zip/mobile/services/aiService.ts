import { apiClient } from "./apiClient";

export type ChatMessage = { role: "user" | "assistant"; content: string };

export const AI_DISCLAIMER =
  "AI assistant for informational and devotional guidance. For complex religious matters, consult a qualified Pandit.";

// The mobile app never talks to the AI provider directly and holds no API key:
// it only calls our own backend, which keeps the key server-side.
export async function askPanditJiAI(messages: ChatMessage[]): Promise<string> {
  const res = await apiClient.post("/ai/chat", { messages }, { timeout: 40000 });
  return res.data.data.reply as string;
}
