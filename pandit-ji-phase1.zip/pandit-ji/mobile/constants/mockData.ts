import { PanchangData } from "@/components/PanchangCard";

// NOTE: This is DEMO data for MVP/UI purposes only.
// Replace with real API responses via services/panchangService.ts
export const demoPanchang: PanchangData = {
  date: "23 सितंबर 2026, बुधवार",
  tithi: "शुक्ल पक्ष द्वितीया",
  nakshatra: "रोहिणी",
  yoga: "शुभ",
  muhurat: "अभिजीत (12:00–12:48)",
};

export const quickPoojaDeities = [
  { id: "ganesh", name: "गणेश पूजा", emoji: "🕉️" },
  { id: "shiv", name: "शिव पूजा", emoji: "🔱" },
  { id: "durga", name: "दुर्गा पूजा", emoji: "🪔" },
  { id: "vishnu", name: "विष्णु पूजा", emoji: "🪷" },
];

export const demoDailyMantra = {
  title: "आज का मंत्र",
  sanskrit: "ॐ गं गणपतये नमः",
  meaning: "भगवान गणेश को नमन, जो विघ्नों को दूर करते हैं।",
};

export const demoFeaturedFestival = {
  name: "नवरात्रि",
  daysLeft: 6,
  description: "माँ दुर्गा के नौ रूपों की उपासना का पावन पर्व",
};
