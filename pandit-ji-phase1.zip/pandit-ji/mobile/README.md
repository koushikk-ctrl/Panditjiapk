# Pandit Ji — Mobile App (Phase 1)

## Prerequisites

- Node.js 18+ installed (check: `node -v`)
- The **Expo Go** app on your phone (Android: Play Store, iOS: App Store) — easiest way to preview
- OR Android Studio / Xcode if you want a simulator instead

## Setup (run these exactly, in order)

1. Open a terminal in the `mobile/` folder (the folder containing this README).
2. Install dependencies:

   ```
   npm install
   ```

3. Start the dev server:

   ```
   npx expo start
   ```

4. A QR code will appear in your terminal.
   - **On your phone**: open the Expo Go app and scan the QR code.
   - **On a simulator**: press `a` for Android emulator or `i` for iOS simulator (in the terminal).

That's it — the Home screen should load.

## What you should see

- A cream background app with an "ॐ Pandit Ji" header and greeting
- A saffron/maroon hero banner: "सनातन ज्ञान सदैव आपके साथ"
- A 4-icon Quick Access row (Daily Sadhana, Pooja Vidhi, Panchang, Mantra & Audio)
- A Today's Panchang card with demo tithi/nakshatra/yoga/muhurat
- A horizontally scrolling Quick Pooja deity row
- A dark "Today's Sadhana" progress teaser card
- A 6-tile "Explore" grid (Sadhana, Pooja Library, Sanatan Knowledge, Jyotish, Pooja Samagri, Pandit Booking)
- Featured Festival and Daily Mantra cards
- A 5-tab bottom bar: Home, Library, Store, Pandit, More (the last 4 are placeholder screens for now)

## Notes

- All Panchang/mantra/festival data on this screen is **demo data** (see `constants/mockData.ts`). It is not astronomically calculated — that comes in Phase 8 with a real API-ready service layer.
- Tapping "Pooja Vidhi", "Pooja Samagri" and "Pandit Booking" navigates to their (placeholder) tabs to prove routing works end-to-end.
- No backend is connected yet — `services/apiClient.ts` is a ready-to-use axios client (with JWT auto-attach) pointed at `http://localhost:5000/api`, which we'll wire up once the backend exists (Phase 11+).

## Troubleshooting

- If `npm install` fails, make sure you're using Node 18 or newer.
- If the QR code doesn't load on your phone, make sure your phone and computer are on the **same Wi-Fi network**.
- If you see a red error screen mentioning a missing package, stop the server (Ctrl+C) and re-run `npm install`, then `npx expo start` again.
