import React from "react";
import { View, Text, StyleSheet } from "react-native";
import { Colors, Typography } from "@/constants/theme";

export default function LibraryScreen() {
  return (
    <View style={styles.screen}>
      <Text style={Typography.h1}>पूजा पुस्तकालय</Text>
      <Text style={[Typography.bodySmall, { marginTop: 8 }]}>
        Coming in Phase 4: Pooja Library with categories, search and full vidhi pages.
      </Text>
    </View>
  );
}

const styles = StyleSheet.create({
  screen: {
    flex: 1,
    backgroundColor: Colors.background,
    padding: 20,
    paddingTop: 60,
  },
});
