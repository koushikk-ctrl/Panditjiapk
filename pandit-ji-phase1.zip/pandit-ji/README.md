# Pandit Ji — "Har Pooja, Har Vidhi — Ab Aapke Mobile Mein"

A digital Sanatan/Dharmic platform: daily sadhana, pooja library, sanatan
knowledge, jyotish, pandit booking, pooja samagri store, and an AI assistant.

## Project structure

```
pandit-ji/
├── mobile/     ← React Native (Expo) app — PHASE 1 (this delivery)
├── backend/    ← Node.js/Express API — later phase
├── admin/      ← Admin dashboard — later phase
└── README.md
```

## Build status

- [x] Phase 1: Project foundation + Home screen (mobile)
- [ ] Phase 2: Navigation & reusable components (partially done alongside Phase 1)
- [ ] Phase 3: Home screen polish
- [ ] Phase 4: Pooja Library
- [ ] Phase 5: Daily Sadhana
- [ ] Phase 6: Mantra & Audio
- [ ] Phase 7: Festival Calendar
- [ ] Phase 8: Astrology
- [ ] Phase 9: Pandit Booking
- [ ] Phase 10: Store & Cart
- [ ] Phase 11+: Backend, DB, Auth, Admin, AI, Testing, Production

See `mobile/README.md` for how to run what's built so far.
