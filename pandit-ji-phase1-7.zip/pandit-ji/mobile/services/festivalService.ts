import { apiClient } from "@/services/apiClient";
import { festivalLibrary, FestivalDetail } from "@/constants/festivalData";

// PRODUCTION TODO:
// Replace the body of these functions with real calls, e.g.:
//   const { data } = await apiClient.get<FestivalDetail[]>("/festivals");
//   return data;
// The backend (see backend/src/routes/festivalRoutes.ts, added in a later
// phase) would compute real festival dates from a panchang/astrology
// provider rather than storing them as static fields. Screens only depend
// on this file, so swapping the implementation here is enough — no screen
// changes needed.

export async function fetchFestivals(): Promise<FestivalDetail[]> {
  // Simulated network delay so loading states can be tested even locally.
  await new Promise((resolve) => setTimeout(resolve, 150));
  return festivalLibrary;
}

export async function fetchFestivalById(id: string): Promise<FestivalDetail | undefined> {
  await new Promise((resolve) => setTimeout(resolve, 100));
  return festivalLibrary.find((f) => f.id === id);
}

// Kept here (unused for now) to show the intended real-API shape once the
// backend exists — apiClient is already configured with base URL + JWT.
export async function fetchFestivalsFromApi(): Promise<FestivalDetail[]> {
  const { data } = await apiClient.get<FestivalDetail[]>("/festivals");
  return data;
}
