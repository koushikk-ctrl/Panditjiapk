import axios from "axios";
import AsyncStorage from "@react-native-async-storage/async-storage";
import Constants from "expo-constants";

// Base URL comes from app.json -> extra.apiUrl so it's easy to change
// per environment (dev/staging/prod) without touching code.
const API_URL = (Constants.expoConfig?.extra?.apiUrl as string) || "http://localhost:5000/api";

export const apiClient = axios.create({
  baseURL: API_URL,
  timeout: 15000,
  headers: {
    "Content-Type": "application/json",
  },
});

// Attach JWT token (once auth is implemented) to every request automatically.
apiClient.interceptors.request.use(async (config) => {
  const token = await AsyncStorage.getItem("authToken");
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

// Centralized error handling so screens can rely on a consistent shape.
apiClient.interceptors.response.use(
  (response) => response,
  (error) => {
    const message =
      error?.response?.data?.message || error?.message || "Something went wrong. Please try again.";
    return Promise.reject(new Error(message));
  }
);
