import React from "react";
import { View, Text, StyleSheet, TouchableOpacity } from "react-native";
import { Colors, Radius, Shadow, Spacing } from "@/constants/theme";

export type PanchangData = {
  date: string;
  tithi: string;
  nakshatra: string;
  yoga: string;
  muhurat: string;
};

type PanchangCardProps = {
  data: PanchangData;
  onPress?: () => void;
};

/**
 * NOTE: Data shown here is DEMO data. Real panchang calculation must come
 * from a licensed astrology/panchang API — see services/astrologyService.ts
 */
export default function PanchangCard({ data, onPress }: PanchangCardProps) {
  return (
    <View style={styles.card}>
      <View style={styles.headerRow}>
        <View>
          <Text style={styles.title}>आज का पंचांग</Text>
          <Text style={styles.date}>{data.date}</Text>
        </View>
        <TouchableOpacity onPress={onPress} hitSlop={{ top: 8, bottom: 8, left: 8, right: 8 }}>
          <Text style={styles.link}>विवरण ›</Text>
        </TouchableOpacity>
      </View>

      <View style={styles.grid}>
        <PanchangItem label="तिथि" value={data.tithi} />
        <PanchangItem label="नक्षत्र" value={data.nakshatra} />
        <PanchangItem label="योग" value={data.yoga} />
        <PanchangItem label="मुहूर्त" value={data.muhurat} />
      </View>
    </View>
  );
}

function PanchangItem({ label, value }: { label: string; value: string }) {
  return (
    <View style={styles.item}>
      <Text style={styles.itemLabel}>{label}</Text>
      <Text style={styles.itemValue} numberOfLines={2}>
        {value}
      </Text>
    </View>
  );
}

const styles = StyleSheet.create({
  card: {
    backgroundColor: Colors.surface,
    borderRadius: Radius.lg,
    padding: Spacing.lg,
    marginHorizontal: Spacing.lg,
    ...Shadow.card,
  },
  headerRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    marginBottom: Spacing.md,
  },
  title: { fontSize: 15, fontWeight: "700", color: Colors.textPrimary },
  date: { fontSize: 12, color: Colors.textSecondary, marginTop: 2 },
  link: { fontSize: 13, fontWeight: "600", color: Colors.primaryDark },
  grid: {
    flexDirection: "row",
    flexWrap: "wrap",
  },
  item: {
    width: "50%",
    paddingVertical: Spacing.sm,
  },
  itemLabel: { fontSize: 11, color: Colors.textSecondary, marginBottom: 2 },
  itemValue: { fontSize: 13, fontWeight: "600", color: Colors.textPrimary },
});
