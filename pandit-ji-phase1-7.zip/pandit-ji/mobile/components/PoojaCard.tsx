import React from "react";
import { TouchableOpacity, Text, View, StyleSheet } from "react-native";
import { Colors, Radius, Spacing } from "@/constants/theme";

type PoojaCardProps = {
  name: string;
  emoji: string;
  shortPurpose: string;
  color: string;
  accent: string;
  onPress: () => void;
};

export default function PoojaCard({ name, emoji, shortPurpose, color, accent, onPress }: PoojaCardProps) {
  return (
    <TouchableOpacity style={[styles.card, { backgroundColor: color }]} onPress={onPress} activeOpacity={0.8}>
      <View style={[styles.emojiCircle, { backgroundColor: Colors.surface }]}>
        <Text style={styles.emoji}>{emoji}</Text>
      </View>
      <Text style={styles.name} numberOfLines={1}>
        {name}
      </Text>
      <Text style={[styles.purpose, { color: accent }]} numberOfLines={2}>
        {shortPurpose}
      </Text>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  card: {
    width: "48%",
    borderRadius: Radius.lg,
    padding: Spacing.md,
    marginBottom: Spacing.md,
    minHeight: 130,
  },
  emojiCircle: {
    width: 44,
    height: 44,
    borderRadius: 22,
    alignItems: "center",
    justifyContent: "center",
    marginBottom: Spacing.sm,
  },
  emoji: { fontSize: 22 },
  name: {
    fontSize: 14.5,
    fontWeight: "700",
    color: Colors.textPrimary,
    marginBottom: 3,
  },
  purpose: {
    fontSize: 11.5,
    fontWeight: "600",
    lineHeight: 15,
  },
});
