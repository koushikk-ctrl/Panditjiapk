import React from "react";
import { TouchableOpacity, Text, View, StyleSheet } from "react-native";
import { Ionicons } from "@expo/vector-icons";
import { Colors, Radius, Shadow, Spacing } from "@/constants/theme";

type AudioCardProps = {
  title: string;
  subtitle: string;
  durationLabel: string;
  emoji: string;
  isActive: boolean;
  isPlaying: boolean;
  isFavorite: boolean;
  onPress: () => void;
  onToggleFavorite: () => void;
};

export default function AudioCard({
  title,
  subtitle,
  durationLabel,
  emoji,
  isActive,
  isPlaying,
  isFavorite,
  onPress,
  onToggleFavorite,
}: AudioCardProps) {
  return (
    <TouchableOpacity
      style={[styles.row, isActive && styles.rowActive]}
      onPress={onPress}
      activeOpacity={0.75}
    >
      <View style={[styles.emojiCircle, isActive && { backgroundColor: Colors.primary }]}>
        {isActive && isPlaying ? (
          <Ionicons name="volume-high" size={18} color="#FFFFFF" />
        ) : (
          <Text style={styles.emoji}>{emoji}</Text>
        )}
      </View>

      <View style={{ flex: 1, marginLeft: Spacing.md }}>
        <Text style={[styles.title, isActive && { color: Colors.primaryDark }]} numberOfLines={1}>
          {title}
        </Text>
        <Text style={styles.subtitle} numberOfLines={1}>
          {subtitle} • {durationLabel}
        </Text>
      </View>

      <TouchableOpacity onPress={onToggleFavorite} hitSlop={{ top: 10, bottom: 10, left: 10, right: 10 }}>
        <Ionicons
          name={isFavorite ? "heart" : "heart-outline"}
          size={20}
          color={isFavorite ? Colors.accentPink : Colors.textSecondary}
        />
      </TouchableOpacity>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  row: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: Colors.surface,
    borderRadius: Radius.md,
    paddingVertical: Spacing.md,
    paddingHorizontal: Spacing.md,
    marginBottom: Spacing.sm,
    ...Shadow.card,
  },
  rowActive: {
    borderWidth: 1.5,
    borderColor: Colors.primary,
  },
  emojiCircle: {
    width: 42,
    height: 42,
    borderRadius: 21,
    backgroundColor: Colors.primaryLight,
    alignItems: "center",
    justifyContent: "center",
  },
  emoji: { fontSize: 18 },
  title: {
    fontSize: 14.5,
    fontWeight: "700",
    color: Colors.textPrimary,
  },
  subtitle: {
    fontSize: 12,
    color: Colors.textSecondary,
    marginTop: 2,
  },
});
