import React from "react";
import { TouchableOpacity, Text, View, StyleSheet } from "react-native";
import { Ionicons } from "@expo/vector-icons";
import { Colors, Radius, Shadow, Spacing } from "@/constants/theme";
import { useAudioPlayer } from "@/contexts/AudioPlayerContext";

type MiniPlayerBarProps = {
  onPress: () => void;
};

export default function MiniPlayerBar({ onPress }: MiniPlayerBarProps) {
  const { currentTrack, isPlaying, togglePlayPause } = useAudioPlayer();

  if (!currentTrack) return null;

  return (
    <TouchableOpacity style={styles.bar} onPress={onPress} activeOpacity={0.85}>
      <View style={styles.emojiCircle}>
        <Text style={styles.emoji}>{currentTrack.emoji}</Text>
      </View>
      <Text style={styles.title} numberOfLines={1}>
        {currentTrack.title}
      </Text>
      <TouchableOpacity
        onPress={(e) => {
          e.stopPropagation();
          togglePlayPause();
        }}
        hitSlop={{ top: 10, bottom: 10, left: 10, right: 10 }}
      >
        <Ionicons name={isPlaying ? "pause-circle" : "play-circle"} size={34} color={Colors.primary} />
      </TouchableOpacity>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  bar: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: Colors.surface,
    borderRadius: Radius.lg,
    paddingVertical: Spacing.sm,
    paddingHorizontal: Spacing.md,
    marginHorizontal: Spacing.lg,
    marginBottom: Spacing.md,
    ...Shadow.card,
  },
  emojiCircle: {
    width: 34,
    height: 34,
    borderRadius: 17,
    backgroundColor: Colors.primaryLight,
    alignItems: "center",
    justifyContent: "center",
    marginRight: Spacing.sm,
  },
  emoji: { fontSize: 16 },
  title: {
    flex: 1,
    fontSize: 13.5,
    fontWeight: "700",
    color: Colors.textPrimary,
  },
});
