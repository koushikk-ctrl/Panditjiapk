import React from "react";
import { TouchableOpacity, Text, View, StyleSheet } from "react-native";
import { Colors, Radius, Shadow, Spacing } from "@/constants/theme";

type DeityChipProps = {
  name: string;
  emoji: string;
  onPress?: () => void;
};

export default function DeityChip({ name, emoji, onPress }: DeityChipProps) {
  return (
    <TouchableOpacity style={styles.wrapper} onPress={onPress} activeOpacity={0.75}>
      <View style={styles.circle}>
        <Text style={styles.emoji}>{emoji}</Text>
      </View>
      <Text style={styles.name}>{name}</Text>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  wrapper: {
    alignItems: "center",
    width: 78,
    marginRight: Spacing.sm,
  },
  circle: {
    width: 64,
    height: 64,
    borderRadius: 32,
    backgroundColor: Colors.surface,
    alignItems: "center",
    justifyContent: "center",
    marginBottom: Spacing.xs,
    borderWidth: 1,
    borderColor: Colors.border,
    ...Shadow.card,
  },
  emoji: { fontSize: 28 },
  name: {
    fontSize: 12,
    fontWeight: "600",
    color: Colors.textPrimary,
    textAlign: "center",
  },
});
