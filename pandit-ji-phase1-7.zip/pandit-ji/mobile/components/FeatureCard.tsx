import React from "react";
import { TouchableOpacity, Text, View, StyleSheet } from "react-native";
import { Ionicons } from "@expo/vector-icons";
import { Radius, Spacing } from "@/constants/theme";

type FeatureCardProps = {
  title: string;
  subtitle: string;
  icon: keyof typeof Ionicons.glyphMap;
  backgroundColor: string;
  accentColor: string;
  onPress?: () => void;
};

/**
 * Represents one core module (Daily Sadhana, Pooja Library, Jyotish, etc).
 * Uses a soft tinted background per category, echoing the poster's
 * color-coded numbered sections, but as tappable navigation entry points.
 */
export default function FeatureCard({
  title,
  subtitle,
  icon,
  backgroundColor,
  accentColor,
  onPress,
}: FeatureCardProps) {
  return (
    <TouchableOpacity style={[styles.card, { backgroundColor }]} onPress={onPress} activeOpacity={0.8}>
      <View style={[styles.iconCircle, { backgroundColor: accentColor }]}>
        <Ionicons name={icon} size={20} color="#FFFFFF" />
      </View>
      <Text style={styles.title} numberOfLines={1}>
        {title}
      </Text>
      <Text style={styles.subtitle} numberOfLines={2}>
        {subtitle}
      </Text>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  card: {
    width: "48%",
    borderRadius: Radius.lg,
    padding: Spacing.md,
    marginBottom: Spacing.md,
    minHeight: 118,
  },
  iconCircle: {
    width: 36,
    height: 36,
    borderRadius: 18,
    alignItems: "center",
    justifyContent: "center",
    marginBottom: Spacing.sm,
  },
  title: {
    fontSize: 14,
    fontWeight: "700",
    color: "#3A1F1A",
    marginBottom: 2,
  },
  subtitle: {
    fontSize: 11.5,
    color: "#6B5A50",
    lineHeight: 15,
  },
});
