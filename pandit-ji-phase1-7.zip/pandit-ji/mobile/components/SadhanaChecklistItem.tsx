import React from "react";
import { TouchableOpacity, Text, View, StyleSheet } from "react-native";
import { Ionicons } from "@expo/vector-icons";
import { Colors, Radius, Shadow, Spacing } from "@/constants/theme";

type SadhanaChecklistItemProps = {
  icon: string;
  title: string;
  completed: boolean;
  onToggle: () => void;
};

export default function SadhanaChecklistItem({ icon, title, completed, onToggle }: SadhanaChecklistItemProps) {
  return (
    <TouchableOpacity style={styles.row} onPress={onToggle} activeOpacity={0.75}>
      <Text style={styles.emoji}>{icon}</Text>
      <Text style={[styles.title, completed && styles.titleCompleted]}>{title}</Text>
      <View style={[styles.checkbox, completed && styles.checkboxChecked]}>
        {completed ? <Ionicons name="checkmark" size={16} color="#FFFFFF" /> : null}
      </View>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  row: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: Colors.surface,
    borderRadius: Radius.md,
    paddingVertical: Spacing.md,
    paddingHorizontal: Spacing.md,
    marginBottom: Spacing.sm,
    ...Shadow.card,
  },
  emoji: { fontSize: 20, marginRight: Spacing.md },
  title: {
    flex: 1,
    fontSize: 14.5,
    fontWeight: "600",
    color: Colors.textPrimary,
  },
  titleCompleted: {
    color: Colors.textSecondary,
    textDecorationLine: "line-through",
  },
  checkbox: {
    width: 26,
    height: 26,
    borderRadius: 13,
    borderWidth: 2,
    borderColor: Colors.border,
    alignItems: "center",
    justifyContent: "center",
  },
  checkboxChecked: {
    backgroundColor: Colors.accentGreen,
    borderColor: Colors.accentGreen,
  },
});
