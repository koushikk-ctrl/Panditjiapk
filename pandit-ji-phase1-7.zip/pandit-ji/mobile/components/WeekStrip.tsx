import React from "react";
import { View, Text, StyleSheet } from "react-native";
import { Ionicons } from "@expo/vector-icons";
import { Colors, Spacing } from "@/constants/theme";
import { DayProgress } from "@/hooks/useSadhana";

type WeekStripProps = {
  days: DayProgress[];
};

export default function WeekStrip({ days }: WeekStripProps) {
  return (
    <View style={styles.row}>
      {days.map((day) => (
        <View key={day.dateKey} style={styles.dayColumn}>
          <View
            style={[
              styles.circle,
              day.isFullyComplete && styles.circleComplete,
              day.isToday && styles.circleToday,
            ]}
          >
            {day.isFullyComplete ? (
              <Ionicons name="checkmark" size={14} color="#FFFFFF" />
            ) : (
              <Text style={styles.circleText}>{day.completedCount}</Text>
            )}
          </View>
          <Text style={[styles.label, day.isToday && styles.labelToday]}>{day.label}</Text>
        </View>
      ))}
    </View>
  );
}

const styles = StyleSheet.create({
  row: {
    flexDirection: "row",
    justifyContent: "space-between",
  },
  dayColumn: {
    alignItems: "center",
  },
  circle: {
    width: 32,
    height: 32,
    borderRadius: 16,
    backgroundColor: Colors.primaryLight,
    alignItems: "center",
    justifyContent: "center",
    marginBottom: Spacing.xs,
  },
  circleComplete: {
    backgroundColor: Colors.accentGreen,
  },
  circleToday: {
    borderWidth: 2,
    borderColor: Colors.primary,
  },
  circleText: {
    fontSize: 11,
    fontWeight: "700",
    color: Colors.primaryDark,
  },
  label: {
    fontSize: 10.5,
    fontWeight: "600",
    color: Colors.textSecondary,
  },
  labelToday: {
    color: Colors.primaryDark,
  },
});
