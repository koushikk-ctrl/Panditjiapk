import React, { useState } from "react";
import { Pressable, View, StyleSheet, LayoutChangeEvent, GestureResponderEvent } from "react-native";
import { Colors } from "@/constants/theme";

type AudioProgressBarProps = {
  progress: number; // 0 to 1
  onSeek: (ratio: number) => void;
};

/**
 * Tap-to-seek progress bar. Note: this supports tapping a point to jump
 * there, not drag-scrubbing — a full drag gesture can be added later with
 * PanResponder if needed.
 */
export default function AudioProgressBar({ progress, onSeek }: AudioProgressBarProps) {
  const [width, setWidth] = useState(0);

  const handleLayout = (e: LayoutChangeEvent) => setWidth(e.nativeEvent.layout.width);

  const handlePress = (e: GestureResponderEvent) => {
    if (width === 0) return;
    const ratio = Math.max(0, Math.min(1, e.nativeEvent.locationX / width));
    onSeek(ratio);
  };

  const clampedProgress = Math.max(0, Math.min(1, progress || 0));

  return (
    <Pressable onLayout={handleLayout} onPress={handlePress} style={styles.track} hitSlop={{ top: 10, bottom: 10 }}>
      <View style={[styles.fill, { width: `${clampedProgress * 100}%` }]} />
      <View style={[styles.thumb, { left: `${clampedProgress * 100}%` }]} />
    </Pressable>
  );
}

const styles = StyleSheet.create({
  track: {
    height: 6,
    borderRadius: 3,
    backgroundColor: "rgba(255,255,255,0.25)",
    justifyContent: "center",
  },
  fill: {
    height: 6,
    borderRadius: 3,
    backgroundColor: Colors.primary,
    position: "absolute",
    left: 0,
  },
  thumb: {
    position: "absolute",
    width: 14,
    height: 14,
    borderRadius: 7,
    backgroundColor: "#FFFFFF",
    marginLeft: -7,
  },
});
