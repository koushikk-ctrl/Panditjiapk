import React from "react";
import { TouchableOpacity, Text, View, StyleSheet } from "react-native";
import { Ionicons } from "@expo/vector-icons";
import { Colors, Radius, Spacing } from "@/constants/theme";

type QuickAccessButtonProps = {
  icon: keyof typeof Ionicons.glyphMap;
  label: string;
  backgroundColor: string;
  iconColor: string;
  onPress?: () => void;
};

export default function QuickAccessButton({
  icon,
  label,
  backgroundColor,
  iconColor,
  onPress,
}: QuickAccessButtonProps) {
  return (
    <TouchableOpacity style={styles.wrapper} onPress={onPress} activeOpacity={0.75}>
      <View style={[styles.iconCircle, { backgroundColor }]}>
        <Ionicons name={icon} size={22} color={iconColor} />
      </View>
      <Text style={styles.label} numberOfLines={2}>
        {label}
      </Text>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  wrapper: {
    alignItems: "center",
    width: 76,
  },
  iconCircle: {
    width: 56,
    height: 56,
    borderRadius: Radius.lg,
    alignItems: "center",
    justifyContent: "center",
    marginBottom: Spacing.xs,
  },
  label: {
    fontSize: 11.5,
    fontWeight: "600",
    color: Colors.textPrimary,
    textAlign: "center",
    lineHeight: 15,
  },
});
