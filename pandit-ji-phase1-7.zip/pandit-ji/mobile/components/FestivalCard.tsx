import React from "react";
import { TouchableOpacity, Text, View, StyleSheet } from "react-native";
import { Colors, Radius, Shadow, Spacing } from "@/constants/theme";

type FestivalCardProps = {
  name: string;
  emoji: string;
  color: string;
  accent: string;
  dateLabel: string;
  daysUntil: number;
  isApproximate?: boolean;
  onPress: () => void;
};

export default function FestivalCard({
  name,
  emoji,
  color,
  accent,
  dateLabel,
  daysUntil,
  isApproximate,
  onPress,
}: FestivalCardProps) {
  const isPast = daysUntil < 0;

  return (
    <TouchableOpacity style={styles.card} onPress={onPress} activeOpacity={0.8}>
      <View style={[styles.emojiCircle, { backgroundColor: color }]}>
        <Text style={styles.emoji}>{emoji}</Text>
      </View>

      <View style={{ flex: 1, marginLeft: Spacing.md }}>
        <Text style={styles.name}>{name}</Text>
        <Text style={styles.date}>
          {dateLabel}
          {isApproximate ? " (अनुमानित)" : ""}
        </Text>
      </View>

      <View
        style={[
          styles.badge,
          { backgroundColor: isPast ? Colors.border : color },
        ]}
      >
        <Text style={[styles.badgeText, { color: isPast ? Colors.textSecondary : accent }]}>
          {isPast ? "बीत चुका" : `${daysUntil} दिन`}
        </Text>
      </View>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  card: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: Colors.surface,
    borderRadius: Radius.md,
    paddingVertical: Spacing.md,
    paddingHorizontal: Spacing.md,
    marginBottom: Spacing.sm,
    ...Shadow.card,
  },
  emojiCircle: {
    width: 46,
    height: 46,
    borderRadius: 23,
    alignItems: "center",
    justifyContent: "center",
  },
  emoji: { fontSize: 22 },
  name: {
    fontSize: 14.5,
    fontWeight: "700",
    color: Colors.textPrimary,
  },
  date: {
    fontSize: 12,
    color: Colors.textSecondary,
    marginTop: 2,
  },
  badge: {
    paddingHorizontal: Spacing.sm,
    paddingVertical: 6,
    borderRadius: Radius.pill,
  },
  badgeText: {
    fontSize: 11,
    fontWeight: "700",
  },
});
