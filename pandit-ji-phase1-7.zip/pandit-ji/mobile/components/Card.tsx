import React from "react";
import { View, StyleSheet, ViewStyle, StyleProp } from "react-native";
import { Colors, Radius, Shadow, Spacing } from "@/constants/theme";

type CardProps = {
  children: React.ReactNode;
  style?: StyleProp<ViewStyle>;
  backgroundColor?: string;
  padded?: boolean;
};

/**
 * Base card surface used across the app: rounded corners, soft shadow.
 * Category-specific tint is passed via backgroundColor.
 */
export default function Card({ children, style, backgroundColor, padded = true }: CardProps) {
  return (
    <View
      style={[
        styles.card,
        padded && styles.padded,
        backgroundColor ? { backgroundColor } : null,
        style,
      ]}
    >
      {children}
    </View>
  );
}

const styles = StyleSheet.create({
  card: {
    backgroundColor: Colors.surface,
    borderRadius: Radius.lg,
    ...Shadow.card,
  },
  padded: {
    padding: Spacing.lg,
  },
});
