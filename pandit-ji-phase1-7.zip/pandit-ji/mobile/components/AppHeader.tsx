import React from "react";
import { View, Text, StyleSheet, TouchableOpacity } from "react-native";
import { Ionicons } from "@expo/vector-icons";
import { Colors, Spacing, Typography } from "@/constants/theme";

type AppHeaderProps = {
  greeting: string;
  userName?: string;
  onNotificationPress?: () => void;
};

/**
 * Top header used on Home. Echoes the poster's "ॐ Pandit Ji" wordmark
 * but as a compact, functional app bar rather than a static banner.
 */
export default function AppHeader({ greeting, userName, onNotificationPress }: AppHeaderProps) {
  return (
    <View style={styles.container}>
      <View style={styles.brandRow}>
        <Text style={styles.om}>ॐ</Text>
        <Text style={styles.brand}>Pandit Ji</Text>
      </View>

      <View style={styles.bottomRow}>
        <View>
          <Text style={styles.greeting}>
            {greeting}
            {userName ? `, ${userName}` : ""}
          </Text>
          <Text style={styles.subtext}>आज की पूजा क्या करनी है?</Text>
        </View>

        <TouchableOpacity style={styles.bell} onPress={onNotificationPress} hitSlop={{ top: 10, bottom: 10, left: 10, right: 10 }}>
          <Ionicons name="notifications-outline" size={22} color={Colors.secondary} />
        </TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    paddingHorizontal: Spacing.lg,
    paddingTop: Spacing.md,
    paddingBottom: Spacing.lg,
  },
  brandRow: {
    flexDirection: "row",
    alignItems: "center",
    marginBottom: Spacing.sm,
  },
  om: {
    fontSize: 20,
    color: Colors.primary,
    marginRight: Spacing.xs,
    fontWeight: "700",
  },
  brand: {
    fontSize: 18,
    fontWeight: "700",
    color: Colors.secondary,
  },
  bottomRow: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
  },
  greeting: {
    ...Typography.hero,
  },
  subtext: {
    ...Typography.bodySmall,
    marginTop: 2,
  },
  bell: {
    width: 42,
    height: 42,
    borderRadius: 21,
    backgroundColor: Colors.primaryLight,
    alignItems: "center",
    justifyContent: "center",
  },
});
