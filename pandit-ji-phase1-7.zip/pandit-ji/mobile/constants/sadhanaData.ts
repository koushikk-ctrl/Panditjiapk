// Default daily sadhana routine. In a later phase this can become
// user-customizable and stored per-user on the backend.

export type SadhanaItem = {
  id: string;
  title: string;
  category: "vandana" | "mantra" | "chalisa" | "aarti" | "meditation";
  icon: string; // emoji, kept simple for MVP
};

export const dailySadhanaItems: SadhanaItem[] = [
  { id: "ganesh-vandana", title: "गणेश वंदना", category: "vandana", icon: "🕉️" },
  { id: "gayatri-mantra", title: "गायत्री मंत्र", category: "mantra", icon: "🔆" },
  { id: "shiv-mantra", title: "शिव मंत्र", category: "mantra", icon: "🔱" },
  { id: "hanuman-chalisa", title: "हनुमान चालीसा", category: "chalisa", icon: "🚩" },
  { id: "evening-aarti", title: "संध्या आरती", category: "aarti", icon: "🪔" },
];
