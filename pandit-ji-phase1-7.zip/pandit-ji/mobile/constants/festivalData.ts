// NOTE: Dates below are for the 2026 calendar year, compiled from public
// panchang references. Tithi/muhurat timings shift by city and by the
// specific panchang authority used, so these are presented as a helpful
// guide, not an authoritative calculation. Ekadashi in particular recurs
// twice every lunar month — the date here is only the NEXT approaching one
// relative to when this app was built, clearly marked as approximate.
// PRODUCTION TODO: replace this static file with services/festivalService.ts
// fetching from a real panchang/astrology API (see that file's comments).

export type FestivalDetail = {
  id: string;
  name: string;
  emoji: string;
  color: string;
  accent: string;
  date: string; // ISO yyyy-mm-dd, this year's occurrence
  isDateApproximate?: boolean;
  tithi: string;
  muhurat: string;
  shortDescription: string;
  description: string;
  samagri: string[];
  vidhiSteps: { title: string; description: string }[];
  mantras: { sanskrit: string; meaning: string }[];
};

export const festivalLibrary: FestivalDetail[] = [
  {
    id: "mahashivratri",
    name: "महाशिवरात्रि",
    emoji: "🔱",
    color: "#E7F1FA",
    accent: "#2E6FA8",
    date: "2026-02-16",
    tithi: "फाल्गुन कृष्ण चतुर्दशी",
    muhurat: "निशीथ काल पूजा",
    shortDescription: "भगवान शिव की महारात्रि आराधना",
    description: "महाशिवरात्रि भगवान शिव को समर्पित प्रमुख पर्व है, जिसमें रात्रि जागरण, उपवास और शिवलिंग का अभिषेक किया जाता है।",
    samagri: ["शिवलिंग", "गंगाजल, दूध, दही, शहद (पंचामृत)", "बेलपत्र", "धतूरा, भांग (यदि उपलब्ध हो)", "सफेद पुष्प", "धूप, दीप"],
    vidhiSteps: [
      { title: "उपवास संकल्प", description: "प्रातः स्नान कर उपवास व पूजा का संकल्प लें।" },
      { title: "पंचामृत अभिषेक", description: "दूध, दही, शहद, घी व शक्कर से शिवलिंग का अभिषेक करें।" },
      { title: "बेलपत्र व मंत्र जाप", description: "'ॐ नमः शिवाय' जपते हुए बेलपत्र अर्पित करें।" },
      { title: "रात्रि जागरण", description: "चार प्रहर की पूजा कर रात्रि जागरण करें।" },
      { title: "प्रातः पारण", description: "अगली सुबह उपवास का पारण करें।" },
    ],
    mantras: [
      { sanskrit: "ॐ नमः शिवाय", meaning: "भगवान शिव को नमन।" },
      { sanskrit: "ॐ त्र्यम्बकं यजामहे सुगन्धिं पुष्टिवर्धनम्", meaning: "महामृत्युंजय मंत्र — आरोग्य व दीर्घायु हेतु।" },
    ],
  },
  {
    id: "holi",
    name: "होली",
    emoji: "🎨",
    color: "#FBEAF0",
    accent: "#B8476B",
    date: "2026-03-03",
    tithi: "फाल्गुन पूर्णिमा",
    muhurat: "होलिका दहन — प्रदोष काल",
    shortDescription: "रंगों व वसंत का उत्सव",
    description: "होली रंगों, वसंत ऋतु के आगमन और बुराई पर अच्छाई की विजय (होलिका दहन) का उत्सव है।",
    samagri: ["होलिका दहन हेतु लकड़ी/उपले", "गोबर की माला", "रंग व गुलाल", "नारियल, गेहूं की बालियां", "जल का कलश"],
    vidhiSteps: [
      { title: "होलिका दहन स्थल तैयार करना", description: "शुभ स्थान पर लकड़ी व उपलों से होलिका सजाएं।" },
      { title: "पूजन", description: "होलिका की परिक्रमा कर जल, रोली, अक्षत अर्पित करें।" },
      { title: "दहन", description: "प्रदोष काल में होलिका दहन करें।" },
      { title: "रंगोत्सव (धुलंडी)", description: "अगले दिन रंग व गुलाल से होली खेली जाती है।" },
    ],
    mantras: [
      { sanskrit: "ॐ होलिकायै नमः", meaning: "होलिका दहन के समय नमन मंत्र।" },
    ],
  },
  {
    id: "ram-navami",
    name: "राम नवमी",
    emoji: "🏹",
    color: "#FDE9D2",
    accent: "#D9720F",
    date: "2026-03-27",
    tithi: "चैत्र शुक्ल नवमी",
    muhurat: "मध्याह्न काल (राम जन्म का समय)",
    shortDescription: "भगवान राम के जन्म का उत्सव",
    description: "राम नवमी भगवान विष्णु के सातवें अवतार, मर्यादा पुरुषोत्तम श्री राम के जन्मोत्सव के रूप में मनाई जाती है।",
    samagri: ["राम दरबार प्रतिमा/चित्र", "तुलसी दल", "पीले/श्वेत पुष्प", "अक्षत, चंदन", "फल व प्रसाद"],
    vidhiSteps: [
      { title: "व्रत व संकल्प", description: "प्रातः स्नान कर व्रत व पूजा का संकल्प लें।" },
      { title: "राम दरबार पूजन", description: "पुष्प, तुलसी व चंदन अर्पित करें।" },
      { title: "पाठ", description: "रामचरितमानस या सुंदरकांड का पाठ करें।" },
      { title: "आरती व प्रसाद वितरण", description: "मध्याह्न में आरती कर प्रसाद वितरित करें।" },
    ],
    mantras: [
      { sanskrit: "श्री राम जय राम जय जय राम", meaning: "राम नाम का सरल जाप मंत्र।" },
    ],
  },
  {
    id: "ganesh-chaturthi",
    name: "गणेश चतुर्थी",
    emoji: "🕉️",
    color: "#FDE9D2",
    accent: "#F08A24",
    date: "2026-09-02",
    tithi: "भाद्रपद शुक्ल चतुर्थी",
    muhurat: "मध्याह्न — मूर्ति स्थापना हेतु",
    shortDescription: "भगवान गणेश का जन्मोत्सव",
    description: "गणेश चतुर्थी विघ्नहर्ता भगवान गणेश के जन्मोत्सव के रूप में 10 दिनों तक मनाई जाती है, जो अनंत चतुर्दशी पर विसर्जन के साथ सम्पन्न होती है।",
    samagri: ["गणेश प्रतिमा (मिट्टी की, पर्यावरण-अनुकूल)", "दूर्वा घास", "मोदक", "रोली, अक्षत", "पुष्प व पुष्पमाला", "धूप, दीप"],
    vidhiSteps: [
      { title: "मूर्ति स्थापना", description: "शुभ मुहूर्त में गणेश प्रतिमा स्थापित करें।" },
      { title: "प्राण-प्रतिष्ठा व आवाहन", description: "मंत्रोच्चार सहित आवाहन करें।" },
      { title: "दैनिक पूजा", description: "10 दिनों तक प्रतिदिन आरती व मोदक भोग अर्पित करें।" },
      { title: "विसर्जन", description: "अनंत चतुर्दशी पर विधिपूर्वक प्रतिमा का विसर्जन करें।" },
    ],
    mantras: [
      { sanskrit: "ॐ गं गणपतये नमः", meaning: "विघ्नहर्ता गणेश जी को नमन।" },
    ],
  },
  {
    id: "navratri",
    name: "शारदीय नवरात्रि",
    emoji: "🪔",
    color: "#FBEAF0",
    accent: "#B8476B",
    date: "2026-10-12",
    tithi: "आश्विन शुक्ल प्रतिपदा से नवमी तक",
    muhurat: "घटस्थापना — प्रातः शुभ मुहूर्त",
    shortDescription: "माँ दुर्गा के नौ रूपों की उपासना",
    description: "शारदीय नवरात्रि में माँ दुर्गा के नौ स्वरूपों की नौ दिनों तक पूजा की जाती है, जो विजयादशमी (दशहरा) पर सम्पन्न होती है।",
    samagri: ["कलश व जल", "दुर्गा प्रतिमा/चित्र", "लाल चुनरी व पुष्प", "अखंड ज्योति हेतु घी", "नारियल, मिठाई"],
    vidhiSteps: [
      { title: "घटस्थापना", description: "प्रथम दिन शुभ मुहूर्त में कलश स्थापना करें।" },
      { title: "अखंड ज्योति", description: "नौ दिनों तक अखंड ज्योति प्रज्वलित रखें।" },
      { title: "नौ रूपों की पूजा", description: "प्रतिदिन माँ के एक स्वरूप की पूजा करें।" },
      { title: "कन्या पूजन", description: "अष्टमी/नवमी पर कन्या पूजन करें।" },
      { title: "विसर्जन", description: "नवमी/दशमी पर व्रत का पारण व विसर्जन करें।" },
    ],
    mantras: [
      { sanskrit: "ॐ दुं दुर्गायै नमः", meaning: "माँ दुर्गा को नमन।" },
    ],
  },
  {
    id: "ekadashi",
    name: "एकादशी",
    emoji: "🪷",
    color: "#E7F3EA",
    accent: "#3F7A54",
    date: "2026-10-02",
    isDateApproximate: true,
    tithi: "एकादशी तिथि (माह में दो बार आती है)",
    muhurat: "पारण समय — अगले दिन सूर्योदय के पश्चात",
    shortDescription: "भगवान विष्णु का व्रत दिवस",
    description: "एकादशी भगवान विष्णु को समर्पित व्रत है, जो हर हिंदी माह में दो बार (शुक्ल व कृष्ण पक्ष) आता है। यह दिखाई गई तारीख अनुमानित है — सटीक तिथि के लिए पंचांग देखें।",
    samagri: ["विष्णु प्रतिमा/चित्र", "तुलसी दल", "पीले पुष्प", "पंचामृत", "फलाहार सामग्री (व्रत हेतु)"],
    vidhiSteps: [
      { title: "व्रत संकल्प", description: "दशमी की रात्रि से सात्विक भोजन के साथ व्रत का संकल्प लें।" },
      { title: "विष्णु पूजन", description: "तुलसी दल व पीले पुष्प अर्पित कर विष्णु पूजा करें।" },
      { title: "जागरण/भजन", description: "रात्रि में भजन-कीर्तन करें।" },
      { title: "पारण", description: "द्वादशी को सूर्योदय के पश्चात व्रत का पारण करें।" },
    ],
    mantras: [
      { sanskrit: "ॐ नमो भगवते वासुदेवाय", meaning: "भगवान विष्णु को नमन।" },
    ],
  },
  {
    id: "janmashtami",
    name: "जन्माष्टमी",
    emoji: "🪈",
    color: "#E7F1FA",
    accent: "#6E4E9E",
    date: "2026-08-23",
    tithi: "भाद्रपद कृष्ण अष्टमी",
    muhurat: "निशीथ काल (मध्यरात्रि — जन्म का समय)",
    shortDescription: "भगवान कृष्ण के जन्म का उत्सव",
    description: "जन्माष्टमी भगवान विष्णु के आठवें अवतार, भगवान श्रीकृष्ण के जन्मोत्सव के रूप में मध्यरात्रि को मनाई जाती है।",
    samagri: ["बाल गोपाल प्रतिमा", "पीत वस्त्र, मोरपंख", "माखन-मिश्री", "तुलसी दल", "झूला सजावट सामग्री"],
    vidhiSteps: [
      { title: "व्रत व संकल्प", description: "दिनभर व्रत रखकर पूजा का संकल्प लें।" },
      { title: "श्रृंगार", description: "बाल गोपाल को स्नान कराकर श्रृंगार करें।" },
      { title: "मध्यरात्रि जन्मोत्सव", description: "ठीक मध्यरात्रि (निशीथ काल) में जन्मोत्सव मनाएं।" },
      { title: "माखन-मिश्री भोग व आरती", description: "भोग अर्पित कर आरती करें, फिर व्रत का पारण करें।" },
    ],
    mantras: [
      { sanskrit: "ॐ क्लीं कृष्णाय नमः", meaning: "भगवान कृष्ण को नमन।" },
      { sanskrit: "हरे कृष्ण हरे कृष्ण कृष्ण कृष्ण हरे हरे", meaning: "महामंत्र — निरंतर भक्ति भाव हेतु।" },
    ],
  },
  {
    id: "diwali",
    name: "दीपावली",
    emoji: "💰",
    color: "#FDE9D2",
    accent: "#D9720F",
    date: "2026-11-08",
    tithi: "कार्तिक अमावस्या",
    muhurat: "प्रदोष काल — लक्ष्मी पूजा मुहूर्त",
    shortDescription: "प्रकाश व समृद्धि का पर्व",
    description: "दीपावली माँ लक्ष्मी और भगवान गणेश की पूजा, दीप प्रज्वलन और अंधकार पर प्रकाश की विजय का पंच-दिवसीय महापर्व है।",
    samagri: ["लक्ष्मी-गणेश प्रतिमा", "दीपक व घी/तेल", "कमल पुष्प, सिक्के", "मिठाई, खील-बताशे", "रंगोली सामग्री"],
    vidhiSteps: [
      { title: "घर की सफाई व सजावट", description: "घर को स्वच्छ कर दीयों व रंगोली से सजाएं।" },
      { title: "प्रदोष काल पूजन", description: "संध्या समय लक्ष्मी-गणेश की पूजा करें।" },
      { title: "अभिषेक व नैवेद्य", description: "पंचामृत अभिषेक कर मिठाई का भोग अर्पित करें।" },
      { title: "दीप प्रज्वलन", description: "पूरे घर व मुख्य द्वार पर दीप जलाएं।" },
      { title: "आरती", description: "लक्ष्मी आरती से पूजा का समापन करें।" },
    ],
    mantras: [
      { sanskrit: "ॐ श्रीं महालक्ष्म्यै नमः", meaning: "माँ लक्ष्मी को नमन — धन-समृद्धि हेतु।" },
    ],
  },
];

export function getFestivalById(id?: string | string[]) {
  const key = Array.isArray(id) ? id[0] : id;
  return festivalLibrary.find((f) => f.id === key);
}
