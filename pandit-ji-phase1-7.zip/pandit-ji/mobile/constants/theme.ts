// Design system for Pandit Ji app
// Inspired by the reference poster: saffron/orange primary, deep maroon text,
// cream background, with green/blue/purple as supporting category accents.

export const Colors = {
  // Brand
  primary: "#F08A24", // saffron/orange
  primaryDark: "#D9720F",
  primaryLight: "#FDE9D2",

  secondary: "#5B1A18", // deep maroon
  secondaryLight: "#7A2E26",

  background: "#FFF8F0", // cream / off-white
  surface: "#FFFFFF",

  textPrimary: "#3A1F1A", // dark maroon-brown
  textSecondary: "#7A6A62",
  textOnPrimary: "#FFFFFF",

  border: "#F0E1CE",

  // Supporting category accents (used per-card, not everywhere)
  accentGreen: "#3F7A54",
  accentGreenBg: "#E7F3EA",
  accentBlue: "#2E6FA8",
  accentBlueBg: "#E7F1FA",
  accentPurple: "#6E4E9E",
  accentPurpleBg: "#EFE9F7",
  accentPink: "#B8476B",
  accentPinkBg: "#FBEAF0",

  success: "#3F7A54",
  warning: "#D9720F",
  error: "#B3261E",

  overlay: "rgba(58, 31, 26, 0.5)",
};

export const Spacing = {
  xs: 4,
  sm: 8,
  md: 12,
  lg: 16,
  xl: 20,
  xxl: 28,
  xxxl: 36,
};

export const Radius = {
  sm: 8,
  md: 14,
  lg: 20,
  xl: 28,
  pill: 999,
};

export const Typography = {
  hero: { fontSize: 26, fontWeight: "700" as const, color: Colors.secondary },
  h1: { fontSize: 22, fontWeight: "700" as const, color: Colors.textPrimary },
  h2: { fontSize: 18, fontWeight: "700" as const, color: Colors.textPrimary },
  h3: { fontSize: 15, fontWeight: "600" as const, color: Colors.textPrimary },
  body: { fontSize: 14, fontWeight: "400" as const, color: Colors.textPrimary },
  bodySmall: { fontSize: 12.5, fontWeight: "400" as const, color: Colors.textSecondary },
  caption: { fontSize: 11, fontWeight: "500" as const, color: Colors.textSecondary },
};

export const Shadow = {
  card: {
    shadowColor: "#3A1F1A",
    shadowOffset: { width: 0, height: 3 },
    shadowOpacity: 0.08,
    shadowRadius: 8,
    elevation: 3,
  },
};
