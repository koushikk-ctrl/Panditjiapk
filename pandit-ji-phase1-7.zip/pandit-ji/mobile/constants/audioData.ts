// NOTE: audioUrl values below are royalty-free DEMO/PLACEHOLDER tracks
// (SoundHelix sample audio, commonly used for app development/testing).
// They are NOT actual devotional recordings. Replace with licensed
// mantra/aarti/bhajan audio (via Cloudinary/S3) before production launch.

export type AudioTrack = {
  id: string;
  title: string;
  category: "mantra" | "aarti" | "bhajan" | "stotra" | "meditation";
  deity?: string;
  durationLabel: string; // display only; real duration comes from playback status
  emoji: string;
  audioUrl: string;
};

export const audioCategories: { id: AudioTrack["category"]; label: string }[] = [
  { id: "mantra", label: "मंत्र" },
  { id: "aarti", label: "आरती" },
  { id: "bhajan", label: "भजन" },
  { id: "stotra", label: "स्तोत्र" },
  { id: "meditation", label: "ध्यान" },
];

const SAMPLE_URLS = [
  "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3",
  "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-2.mp3",
  "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-3.mp3",
];

export const audioLibrary: AudioTrack[] = [
  {
    id: "gayatri-mantra-audio",
    title: "गायत्री मंत्र",
    category: "mantra",
    deity: "सूर्य",
    durationLabel: "3:12",
    emoji: "🔆",
    audioUrl: SAMPLE_URLS[0],
  },
  {
    id: "mahamrityunjaya-mantra-audio",
    title: "महामृत्युंजय मंत्र",
    category: "mantra",
    deity: "शिव",
    durationLabel: "4:05",
    emoji: "🔱",
    audioUrl: SAMPLE_URLS[1],
  },
  {
    id: "ganesh-aarti-audio",
    title: "जय गणेश आरती",
    category: "aarti",
    deity: "गणेश",
    durationLabel: "2:48",
    emoji: "🕉️",
    audioUrl: SAMPLE_URLS[2],
  },
  {
    id: "om-jai-jagdish-aarti-audio",
    title: "ॐ जय जगदीश हरे",
    category: "aarti",
    deity: "विष्णु",
    durationLabel: "3:30",
    emoji: "🪷",
    audioUrl: SAMPLE_URLS[0],
  },
  {
    id: "hanuman-chalisa-audio",
    title: "हनुमान चालीसा",
    category: "bhajan",
    deity: "हनुमान",
    durationLabel: "8:15",
    emoji: "🚩",
    audioUrl: SAMPLE_URLS[1],
  },
  {
    id: "krishna-bhajan-audio",
    title: "आरती कुंजबिहारी की",
    category: "bhajan",
    deity: "कृष्ण",
    durationLabel: "4:40",
    emoji: "🪈",
    audioUrl: SAMPLE_URLS[2],
  },
  {
    id: "vishnu-sahasranam-stotra-audio",
    title: "विष्णु सहस्रनाम (अंश)",
    category: "stotra",
    deity: "विष्णु",
    durationLabel: "12:00",
    emoji: "🪷",
    audioUrl: SAMPLE_URLS[0],
  },
  {
    id: "durga-chalisa-stotra-audio",
    title: "दुर्गा चालीसा",
    category: "stotra",
    deity: "दुर्गा",
    durationLabel: "6:20",
    emoji: "🪔",
    audioUrl: SAMPLE_URLS[1],
  },
  {
    id: "om-chanting-meditation-audio",
    title: "ॐ ध्यान चैंटिंग",
    category: "meditation",
    durationLabel: "10:00",
    emoji: "🧘",
    audioUrl: SAMPLE_URLS[2],
  },
  {
    id: "silent-meditation-bell-audio",
    title: "शांति ध्यान (घंटी सहित)",
    category: "meditation",
    durationLabel: "15:00",
    emoji: "🔔",
    audioUrl: SAMPLE_URLS[0],
  },
];

export function getTrackById(id?: string | null) {
  if (!id) return undefined;
  return audioLibrary.find((t) => t.id === id);
}
