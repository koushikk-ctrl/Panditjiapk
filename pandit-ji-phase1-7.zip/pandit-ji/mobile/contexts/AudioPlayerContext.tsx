import React, { createContext, useContext, useEffect, useRef, useState, useCallback } from "react";
import { Audio, AVPlaybackStatus } from "expo-av";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { AudioTrack, audioLibrary, getTrackById } from "@/constants/audioData";

const FAVORITES_KEY = "audio:favorites:v1";
const RECENT_KEY = "audio:recent:v1";
const MAX_RECENT = 10;

type AudioPlayerContextValue = {
  currentTrack: AudioTrack | undefined;
  isPlaying: boolean;
  isLoading: boolean;
  positionMillis: number;
  durationMillis: number;
  favorites: string[];
  recentlyPlayedIds: string[];
  playTrack: (track: AudioTrack) => Promise<void>;
  togglePlayPause: () => Promise<void>;
  seekTo: (ratio: number) => Promise<void>;
  playNext: () => void;
  playPrevious: () => void;
  isFavorite: (id: string) => boolean;
  toggleFavorite: (id: string) => void;
};

const AudioPlayerContext = createContext<AudioPlayerContextValue | undefined>(undefined);

export function AudioPlayerProvider({ children }: { children: React.ReactNode }) {
  const soundRef = useRef<Audio.Sound | null>(null);
  const [currentTrackId, setCurrentTrackId] = useState<string | undefined>(undefined);
  const [isPlaying, setIsPlaying] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [positionMillis, setPositionMillis] = useState(0);
  const [durationMillis, setDurationMillis] = useState(0);
  const [favorites, setFavorites] = useState<string[]>([]);
  const [recentlyPlayedIds, setRecentlyPlayedIds] = useState<string[]>([]);

  const currentTrack = getTrackById(currentTrackId);

  // Load persisted favorites / recently played on mount.
  useEffect(() => {
    (async () => {
      try {
        const [favRaw, recentRaw] = await Promise.all([
          AsyncStorage.getItem(FAVORITES_KEY),
          AsyncStorage.getItem(RECENT_KEY),
        ]);
        if (favRaw) setFavorites(JSON.parse(favRaw));
        if (recentRaw) setRecentlyPlayedIds(JSON.parse(recentRaw));
      } catch (err) {
        console.error("Failed to load audio preferences:", err);
      }
    })();

    // Allow playback even if the phone's silent switch is on (typical for
    // devotional/meditation apps), and clean up the sound on unmount.
    Audio.setAudioModeAsync({ playsInSilentModeIOS: true }).catch(() => {});
    return () => {
      soundRef.current?.unloadAsync().catch(() => {});
    };
  }, []);

  const persistFavorites = useCallback(async (next: string[]) => {
    setFavorites(next);
    try {
      await AsyncStorage.setItem(FAVORITES_KEY, JSON.stringify(next));
    } catch (err) {
      console.error("Failed to save favorites:", err);
    }
  }, []);

  const persistRecent = useCallback(async (trackId: string) => {
    setRecentlyPlayedIds((prev) => {
      const next = [trackId, ...prev.filter((id) => id !== trackId)].slice(0, MAX_RECENT);
      AsyncStorage.setItem(RECENT_KEY, JSON.stringify(next)).catch((err) =>
        console.error("Failed to save recently played:", err)
      );
      return next;
    });
  }, []);

  const onStatusUpdate = useCallback(
    (status: AVPlaybackStatus) => {
      if (!status.isLoaded) return;
      setPositionMillis(status.positionMillis ?? 0);
      setDurationMillis(status.durationMillis ?? 0);
      setIsPlaying(status.isPlaying);
      if (status.didJustFinish) {
        playNextRef.current();
      }
    },
    []
  );

  const playTrack = useCallback(
    async (track: AudioTrack) => {
      try {
        setIsLoading(true);
        if (soundRef.current) {
          await soundRef.current.unloadAsync();
          soundRef.current = null;
        }
        const { sound } = await Audio.Sound.createAsync(
          { uri: track.audioUrl },
          { shouldPlay: true },
          onStatusUpdate
        );
        soundRef.current = sound;
        setCurrentTrackId(track.id);
        persistRecent(track.id);
      } catch (err) {
        console.error("Failed to play track:", err);
      } finally {
        setIsLoading(false);
      }
    },
    [onStatusUpdate, persistRecent]
  );

  const togglePlayPause = useCallback(async () => {
    if (!soundRef.current) return;
    const status = await soundRef.current.getStatusAsync();
    if (!status.isLoaded) return;
    if (status.isPlaying) {
      await soundRef.current.pauseAsync();
    } else {
      await soundRef.current.playAsync();
    }
  }, []);

  const seekTo = useCallback(
    async (ratio: number) => {
      if (!soundRef.current || durationMillis === 0) return;
      const target = Math.max(0, Math.min(1, ratio)) * durationMillis;
      await soundRef.current.setPositionAsync(target);
    },
    [durationMillis]
  );

  const playNext = useCallback(() => {
    if (!currentTrack) return;
    const idx = audioLibrary.findIndex((t) => t.id === currentTrack.id);
    const next = audioLibrary[(idx + 1) % audioLibrary.length];
    playTrack(next);
  }, [currentTrack, playTrack]);

  const playPrevious = useCallback(() => {
    if (!currentTrack) return;
    const idx = audioLibrary.findIndex((t) => t.id === currentTrack.id);
    const prev = audioLibrary[(idx - 1 + audioLibrary.length) % audioLibrary.length];
    playTrack(prev);
  }, [currentTrack, playTrack]);

  // onStatusUpdate needs to call the *latest* playNext without becoming a
  // dependency cycle, so we keep a ref that's always up to date.
  const playNextRef = useRef(playNext);
  useEffect(() => {
    playNextRef.current = playNext;
  }, [playNext]);

  const isFavorite = useCallback((id: string) => favorites.includes(id), [favorites]);

  const toggleFavorite = useCallback(
    (id: string) => {
      const next = favorites.includes(id) ? favorites.filter((f) => f !== id) : [...favorites, id];
      persistFavorites(next);
    },
    [favorites, persistFavorites]
  );

  return (
    <AudioPlayerContext.Provider
      value={{
        currentTrack,
        isPlaying,
        isLoading,
        positionMillis,
        durationMillis,
        favorites,
        recentlyPlayedIds,
        playTrack,
        togglePlayPause,
        seekTo,
        playNext,
        playPrevious,
        isFavorite,
        toggleFavorite,
      }}
    >
      {children}
    </AudioPlayerContext.Provider>
  );
}

export function useAudioPlayer() {
  const ctx = useContext(AudioPlayerContext);
  if (!ctx) {
    throw new Error("useAudioPlayer must be used within an AudioPlayerProvider");
  }
  return ctx;
}
