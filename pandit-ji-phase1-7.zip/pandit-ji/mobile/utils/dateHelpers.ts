// Lightweight date helpers (no external date library needed for MVP).

export function toDateKey(date: Date): string {
  const y = date.getFullYear();
  const m = String(date.getMonth() + 1).padStart(2, "0");
  const d = String(date.getDate()).padStart(2, "0");
  return `${y}-${m}-${d}`;
}

export function todayKey(): string {
  return toDateKey(new Date());
}

const HINDI_WEEKDAY_SHORT = ["रवि", "सोम", "मंगल", "बुध", "गुरु", "शुक्र", "शनि"];

export function weekdayLabel(date: Date): string {
  return HINDI_WEEKDAY_SHORT[date.getDay()];
}

export function daysAgo(n: number): Date {
  const d = new Date();
  d.setDate(d.getDate() - n);
  return d;
}

export function isSameDayKey(a: string, b: string): boolean {
  return a === b;
}

export function daysInCurrentMonthSoFar(): number {
  return new Date().getDate(); // e.g. 24 if today is the 24th
}

/**
 * Days between today (local midnight) and a given ISO date string
 * (yyyy-mm-dd). Positive = in the future, negative = already passed.
 */
export function daysUntil(isoDate: string): number {
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  const target = new Date(isoDate + "T00:00:00");
  const diffMs = target.getTime() - today.getTime();
  return Math.round(diffMs / (1000 * 60 * 60 * 24));
}

const HINDI_MONTHS = [
  "जनवरी", "फरवरी", "मार्च", "अप्रैल", "मई", "जून",
  "जुलाई", "अगस्त", "सितंबर", "अक्टूबर", "नवंबर", "दिसंबर",
];

export function formatDisplayDate(isoDate: string): string {
  const d = new Date(isoDate + "T00:00:00");
  return `${d.getDate()} ${HINDI_MONTHS[d.getMonth()]} ${d.getFullYear()}`;
}
