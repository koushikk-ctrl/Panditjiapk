import { useCallback, useEffect, useMemo, useState } from "react";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { dailySadhanaItems } from "@/constants/sadhanaData";
import { toDateKey, todayKey, weekdayLabel, daysAgo, daysInCurrentMonthSoFar } from "@/utils/dateHelpers";

const STORAGE_KEY = "sadhana:completions:v1";

// Shape stored on device: { "2026-09-24": ["ganesh-vandana", "gayatri-mantra"], ... }
type CompletionMap = Record<string, string[]>;

export type DayProgress = {
  dateKey: string;
  label: string;
  completedCount: number;
  isToday: boolean;
  isFullyComplete: boolean;
};

export function useSadhana() {
  const [completions, setCompletions] = useState<CompletionMap>({});
  const [loading, setLoading] = useState(true);
  const totalItems = dailySadhanaItems.length;
  const today = todayKey();

  // Load persisted completions on mount.
  useEffect(() => {
    (async () => {
      try {
        const raw = await AsyncStorage.getItem(STORAGE_KEY);
        if (raw) {
          setCompletions(JSON.parse(raw));
        }
      } catch (err) {
        console.error("Failed to load sadhana data:", err);
      } finally {
        setLoading(false);
      }
    })();
  }, []);

  const persist = useCallback(async (next: CompletionMap) => {
    setCompletions(next);
    try {
      await AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(next));
    } catch (err) {
      console.error("Failed to save sadhana data:", err);
    }
  }, []);

  const isCompleted = useCallback(
    (itemId: string) => (completions[today] || []).includes(itemId),
    [completions, today]
  );

  const toggleItem = useCallback(
    (itemId: string) => {
      const todayList = completions[today] || [];
      const nextTodayList = todayList.includes(itemId)
        ? todayList.filter((id) => id !== itemId)
        : [...todayList, itemId];
      persist({ ...completions, [today]: nextTodayList });
    },
    [completions, today, persist]
  );

  const todayCompletedCount = (completions[today] || []).length;
  const todayPercent = totalItems === 0 ? 0 : Math.round((todayCompletedCount / totalItems) * 100);

  // Last 7 days (oldest -> newest, ending today) for the weekly strip.
  const last7Days: DayProgress[] = useMemo(() => {
    const days: DayProgress[] = [];
    for (let i = 6; i >= 0; i--) {
      const date = daysAgo(i);
      const key = toDateKey(date);
      const completedCount = (completions[key] || []).length;
      days.push({
        dateKey: key,
        label: weekdayLabel(date),
        completedCount,
        isToday: key === today,
        isFullyComplete: completedCount === totalItems,
      });
    }
    return days;
  }, [completions, today, totalItems]);

  // Streak: consecutive fully-completed days, walking backward from the
  // most recent fully-completed day (today counts if fully done; otherwise
  // we start counting from yesterday so an in-progress today doesn't reset it).
  const streak = useMemo(() => {
    let count = 0;
    let cursor = new Date();
    const todayFullyDone = (completions[today] || []).length === totalItems;
    if (!todayFullyDone) {
      cursor = daysAgo(1);
    }
    // Walk backward until we hit a day that isn't fully complete.
    for (let i = 0; i < 366; i++) {
      const key = toDateKey(cursor);
      const completedCount = (completions[key] || []).length;
      if (completedCount === totalItems && totalItems > 0) {
        count += 1;
        cursor = new Date(cursor);
        cursor.setDate(cursor.getDate() - 1);
      } else {
        break;
      }
    }
    return count;
  }, [completions, today, totalItems]);

  // Monthly progress: how many days this month have at least full completion,
  // out of days elapsed so far this month.
  const monthStats = useMemo(() => {
    const now = new Date();
    const daysSoFar = daysInCurrentMonthSoFar();
    let fullyCompletedDays = 0;
    for (let day = 1; day <= daysSoFar; day++) {
      const d = new Date(now.getFullYear(), now.getMonth(), day);
      const key = toDateKey(d);
      if ((completions[key] || []).length === totalItems && totalItems > 0) {
        fullyCompletedDays += 1;
      }
    }
    return { fullyCompletedDays, daysSoFar };
  }, [completions, totalItems]);

  return {
    items: dailySadhanaItems,
    loading,
    isCompleted,
    toggleItem,
    todayCompletedCount,
    totalItems,
    todayPercent,
    last7Days,
    streak,
    monthStats,
  };
}
