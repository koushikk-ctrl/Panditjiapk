import React from "react";
import { View, Text, StyleSheet, TouchableOpacity } from "react-native";
import { router } from "expo-router";
import { Ionicons } from "@expo/vector-icons";
import { Colors, Radius, Spacing } from "@/constants/theme";
import AudioProgressBar from "@/components/AudioProgressBar";
import { useAudioPlayer } from "@/contexts/AudioPlayerContext";
import { audioCategories } from "@/constants/audioData";

function formatMillis(ms: number) {
  const totalSeconds = Math.floor(ms / 1000);
  const minutes = Math.floor(totalSeconds / 60);
  const seconds = totalSeconds % 60;
  return `${minutes}:${String(seconds).padStart(2, "0")}`;
}

export default function AudioPlayerScreen() {
  const {
    currentTrack,
    isPlaying,
    isLoading,
    positionMillis,
    durationMillis,
    togglePlayPause,
    seekTo,
    playNext,
    playPrevious,
    isFavorite,
    toggleFavorite,
  } = useAudioPlayer();

  if (!currentTrack) {
    return (
      <View style={styles.screen}>
        <View style={styles.topBar}>
          <TouchableOpacity onPress={() => router.back()} hitSlop={{ top: 10, bottom: 10, left: 10, right: 10 }}>
            <Ionicons name="chevron-down" size={26} color={Colors.textPrimary} />
          </TouchableOpacity>
        </View>
        <View style={styles.emptyWrap}>
          <Ionicons name="musical-notes-outline" size={40} color={Colors.textSecondary} />
          <Text style={styles.emptyText}>कोई ऑडियो नहीं चल रहा है</Text>
        </View>
      </View>
    );
  }

  const categoryLabel = audioCategories.find((c) => c.id === currentTrack.category)?.label;
  const progress = durationMillis > 0 ? positionMillis / durationMillis : 0;

  return (
    <View style={styles.screen}>
      <View style={styles.topBar}>
        <TouchableOpacity onPress={() => router.back()} hitSlop={{ top: 10, bottom: 10, left: 10, right: 10 }}>
          <Ionicons name="chevron-down" size={26} color={Colors.textPrimary} />
        </TouchableOpacity>
        <Text style={styles.topBarLabel}>अभी बज रहा है</Text>
        <TouchableOpacity
          onPress={() => toggleFavorite(currentTrack.id)}
          hitSlop={{ top: 10, bottom: 10, left: 10, right: 10 }}
        >
          <Ionicons
            name={isFavorite(currentTrack.id) ? "heart" : "heart-outline"}
            size={22}
            color={isFavorite(currentTrack.id) ? Colors.accentPink : Colors.textPrimary}
          />
        </TouchableOpacity>
      </View>

      <View style={styles.artworkWrap}>
        <View style={styles.artworkCircle}>
          <Text style={styles.artworkEmoji}>{currentTrack.emoji}</Text>
        </View>
      </View>

      <View style={styles.infoWrap}>
        <Text style={styles.title}>{currentTrack.title}</Text>
        <Text style={styles.subtitle}>
          {currentTrack.deity ? `${currentTrack.deity} • ` : ""}
          {categoryLabel}
        </Text>
      </View>

      <View style={styles.progressWrap}>
        <AudioProgressBar progress={progress} onSeek={seekTo} />
        <View style={styles.timeRow}>
          <Text style={styles.timeText}>{formatMillis(positionMillis)}</Text>
          <Text style={styles.timeText}>{formatMillis(durationMillis)}</Text>
        </View>
      </View>

      <View style={styles.controlsRow}>
        <TouchableOpacity onPress={playPrevious} hitSlop={{ top: 10, bottom: 10, left: 10, right: 10 }}>
          <Ionicons name="play-skip-back" size={30} color={Colors.textPrimary} />
        </TouchableOpacity>

        <TouchableOpacity style={styles.playButton} onPress={togglePlayPause} disabled={isLoading}>
          <Ionicons name={isPlaying ? "pause" : "play"} size={32} color="#FFFFFF" />
        </TouchableOpacity>

        <TouchableOpacity onPress={playNext} hitSlop={{ top: 10, bottom: 10, left: 10, right: 10 }}>
          <Ionicons name="play-skip-forward" size={30} color={Colors.textPrimary} />
        </TouchableOpacity>
      </View>

      <Text style={styles.disclaimer}>
        डेमो ऑडियो प्रदर्शन हेतु है। वास्तविक मंत्र/आरती रिकॉर्डिंग जल्द जोड़ी जाएगी।
      </Text>
    </View>
  );
}

const styles = StyleSheet.create({
  screen: {
    flex: 1,
    backgroundColor: Colors.secondary,
    paddingTop: 56,
    paddingHorizontal: Spacing.xl,
  },
  topBar: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    marginBottom: Spacing.xxl,
  },
  topBarLabel: {
    fontSize: 12,
    fontWeight: "600",
    color: "#F0D9CF",
    textTransform: "uppercase",
    letterSpacing: 0.5,
  },
  emptyWrap: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
  },
  emptyText: {
    color: "#F0D9CF",
    marginTop: Spacing.md,
    fontSize: 14,
  },
  artworkWrap: {
    alignItems: "center",
    marginBottom: Spacing.xxl,
  },
  artworkCircle: {
    width: 220,
    height: 220,
    borderRadius: 110,
    backgroundColor: Colors.primaryLight,
    alignItems: "center",
    justifyContent: "center",
  },
  artworkEmoji: { fontSize: 88 },
  infoWrap: {
    alignItems: "center",
    marginBottom: Spacing.xxl,
  },
  title: {
    fontSize: 20,
    fontWeight: "700",
    color: "#FFFFFF",
    textAlign: "center",
  },
  subtitle: {
    fontSize: 13,
    color: "#F0D9CF",
    marginTop: 4,
  },
  progressWrap: {
    marginBottom: Spacing.xl,
  },
  timeRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    marginTop: Spacing.sm,
  },
  timeText: {
    fontSize: 11,
    color: "#F0D9CF",
  },
  controlsRow: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: Spacing.xxl,
  },
  playButton: {
    width: 68,
    height: 68,
    borderRadius: 34,
    backgroundColor: Colors.primary,
    alignItems: "center",
    justifyContent: "center",
    marginHorizontal: Spacing.xl,
  },
  disclaimer: {
    fontSize: 10.5,
    color: "#C9A79B",
    textAlign: "center",
    marginTop: Spacing.xxl,
    paddingHorizontal: Spacing.lg,
  },
});
