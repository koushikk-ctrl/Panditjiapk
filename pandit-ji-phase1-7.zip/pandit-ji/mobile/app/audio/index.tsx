import React, { useMemo, useState } from "react";
import { View, Text, ScrollView, StyleSheet, TouchableOpacity } from "react-native";
import { router } from "expo-router";
import { Ionicons } from "@expo/vector-icons";
import { Colors, Shadow, Spacing, Typography } from "@/constants/theme";
import CategoryChip from "@/components/CategoryChip";
import AudioCard from "@/components/AudioCard";
import MiniPlayerBar from "@/components/MiniPlayerBar";
import EmptyState from "@/components/EmptyState";
import { audioCategories, audioLibrary, getTrackById } from "@/constants/audioData";
import { useAudioPlayer } from "@/contexts/AudioPlayerContext";

const ALL = "सभी";
const FAVORITES = "पसंदीदा";

export default function AudioLibraryScreen() {
  const [activeFilter, setActiveFilter] = useState(ALL);
  const { currentTrack, isPlaying, playTrack, isFavorite, toggleFavorite, recentlyPlayedIds } = useAudioPlayer();

  const filteredTracks = useMemo(() => {
    if (activeFilter === ALL) return audioLibrary;
    if (activeFilter === FAVORITES) return audioLibrary.filter((t) => isFavorite(t.id));
    const categoryId = audioCategories.find((c) => c.label === activeFilter)?.id;
    return audioLibrary.filter((t) => t.category === categoryId);
  }, [activeFilter, isFavorite]);

  const recentTracks = useMemo(
    () => recentlyPlayedIds.map((id) => getTrackById(id)).filter(Boolean).slice(0, 5),
    [recentlyPlayedIds]
  );

  return (
    <View style={styles.screen}>
      <View style={styles.backBar}>
        <TouchableOpacity
          onPress={() => router.back()}
          style={styles.backButton}
          hitSlop={{ top: 10, bottom: 10, left: 10, right: 10 }}
        >
          <Ionicons name="chevron-back" size={24} color={Colors.textPrimary} />
        </TouchableOpacity>
        <Text style={styles.backBarTitle}>मंत्र व ऑडियो</Text>
        <View style={{ width: 24 }} />
      </View>

      <ScrollView
        horizontal
        showsHorizontalScrollIndicator={false}
        contentContainerStyle={styles.chipsRow}
      >
        <CategoryChip label={ALL} active={activeFilter === ALL} onPress={() => setActiveFilter(ALL)} />
        <CategoryChip label={FAVORITES} active={activeFilter === FAVORITES} onPress={() => setActiveFilter(FAVORITES)} />
        {audioCategories.map((c) => (
          <CategoryChip key={c.id} label={c.label} active={activeFilter === c.label} onPress={() => setActiveFilter(c.label)} />
        ))}
      </ScrollView>

      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={styles.scrollContent}>
        {activeFilter === ALL && recentTracks.length > 0 ? (
          <View style={styles.section}>
            <Text style={styles.sectionTitle}>हाल ही में सुना गया</Text>
            {recentTracks.map((t) =>
              t ? (
                <AudioCard
                  key={t.id}
                  title={t.title}
                  subtitle={t.deity || audioCategories.find((c) => c.id === t.category)?.label || ""}
                  durationLabel={t.durationLabel}
                  emoji={t.emoji}
                  isActive={currentTrack?.id === t.id}
                  isPlaying={isPlaying}
                  isFavorite={isFavorite(t.id)}
                  onPress={() => {
                    playTrack(t);
                    router.push("/audio/player");
                  }}
                  onToggleFavorite={() => toggleFavorite(t.id)}
                />
              ) : null
            )}
          </View>
        ) : null}

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>
            {activeFilter === ALL ? "सभी ऑडियो" : activeFilter}
          </Text>
          {filteredTracks.length === 0 ? (
            <EmptyState icon="musical-notes" title="कोई ऑडियो नहीं मिला" subtitle="कृपया कोई अन्य श्रेणी चुनें।" />
          ) : (
            filteredTracks.map((t) => (
              <AudioCard
                key={t.id}
                title={t.title}
                subtitle={t.deity || audioCategories.find((c) => c.id === t.category)?.label || ""}
                durationLabel={t.durationLabel}
                emoji={t.emoji}
                isActive={currentTrack?.id === t.id}
                isPlaying={isPlaying}
                isFavorite={isFavorite(t.id)}
                onPress={() => {
                  playTrack(t);
                  router.push("/audio/player");
                }}
                onToggleFavorite={() => toggleFavorite(t.id)}
              />
            ))
          )}
        </View>
      </ScrollView>

      <MiniPlayerBar onPress={() => router.push("/audio/player")} />
    </View>
  );
}

const styles = StyleSheet.create({
  screen: {
    flex: 1,
    backgroundColor: Colors.background,
    paddingTop: 56,
  },
  backBar: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingHorizontal: Spacing.lg,
    paddingBottom: Spacing.md,
  },
  backButton: {
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: Colors.surface,
    alignItems: "center",
    justifyContent: "center",
    ...Shadow.card,
  },
  backBarTitle: {
    flex: 1,
    textAlign: "center",
    fontSize: 15,
    fontWeight: "700",
    color: Colors.textPrimary,
  },
  chipsRow: {
    paddingHorizontal: Spacing.lg,
    paddingBottom: Spacing.md,
  },
  scrollContent: {
    paddingHorizontal: Spacing.lg,
    paddingBottom: Spacing.md,
  },
  section: {
    marginBottom: Spacing.xl,
  },
  sectionTitle: {
    fontSize: 15,
    fontWeight: "700",
    color: Colors.textPrimary,
    marginBottom: Spacing.md,
  },
});
