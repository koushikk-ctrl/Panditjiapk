import React from "react";
import { View, Text, ScrollView, StyleSheet, TouchableOpacity, ActivityIndicator } from "react-native";
import { router } from "expo-router";
import { useQuery } from "@tanstack/react-query";
import { Ionicons } from "@expo/vector-icons";
import { Colors, Shadow, Spacing, Typography } from "@/constants/theme";
import FestivalCard from "@/components/FestivalCard";
import EmptyState from "@/components/EmptyState";
import { fetchFestivals } from "@/services/festivalService";
import { daysUntil, formatDisplayDate } from "@/utils/dateHelpers";

export default function FestivalCalendarScreen() {
  const { data: festivals, isLoading, isError } = useQuery({
    queryKey: ["festivals"],
    queryFn: fetchFestivals,
  });

  const sorted = (festivals || [])
    .map((f) => ({ ...f, daysUntil: daysUntil(f.date) }))
    .sort((a, b) => {
      // Upcoming festivals first (soonest first), past ones after.
      const aRank = a.daysUntil >= 0 ? a.daysUntil : 10000 - a.daysUntil;
      const bRank = b.daysUntil >= 0 ? b.daysUntil : 10000 - b.daysUntil;
      return aRank - bRank;
    });

  return (
    <View style={styles.screen}>
      <View style={styles.backBar}>
        <TouchableOpacity
          onPress={() => router.back()}
          style={styles.backButton}
          hitSlop={{ top: 10, bottom: 10, left: 10, right: 10 }}
        >
          <Ionicons name="chevron-back" size={24} color={Colors.textPrimary} />
        </TouchableOpacity>
        <Text style={styles.backBarTitle}>त्योहार कैलेंडर</Text>
        <View style={{ width: 24 }} />
      </View>

      <Text style={[Typography.bodySmall, styles.subheading]}>
        हर पर्व, हर परंपरा, सही विधि के साथ
      </Text>

      {isLoading ? (
        <View style={styles.centerWrap}>
          <ActivityIndicator color={Colors.primary} size="large" />
        </View>
      ) : isError || !festivals ? (
        <EmptyState icon="alert-circle" title="त्योहार लोड नहीं हो सके" subtitle="कृपया पुनः प्रयास करें।" />
      ) : (
        <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={styles.scrollContent}>
          {sorted.map((f) => (
            <FestivalCard
              key={f.id}
              name={f.name}
              emoji={f.emoji}
              color={f.color}
              accent={f.accent}
              dateLabel={formatDisplayDate(f.date)}
              daysUntil={f.daysUntil}
              isApproximate={f.isDateApproximate}
              onPress={() => router.push(`/festivals/${f.id}`)}
            />
          ))}
        </ScrollView>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  screen: {
    flex: 1,
    backgroundColor: Colors.background,
    paddingTop: 56,
  },
  backBar: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingHorizontal: Spacing.lg,
    paddingBottom: 4,
  },
  backButton: {
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: Colors.surface,
    alignItems: "center",
    justifyContent: "center",
    ...Shadow.card,
  },
  backBarTitle: {
    flex: 1,
    textAlign: "center",
    fontSize: 15,
    fontWeight: "700",
    color: Colors.textPrimary,
  },
  subheading: {
    textAlign: "center",
    marginBottom: Spacing.md,
  },
  centerWrap: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
  },
  scrollContent: {
    paddingHorizontal: Spacing.lg,
    paddingBottom: Spacing.xxxl,
  },
});
