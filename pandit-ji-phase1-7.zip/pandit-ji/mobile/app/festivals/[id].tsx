import React from "react";
import { View, Text, ScrollView, StyleSheet, TouchableOpacity, ActivityIndicator } from "react-native";
import { router, useLocalSearchParams } from "expo-router";
import { useQuery } from "@tanstack/react-query";
import { Ionicons } from "@expo/vector-icons";
import { Colors, Radius, Shadow, Spacing, Typography } from "@/constants/theme";
import Card from "@/components/Card";
import EmptyState from "@/components/EmptyState";
import { fetchFestivalById } from "@/services/festivalService";
import { daysUntil, formatDisplayDate } from "@/utils/dateHelpers";

export default function FestivalDetailScreen() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const { data: festival, isLoading } = useQuery({
    queryKey: ["festival", id],
    queryFn: () => fetchFestivalById(id as string),
    enabled: !!id,
  });

  return (
    <View style={styles.screen}>
      <BackBar title={festival?.name || ""} />

      {isLoading ? (
        <View style={styles.centerWrap}>
          <ActivityIndicator color={Colors.primary} size="large" />
        </View>
      ) : !festival ? (
        <EmptyState icon="alert-circle" title="यह त्योहार नहीं मिला" subtitle="कृपया वापस जाकर दोबारा कोशिश करें।" />
      ) : (
        <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={styles.scrollContent}>
          <View style={[styles.hero, { backgroundColor: festival.color }]}>
            <Text style={styles.heroEmoji}>{festival.emoji}</Text>
            <Text style={styles.heroName}>{festival.name}</Text>
            <Text style={[styles.heroPurpose, { color: festival.accent }]}>{festival.shortDescription}</Text>

            <View style={styles.metaRow}>
              <MetaPill icon="calendar-outline" label={formatDisplayDate(festival.date)} />
              <MetaPill icon="time-outline" label={festival.muhurat} />
            </View>

            <View style={styles.countdownBadge}>
              <Text style={[styles.countdownText, { color: festival.accent }]}>
                {(() => {
                  const d = daysUntil(festival.date);
                  return d >= 0 ? `${d} दिन शेष` : "यह वर्ष बीत चुका है";
                })()}
                {festival.isDateApproximate ? " • तिथि अनुमानित" : ""}
              </Text>
            </View>
          </View>

          <Section title="तिथि">
            <Text style={Typography.body}>{festival.tithi}</Text>
          </Section>

          <Section title="विवरण">
            <Text style={Typography.body}>{festival.description}</Text>
          </Section>

          <Section title="आवश्यक सामग्री">
            <Card backgroundColor={Colors.accentGreenBg}>
              {festival.samagri.map((item, i) => (
                <View key={i} style={styles.samagriRow}>
                  <Ionicons name="checkmark-circle" size={16} color={Colors.accentGreen} />
                  <Text style={[Typography.body, { marginLeft: Spacing.sm }]}>{item}</Text>
                </View>
              ))}
            </Card>
          </Section>

          <Section title="पूजा विधि">
            {festival.vidhiSteps.map((step, i) => (
              <View key={i} style={styles.stepRow}>
                <View style={styles.stepNumber}>
                  <Text style={styles.stepNumberText}>{i + 1}</Text>
                </View>
                <View style={{ flex: 1 }}>
                  <Text style={styles.stepTitle}>{step.title}</Text>
                  <Text style={Typography.bodySmall}>{step.description}</Text>
                </View>
              </View>
            ))}
          </Section>

          <Section title="मंत्र">
            {festival.mantras.map((m, i) => (
              <Card key={i} backgroundColor={Colors.primaryLight} style={{ marginBottom: Spacing.sm }}>
                <Text style={styles.mantraSanskrit}>{m.sanskrit}</Text>
                <Text style={[Typography.bodySmall, { marginTop: Spacing.xs }]}>{m.meaning}</Text>
              </Card>
            ))}
          </Section>

          <View style={{ height: Spacing.xxxl }} />
        </ScrollView>
      )}
    </View>
  );
}

function BackBar({ title }: { title: string }) {
  return (
    <View style={styles.backBar}>
      <TouchableOpacity
        onPress={() => router.back()}
        style={styles.backButton}
        hitSlop={{ top: 10, bottom: 10, left: 10, right: 10 }}
      >
        <Ionicons name="chevron-back" size={24} color={Colors.textPrimary} />
      </TouchableOpacity>
      <Text style={styles.backBarTitle} numberOfLines={1}>
        {title}
      </Text>
      <View style={{ width: 24 }} />
    </View>
  );
}

function MetaPill({ icon, label }: { icon: keyof typeof Ionicons.glyphMap; label: string }) {
  return (
    <View style={styles.metaPill}>
      <Ionicons name={icon} size={13} color={Colors.textPrimary} />
      <Text style={styles.metaPillText}>{label}</Text>
    </View>
  );
}

function Section({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <View style={styles.section}>
      <Text style={styles.sectionTitle}>{title}</Text>
      {children}
    </View>
  );
}

const styles = StyleSheet.create({
  screen: {
    flex: 1,
    backgroundColor: Colors.background,
    paddingTop: 56,
  },
  centerWrap: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
  },
  scrollContent: {
    paddingBottom: Spacing.xxxl,
  },
  backBar: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingHorizontal: Spacing.lg,
    paddingBottom: Spacing.md,
  },
  backButton: {
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: Colors.surface,
    alignItems: "center",
    justifyContent: "center",
    ...Shadow.card,
  },
  backBarTitle: {
    flex: 1,
    textAlign: "center",
    fontSize: 15,
    fontWeight: "700",
    color: Colors.textPrimary,
    marginHorizontal: Spacing.sm,
  },
  hero: {
    marginHorizontal: Spacing.lg,
    borderRadius: Radius.lg,
    padding: Spacing.xl,
    alignItems: "center",
    marginBottom: Spacing.lg,
  },
  heroEmoji: { fontSize: 40, marginBottom: Spacing.sm },
  heroName: { fontSize: 20, fontWeight: "700", color: Colors.textPrimary },
  heroPurpose: { fontSize: 13, fontWeight: "600", marginTop: 4 },
  metaRow: {
    flexDirection: "row",
    marginTop: Spacing.md,
  },
  metaPill: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: Colors.surface,
    borderRadius: Radius.pill,
    paddingHorizontal: Spacing.md,
    paddingVertical: 6,
    marginHorizontal: Spacing.xs,
  },
  metaPillText: {
    fontSize: 11.5,
    fontWeight: "600",
    color: Colors.textPrimary,
    marginLeft: 4,
  },
  countdownBadge: {
    marginTop: Spacing.md,
    backgroundColor: "rgba(255,255,255,0.6)",
    paddingHorizontal: Spacing.md,
    paddingVertical: 6,
    borderRadius: Radius.pill,
  },
  countdownText: {
    fontSize: 12,
    fontWeight: "700",
  },
  section: {
    paddingHorizontal: Spacing.lg,
    marginBottom: Spacing.xl,
  },
  sectionTitle: {
    fontSize: 16,
    fontWeight: "700",
    color: Colors.textPrimary,
    marginBottom: Spacing.sm,
  },
  samagriRow: {
    flexDirection: "row",
    alignItems: "center",
    marginBottom: Spacing.sm,
  },
  stepRow: {
    flexDirection: "row",
    marginBottom: Spacing.md,
  },
  stepNumber: {
    width: 26,
    height: 26,
    borderRadius: 13,
    backgroundColor: Colors.primary,
    alignItems: "center",
    justifyContent: "center",
    marginRight: Spacing.md,
    marginTop: 2,
  },
  stepNumberText: {
    color: Colors.textOnPrimary,
    fontSize: 12,
    fontWeight: "700",
  },
  stepTitle: {
    fontSize: 14,
    fontWeight: "700",
    color: Colors.textPrimary,
    marginBottom: 2,
  },
  mantraSanskrit: {
    fontSize: 16,
    fontWeight: "700",
    color: Colors.secondary,
  },
});
