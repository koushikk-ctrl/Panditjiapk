import React from "react";
import { View, Text, ScrollView, StyleSheet, TouchableOpacity, ActivityIndicator } from "react-native";
import { router } from "expo-router";
import { Ionicons } from "@expo/vector-icons";
import { Colors, Radius, Shadow, Spacing, Typography } from "@/constants/theme";
import Card from "@/components/Card";
import SadhanaChecklistItem from "@/components/SadhanaChecklistItem";
import WeekStrip from "@/components/WeekStrip";
import { useSadhana } from "@/hooks/useSadhana";

export default function SadhanaScreen() {
  const {
    items,
    loading,
    isCompleted,
    toggleItem,
    todayCompletedCount,
    totalItems,
    todayPercent,
    last7Days,
    streak,
    monthStats,
  } = useSadhana();

  return (
    <View style={styles.screen}>
      <View style={styles.backBar}>
        <TouchableOpacity
          onPress={() => router.back()}
          style={styles.backButton}
          hitSlop={{ top: 10, bottom: 10, left: 10, right: 10 }}
        >
          <Ionicons name="chevron-back" size={24} color={Colors.textPrimary} />
        </TouchableOpacity>
        <Text style={styles.backBarTitle}>दैनिक साधना</Text>
        <View style={{ width: 24 }} />
      </View>

      {loading ? (
        <View style={styles.loadingWrap}>
          <ActivityIndicator color={Colors.primary} size="large" />
        </View>
      ) : (
        <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={styles.scrollContent}>
          {/* Today's progress + streak */}
          <View style={styles.progressCard}>
            <View style={{ flex: 1 }}>
              <Text style={styles.progressTitle}>आज की साधना</Text>
              <Text style={styles.progressSubtitle}>
                {todayCompletedCount} / {totalItems} पूर्ण
              </Text>
              <View style={styles.streakRow}>
                <Text style={styles.streakEmoji}>🔥</Text>
                <Text style={styles.streakText}>{streak} दिन की लय</Text>
              </View>
            </View>
            <View style={styles.percentBadge}>
              <Text style={styles.percentText}>{todayPercent}%</Text>
            </View>
          </View>

          {/* Checklist */}
          <View style={styles.section}>
            <Text style={styles.sectionTitle}>आज के कार्य</Text>
            {items.map((item) => (
              <SadhanaChecklistItem
                key={item.id}
                icon={item.icon}
                title={item.title}
                completed={isCompleted(item.id)}
                onToggle={() => toggleItem(item.id)}
              />
            ))}
          </View>

          {/* Weekly streak strip */}
          <View style={styles.section}>
            <Text style={styles.sectionTitle}>साप्ताहिक प्रगति</Text>
            <Card>
              <WeekStrip days={last7Days} />
            </Card>
          </View>

          {/* Monthly progress */}
          <View style={styles.section}>
            <Text style={styles.sectionTitle}>मासिक प्रगति</Text>
            <Card backgroundColor={Colors.accentBlueBg}>
              <Text style={styles.monthText}>
                इस महीने {monthStats.fullyCompletedDays} / {monthStats.daysSoFar} दिन पूर्ण
              </Text>
              <View style={styles.monthBarTrack}>
                <View
                  style={[
                    styles.monthBarFill,
                    {
                      width: `${
                        monthStats.daysSoFar === 0
                          ? 0
                          : Math.round((monthStats.fullyCompletedDays / monthStats.daysSoFar) * 100)
                      }%`,
                    },
                  ]}
                />
              </View>
            </Card>
          </View>

          <View style={{ height: Spacing.xxxl }} />
        </ScrollView>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  screen: {
    flex: 1,
    backgroundColor: Colors.background,
    paddingTop: 56,
  },
  backBar: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingHorizontal: Spacing.lg,
    paddingBottom: Spacing.md,
  },
  backButton: {
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: Colors.surface,
    alignItems: "center",
    justifyContent: "center",
    ...Shadow.card,
  },
  backBarTitle: {
    flex: 1,
    textAlign: "center",
    fontSize: 15,
    fontWeight: "700",
    color: Colors.textPrimary,
  },
  loadingWrap: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
  },
  scrollContent: {
    paddingHorizontal: Spacing.lg,
    paddingBottom: Spacing.xxxl,
  },
  progressCard: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: Colors.secondary,
    borderRadius: Radius.lg,
    padding: Spacing.lg,
    marginBottom: Spacing.xl,
  },
  progressTitle: {
    color: "#FFFFFF",
    fontSize: 16,
    fontWeight: "700",
  },
  progressSubtitle: {
    color: "#F0D9CF",
    fontSize: 13,
    marginTop: 2,
  },
  streakRow: {
    flexDirection: "row",
    alignItems: "center",
    marginTop: Spacing.sm,
  },
  streakEmoji: { fontSize: 14, marginRight: 4 },
  streakText: {
    color: "#FDE9D2",
    fontSize: 12.5,
    fontWeight: "600",
  },
  percentBadge: {
    width: 56,
    height: 56,
    borderRadius: 28,
    backgroundColor: Colors.primary,
    alignItems: "center",
    justifyContent: "center",
  },
  percentText: {
    color: "#FFFFFF",
    fontSize: 14,
    fontWeight: "700",
  },
  section: {
    marginBottom: Spacing.xl,
  },
  sectionTitle: {
    fontSize: 16,
    fontWeight: "700",
    color: Colors.textPrimary,
    marginBottom: Spacing.md,
  },
  monthText: {
    fontSize: 14,
    fontWeight: "700",
    color: Colors.textPrimary,
    marginBottom: Spacing.sm,
  },
  monthBarTrack: {
    height: 8,
    borderRadius: 4,
    backgroundColor: "#D7E6F2",
    overflow: "hidden",
  },
  monthBarFill: {
    height: 8,
    borderRadius: 4,
    backgroundColor: Colors.accentBlue,
  },
});
