import React, { useMemo, useState } from "react";
import { View, Text, TextInput, ScrollView, StyleSheet } from "react-native";
import { router } from "expo-router";
import { Ionicons } from "@expo/vector-icons";
import { Colors, Radius, Spacing, Typography } from "@/constants/theme";
import CategoryChip from "@/components/CategoryChip";
import PoojaCard from "@/components/PoojaCard";
import EmptyState from "@/components/EmptyState";
import { categories, poojaLibrary } from "@/constants/poojaData";

const ALL = "सभी";

export default function LibraryScreen() {
  const [query, setQuery] = useState("");
  const [activeCategory, setActiveCategory] = useState(ALL);

  const filtered = useMemo(() => {
    return poojaLibrary.filter((p) => {
      const matchesCategory = activeCategory === ALL || p.category === activeCategory;
      const matchesQuery = p.name.toLowerCase().includes(query.trim().toLowerCase());
      return matchesCategory && matchesQuery;
    });
  }, [query, activeCategory]);

  return (
    <View style={styles.screen}>
      <View style={styles.header}>
        <Text style={Typography.h1}>पूजा पुस्तकालय</Text>
        <Text style={[Typography.bodySmall, { marginTop: 2 }]}>हर देवता, हर विधि, एक ही जगह</Text>
      </View>

      <View style={styles.searchBar}>
        <Ionicons name="search" size={18} color={Colors.textSecondary} />
        <TextInput
          value={query}
          onChangeText={setQuery}
          placeholder="पूजा खोजें..."
          placeholderTextColor={Colors.textSecondary}
          style={styles.searchInput}
        />
      </View>

      <ScrollView
        horizontal
        showsHorizontalScrollIndicator={false}
        contentContainerStyle={styles.chipsRow}
      >
        <CategoryChip label={ALL} active={activeCategory === ALL} onPress={() => setActiveCategory(ALL)} />
        {categories.map((c) => (
          <CategoryChip key={c} label={c} active={activeCategory === c} onPress={() => setActiveCategory(c)} />
        ))}
      </ScrollView>

      <ScrollView
        showsVerticalScrollIndicator={false}
        contentContainerStyle={styles.grid}
      >
        {filtered.length === 0 ? (
          <EmptyState
            icon="search"
            title="कोई पूजा नहीं मिली"
            subtitle="कृपया अलग खोज शब्द या श्रेणी आज़माएं।"
          />
        ) : (
          filtered.map((p) => (
            <PoojaCard
              key={p.id}
              name={p.name}
              emoji={p.emoji}
              shortPurpose={p.shortPurpose}
              color={p.color}
              accent={p.accent}
              onPress={() => router.push(`/pooja/${p.id}`)}
            />
          ))
        )}
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  screen: {
    flex: 1,
    backgroundColor: Colors.background,
    paddingTop: 56,
  },
  header: {
    paddingHorizontal: Spacing.lg,
    marginBottom: Spacing.md,
  },
  searchBar: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: Colors.surface,
    borderRadius: Radius.pill,
    borderWidth: 1,
    borderColor: Colors.border,
    marginHorizontal: Spacing.lg,
    paddingHorizontal: Spacing.md,
    paddingVertical: 10,
    marginBottom: Spacing.md,
  },
  searchInput: {
    flex: 1,
    marginLeft: Spacing.sm,
    fontSize: 14,
    color: Colors.textPrimary,
  },
  chipsRow: {
    paddingHorizontal: Spacing.lg,
    paddingBottom: Spacing.md,
  },
  grid: {
    flexDirection: "row",
    flexWrap: "wrap",
    justifyContent: "space-between",
    paddingHorizontal: Spacing.lg,
    paddingBottom: Spacing.xxxl,
  },
});
