import React from "react";
import { View, Text, StyleSheet } from "react-native";
import { Colors, Typography } from "@/constants/theme";

export default function PanditScreen() {
  return (
    <View style={styles.screen}>
      <Text style={Typography.h1}>pandit</Text>
      <Text style={[Typography.bodySmall, { marginTop: 8 }]}>
        This tab will be built in a later phase.
      </Text>
    </View>
  );
}

const styles = StyleSheet.create({
  screen: {
    flex: 1,
    backgroundColor: Colors.background,
    padding: 20,
    paddingTop: 60,
  },
});
